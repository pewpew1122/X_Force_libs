vehicles = { -- from;https://github.com/iLeaksy/fivem-vehicle-list, still searching for a better source
    ["compacts"] = { "asbo","blista","brioso","brioso2","club","dilettante","issi2","issi3","kanjo","panto","prairie","rhapsody","weevil",},
    ["cycles"] = { "bmx","cruiser","fixter","scorcher","tribike","tribike2","tribike3",},
    ["sportsclassics"] = { "btype","btype2","btype3","casco","coquette2","feltzer3","gt500","manana","monroe","pigalle","rapidgt3","retinue","savestra","stinger","stingergt","viseris","z190","ztype",},
    --["commercial"] = { "mule5",},
    ["super"] = { "adder","autarch","banshee2","bullet","cheetah","cyclone","emerus","entity2","entityxf","fmj","furia","gp1","infernus","italigtb","italigtb2","krieger","le7b","nero","nero2","osiris","penetrator","pfister811","prototipo","reaper","s80","sc1","sheava","sultanrs","t20","taipan","tempesta","tezeract","thrax","tigon","turismor","tyrant","tyrus","vacca","vagner","visione","voltic","xa21","zentorno","zorrusso","champion","ignus","zeno",},
    ["offroad"] = { "bfinjection","bifta","blazer","blazer4","bodhi2","brawler","dloader","dubsta3","dune","everon","freecrawler","guardian","hellion","kalahari","kamacho","outlaw","rancherxl","rebel","rebel2","riata","sandking","sandking2","trophytruck","trophytruck2","vagrant","verus","winky","caracara2","20000",},
    ["sedans"] = { "asea","asterope","cheburek","cog55","cognoscenti","emperor","emperor2","fugitive","glendale","glendale2","ingot","intruder","premier","primo","primo2","regina","schafter2","stafford","stanier","stratum","stretch","superd","surge","tailgater","warrener","washington","cinquemila","deity",},
    ["motorcycles"] = { "akuma","avarus","bagger","bati","bati2","bf400","carbonrs","chimera","cliffhanger","daemon","daemon2","defiler","diablous","diablous2","double","enduro","esskey","faggio","faggio2","faggio3","fcr","fcr2","gargoyle","hakuchou","hakuchou2","hexer","innovation","manchez","manchez2","nemesis","nightblade","pcj","ratbike","ruffian","sanchez","sanchez2","sanctus","sovereign","stryder","thrust","vader","vindicator","vortex","wolfsbane","zombiea","zombieb","reever","shinobi",},
    ["suvs"] = { "baller2","baller3","baller4","bjxl","cavalcade","cavalcade2","contender","dubsta","dubsta2","fq2","granger","gresley","habanero","huntley","landstalker","landstalker2","mesa","mesa3","novak","patriot","patriot2","radi","rebla","rocoto","seminole","seminole2","serrano","squaddie","toros","xls","astron","baller7","granger2","iwagen","jubilee",},
    ["muscle"] = { "blade","buccaneer","buccaneer2","chino","chino2","clique","coquette3","deviant","dominator","dominator2","dominator3","dukes","dukes3","ellie","faction","faction2","gauntlet","gauntlet2","gauntlet3","gauntlet4","gauntlet5","hermes","hotknife","hustler","impaler","nightshade","peyote2","phoenix","picador","ratloader","ratloader2","ruiner","ruiner3","sabregt","sabregt2","slamvan3","stalion","stalion2","tampa","tulip","vamos","vigero","virgo","virgo2","virgo3","voodoo","voodoo2","yosemite","yosemite2","yosemite3","buffalo4",},
    ["coupes"] = { "cogcabrio","exemplar","f620","felon","felon2","jackal","oracle","oracle2","sentinel","sentinel2","windsor","windsor2","zion","zion2",},
    ["sports"] = { "alpha","banshee","bestiagts","blista2","blista3","buffalo","buffalo2","buffalo3","carbonizzare","cheetah2","comet2","comet5","coquette","deveste","drafter","dynasty","elegy","elegy2","fagaloa","feltzer2","flashgt","furoregt","fusilade","futo","gb200","hotring","imorgon","infernus2","issi7","italigto","italirsx","jester","jester2","jester3","jugular","khamelion","komoda","kuruma","locust","lynx","mamba","manana2","massacro","massacro2","michelli","nebula","neon","ninef","ninef2","omnis","paragon","pariah","penumbra","penumbra2","peyote","peyote3","raiden","rapidgt","rapidgt2","raptor","retinue2","revolter","ruston","schafter3","schafter4","schlagen","schwarzer","sentinel3","seven70","specter","specter2","streiter","sugoi","sultan","sultan2","surano","swinger","tampa2","torero","tornado","tornado2","tornado3","tornado4","tornado5","tornado6","tropos","turismo2","verlierer2","vstr","zion3","comet6","dominator7","dominator8","euros","futo2","rt3000","sultan3","tailgater2","growler","vectre","remus","calico","cypher","jester4","zr350","previon","warrener2","comet7",},
    ["vans"] = { "bison","bison2","bobcatxl","burrito2","burrito3","burrito4","camper","gburrito","gburrito2","journey","minivan","minivan2","moonbeam","moonbeam2","paradise","pony","pony2","rumpo","rumpo2","speedo","speedo2","speedo4","surfer","surfer2","taco","youga","youga2","youga3","youga4",},
}

--from: Nathanoy#1827
local function request_model(str)
    local model = g_util.joaat(str)
    STREAMING.REQUEST_MODEL(model)
    while not STREAMING.HAS_MODEL_LOADED(model) do
      g_util.yield()
    end
    return model
end

local function max_veh(veh)
    VEHICLE.SET_VEHICLE_MOD_KIT(veh, 0)
    for mods = 0, 48 do
        VEHICLE.SET_VEHICLE_MOD(veh, mods, VEHICLE.GET_NUM_VEHICLE_MODS(veh, mods)-1, false)
    end
    VEHICLE.TOGGLE_VEHICLE_MOD(veh, 22, true) -- enable xenon
    
end

local PI = 3.14159265359
local PI_180 = PI/180
local DISTANCE = 5
local function asin(x) return g_math.sin(x*PI_180) end
local function acos(x) return g_math.cos(x*PI_180) end

local function set_veh_gm(veh)
    ENTITY.SET_ENTITY_INVINCIBLE(veh, true)
    VEHICLE.SET_VEHICLE_CAN_BE_VISIBLY_DAMAGED(veh, false)
end

local function mod_vehicle(veh, plate_text)
    DECORATOR.DECOR_SET_INT(veh, "MPBitset", 0)
    NETWORK.SET_ENTITY_EXISTS_ON_ALL_MACHINES(veh, true)
    -- VEHICLE.SET_VEHICLE_CUSTOM_PRIMARY_COLOUR(veh, 0, 0, 0)
    -- VEHICLE.SET_VEHICLE_CUSTOM_SECONDARY_COLOUR(veh, 255, 255, 255)
    VEHICLE.SET_VEHICLE_NUMBER_PLATE_TEXT(veh, plate_text)
    VEHICLE.SET_VEHICLE_ON_GROUND_PROPERLY(veh, 0)
    max_veh(veh)
    set_veh_gm(veh)
end

-- facing: int 0 to 360
-- coords: vec3
-- distance: int
local function spawn_radial(model, coords, facing, distance)
    local x, y = coords.x - (asin(facing)* distance) , coords.y + (acos(facing)*distance)
    local veh = VEHICLE.CREATE_VEHICLE(model, x, y, coords.z, facing, true, true, false)
    mod_vehicle(veh,  "smile")
    return veh
end

local function max(a,  b)
    return a > b and a or b
end

local function spawn_circle(vehicles)
    local mul = 360 / #vehicles
    local d = max(#vehicles * (1/ 2), 5)
    local rot
    local c = PLAYER.GET_PLAYER_COORDS(PLAYER.PLAYER_ID())
    for i, veh in pairs(vehicles) do
        rot = i * mul
        spawn_radial(request_model(veh), c, rot, d)
        g_util.yield()
    end
end

function get_spawn_fn(values)
    local values = values
    return function()
        spawn_circle(values)
    end
end

function cleararea()
    --g_gui.go_to_submenu(300)
    g_gui.press_option(300, 2)--should be the clear area option
end

g_lua.register()
local SUB_NAME = "Spawn Categories"
local TARGET_SUB = "Lua Options"
g_gui.add_submenu(TARGET_SUB, SUB_NAME)

g_gui.add_separator(SUB_NAME, "F4 to unload")
g_gui.add_button(SUB_NAME, "Clear Area", cleararea) 
g_gui.add_separator(SUB_NAME, "Vehicles")
for name, values in pairs(vehicles) do
   g_gui.add_button(SUB_NAME, ("%s (%s)"):format(name, #values), get_spawn_fn(values)) 
end

g_gui.add_toast(("Added Submenu in: %s. Named: %s"):format(TARGET_SUB, SUB_NAME))

repeat
    if g_util.is_key_pressed(115) then -- F4
        g_lua.unregister()
    end
    -- if g_util.is_key_pressed(116) then -- F5
    --     print(g_gui.get_current_submenu_id(), g_gui.get_current_option_id())
    -- end
    g_util.yield()
until false

