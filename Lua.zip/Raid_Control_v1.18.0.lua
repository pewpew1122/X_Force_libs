g_lua.register()

-- [[ Developer: Not_DerPaul ]] --

notify = g_gui.add_toast
log = g_logger.log_info
submenu = g_gui.add_submenu
separator = g_gui.add_separator
button = g_gui.add_button
toggle = g_gui.add_toggle
input = g_gui.add_input_int
input_keyboard = g_gui.add_input_text
trsl = g_translation.get_translated

NETWORK = NETWORK.IS_SESSION_STARTED()

function STAT_SET_BOOL(hash, val)
    STATS.STAT_SET_BOOL(g_util.joaat("MP0_" .. hash), val, true)
    STATS.STAT_SET_BOOL(g_util.joaat("MP1_" .. hash), val, true)
end

function STAT_GET_BOOL(hash)
    STATS.STAT_GET_BOOL(g_util.joaat("MP0_" .. hash))
    STATS.STAT_GET_BOOL(g_util.joaat("MP1_" .. hash))
end

function STAT_SET_BOOL_MPPLY(hash, val)
    STATS.STAT_SET_BOOL(g_util.joaat(hash), val, true)
end

function STAT_SET_INT(hash, val)
    STATS.STAT_SET_INT(g_util.joaat("MP0_" .. hash), val, true)
    STATS.STAT_SET_INT(g_util.joaat("MP1_" .. hash), val, true)
end

function STAT_GET_INT(hash)
    local char = STATS.STAT_GET_INT(g_util.joaat("MPPLY_LAST_MP_CHAR"))
    return STATS.STAT_GET_INT(g_util.joaat("MP" .. char .. "_" .. hash))
end

function STAT_SET_INT_MPPLY(hash, val)
    STATS.STAT_SET_INT(g_util.joaat(hash), val, true)
end

function STAT_SET_FLOAT(hash, val)
    STATS.STAT_SET_FLOAT(g_util.joaat(hash), val, true)
end

function STAT_GET_FLOAT(hash, val)
    STATS.STAT_GET_FLOAT(g_util.joaat("MP0_" .. hash))
    STATS.STAT_GET_FLOAT(g_util.joaat("MP1_" .. hash))
end

function STAT_SET_FLOAT_MPPLY(hash, val)
    STATS.STAT_SET_FLOAT(util.joaat(hash), val, true)
end

function better_yield(time)
    local t0 = os.time()
    while (os.time() - t0) < time do
        g_util.yield()
    end
end

function check(int)
    if int >= 1 then
        return "True"
    else
        return "False"
    end
end

function check_status()
    if STAT_GET_BOOL("MPPLY_IS_HIGH_EARNER") or STAT_GET_BOOL("MPPLY_IS_CHEATER") or STAT_GET_BOOL("MPPLY_IS_CHEATER") then
        notify(trsl("FlgCh"))
    end
end

function keyboard_inp()
    g_gui.show_menu_ui(false)
    GAMEPLAY.DISPLAY_ONSCREEN_KEYBOARD("", "", 30)
    while GAMEPLAY.UPDATE_ONSCREEN_KEYBOARD() == 0 do
        g_util.yield()
    end
    g_gui.show_menu_ui(true)
    return GAMEPLAY.GET_ONSCREEN_KEYBOARD_RESULT()
end

local input_register = {}
local inp_delay = 150
local last_pressed_on = 0
local hold = 0
local inp_timer = g_os.time_ms()

function handle_inputs()
    if not g_util.is_key_pressed(last_key) then
        hold = 0
    end
    for k, f in pairs(input_register) do
        if g_util.is_key_pressed(k) and ((g_os.time_ms() - inp_timer) > inp_delay) then
            f()
            if k == last_key then
                hold = hold + 1
            else
                hold = 0
            end
            if hold > 3 then
                inp_delay = 80
            else
                inp_delay = 150
            end
            last_key = k
            inp_timer = g_os.time_ms()
        end
    end
end

KEY = {
    ENTER = 13
}

function register_input(key, func)
    if type(func) == "function" then
        input_register[key] = func
    else
        log("Not a function: %s => %s", func, type(func))
    end
end

local loglogo =
    "\n██████╗░░█████╗░██╗██████╗░  ░█████╗░░█████╗░███╗░░██╗████████╗██████╗░░█████╗░██╗░░░░░\n██╔══██╗██╔══██╗██║██╔══██╗  ██╔══██╗██╔══██╗████╗░██║╚══██╔══╝██╔══██╗██╔══██╗██║░░░░░\n██████╔╝███████║██║██║░░██║  ██║░░╚═╝██║░░██║██╔██╗██║░░░██║░░░██████╔╝██║░░██║██║░░░░░\n██╔══██╗██╔══██║██║██║░░██║  ██║░░██╗██║░░██║██║╚████║░░░██║░░░██╔══██╗██║░░██║██║░░░░░\n██║░░██║██║░░██║██║██████╔╝  ╚█████╔╝╚█████╔╝██║░╚███║░░░██║░░░██║░░██║╚█████╔╝███████╗\n╚═╝░░╚═╝╚═╝░░╚═╝╚═╝╚═════╝░  ░╚════╝░░╚════╝░╚═╝░░╚══╝░░░╚═╝░░░╚═╝░░╚═╝░╚════╝░╚══════╝"
log(loglogo)

-- [[ Main Submenus ]] --

submenu("Main Menu", "Raid Control")
submenu("Lua Player Options", "Raid Players")

-- [[ Heist Submenus ]] --

separator("Raid Control", "Heists")
submenu("Raid Control", "CayoPericoHeist")
submenu("Raid Control", "DiamondCasinoHeist")
submenu("Raid Control", "DoomsdayHeist")
submenu("Raid Control", "ClassicHeists")
submenu("Raid Control", "LSContract")
submenu("Raid Control", "TheContract")

-- [[ World ]] --

separator("Raid Control", "Wrld")


-- [[ Clear ]] --

submenu("Raid Control", "Clr")

-- [[ Single ]] --

separator("Clr", "Sin")

button(
    "Clr",
    "Every",
    function()
        local pos = ENTITY.GET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID())
        GAMEPLAY.CLEAR_AREA_OF_COPS(pos.x, pos.y, pos.z, 100, 0)
        GAMEPLAY.CLEAR_AREA_OF_VEHICLES(pos.x, pos.y, pos.z, 100, false, false, false, false, false, false)
        GAMEPLAY.CLEAR_AREA_OF_OBJECTS(pos.x, pos.y, pos.z, 100, 0)
        for i = 0, POOL.GET_PED_COUNT() do
            local ped = POOL.GET_PED_AT_INDEX(i)
            if not PED.IS_PED_A_PLAYER(ped) then
                PED.SET_PED_HEALTH(ped, 0)
                SYSTEM.WAIT(50)
                ENTITY.SET_ENTITY_AS_MISSION_ENTITY(ped, true, true)
                ENTITY.DELETE_ENTITY(ped)
            end
        end
    end
)

button(
    "Clr",
    "Peds",
    function()
        for i = 0, POOL.GET_PED_COUNT() do
            local ped = POOL.GET_PED_AT_INDEX(i)
            if not PED.IS_PED_A_PLAYER(ped) then
                PED.SET_PED_HEALTH(ped, 0)
                SYSTEM.WAIT(50)
                ENTITY.SET_ENTITY_AS_MISSION_ENTITY(ped, true, true)
                ENTITY.DELETE_ENTITY(ped)
            end
        end
    end
)

button(
    "Clr",
    "Cops",
    function()
        local pos = ENTITY.GET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID())
        GAMEPLAY.CLEAR_AREA_OF_COPS(pos.x, pos.y, pos.z, 100, 0)
    end
)

button(
    "Clr",
    "Veh",
    function()
        local pos = ENTITY.GET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID())
        GAMEPLAY.CLEAR_AREA_OF_VEHICLES(pos.x, pos.y, pos.z, 100, false, false, false, false, false, false)
    end
)

button(
    "Clr",
    "Obj",
    function()
        local pos = ENTITY.GET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID())
        GAMEPLAY.CLEAR_AREA_OF_OBJECTS(pos.x, pos.y, pos.z, 100, 0)
    end
)

-- [[ Looped ]] --

separator("Clr", "Loop")

toggle(
    "Clr",
    "EverythingLooped",
    false,
    function(on)
        clear = on
        while clear do
            SYSTEM.WAIT(100)
            local pos = ENTITY.GET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID())
            GAMEPLAY.CLEAR_AREA_OF_COPS(pos.x, pos.y, pos.z, 100, 0)
            GAMEPLAY.CLEAR_AREA_OF_VEHICLES(pos.x, pos.y, pos.z, 100, false, false, false, false, false, false)
            GAMEPLAY.CLEAR_AREA_OF_OBJECTS(pos.x, pos.y, pos.z, 100, 0)
            for i = 0, POOL.GET_PED_COUNT() do
                local ped = POOL.GET_PED_AT_INDEX(i)
                if not PED.IS_PED_A_PLAYER(ped) then
                    PED.SET_PED_HEALTH(ped, 0)
                    SYSTEM.WAIT(50)
                    ENTITY.SET_ENTITY_AS_MISSION_ENTITY(ped, true, true)
                    ENTITY.DELETE_ENTITY(ped)
                end
            end
        end
    end
)

toggle(
    "Clr",
    "PedsLooped",
    false,
    function(on)
        clear = on
        while clear do
            SYSTEM.WAIT(100)
            for i = 0, POOL.GET_PED_COUNT() do
                local ped = POOL.GET_PED_AT_INDEX(i)
                if not PED.IS_PED_A_PLAYER(ped) then
                    PED.SET_PED_HEALTH(ped, 0)
                    SYSTEM.WAIT(50)
                    ENTITY.SET_ENTITY_AS_MISSION_ENTITY(ped, true, true)
                    ENTITY.DELETE_ENTITY(ped)
                end
            end
        end
    end
)

toggle(
    "Clr",
    "CopsLooped",
    false,
    function(on)
        clear = on
        while clear do
            SYSTEM.WAIT(100)
            local pos = ENTITY.GET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID())
            GAMEPLAY.CLEAR_AREA_OF_COPS(pos.x, pos.y, pos.z, 100, 0)
        end
    end
)

toggle(
    "Clr",
    "VehiclesLooped",
    false,
    function(on)
        clear = on
        while clear do
            SYSTEM.WAIT(100)
            local pos = ENTITY.GET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID())
            GAMEPLAY.CLEAR_AREA_OF_VEHICLES(pos.x, pos.y, pos.z, 100, false, false, false, false, false, false)
        end
    end
)

toggle(
    "Clr",
    "ObjectsLooped",
    false,
    function(on)
        clear = on
        while clear do
            SYSTEM.WAIT(100)
            local pos = ENTITY.GET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID())
            GAMEPLAY.CLEAR_AREA_OF_OBJECTS(pos.x, pos.y, pos.z, 100, 0)
        end
    end
)

-- [[ Misc ]] --

separator("Raid Control", "Misc")

toggle(
    "Raid Control",
    "Skip",
    false,
    function(on)
        cut = on
        while cut do
            g_util.yield()
            if CUTSCENE.IS_CUTSCENE_ACTIVE() and CUTSCENE.IS_CUTSCENE_PLAYING() then
                CUTSCENE.STOP_CUTSCENE_IMMEDIATELY()
            end
        end
    end
)

button(
    "Raid Control",
    "Leave",
    "LeaveBio",
    function()
        if NETWORK then
            notify("LeaveNot", 500)
            SYSTEM.WAIT(300)
            local time = os.time() + 10
            while time > os.time() do
            end
        end
    end
)

-- [[ More ]] --

separator("Raid Control", "More")

-- [[ Remaining Options ]] --

submenu("Raid Control", "RemainingOptions")

-- [[ Settings ]] --

separator("Raid Control", "Settings")

-- [[ Heist Cooldown Reminder ]] --

submenu("Raid Control", "Cooldown")

function timer()
    notify("Count")
    log("Count")
    better_yield(300)
    notify("Count5")
    log("Count5")
    better_yield(300)
    notify("Count10")
    log("Count10")
    better_yield(360)
    notify("Count15")
    log("Count15")
    better_yield(2)
    notify("CountOver")
    log("CountOver")
end

button(
    "Cooldown",
    "Reminder for Cayo Perico Heist",
    function()
        timer()
    end
)

button(
    "Cooldown",
    "Reminder for Diamond Casino Heist",
    function()
        timer()
    end
)

button(
    "Cooldown",
    "Reminder for Doomsday Heist",
    function()
        timer()
    end
)

button(
    "Cooldown",
    "Reminder for Classic Heists",
    function()
        timer()
    end
)

button(
    "Cooldown",
    "Reminder for LS Robbery (Contracts)",
    function()
        timer()
    end
)

button(
    "Raid Control",
    "SafeCheck",
    "SafeBio",
    function()
        if
            STAT_GET_BOOL("MPPLY_IS_HIGH_EARNER") or STAT_GET_BOOL("MPPLY_IS_CHEATER") or
                STAT_GET_BOOL("MPPLY_IS_CHEATER")
         then
            notify(trsl("FlgCh"))
        else
            notify(trsl("NoCh"))
        end
    end
)

button(
    "Raid Control",
    "Web",
    function()
        os.execute("start http://raid-control.great-site.net/")
    end
)

button(
    "Raid Control",
    "Credits",
    function()
        notify("X-Man, Senpai Ari, Phobos, jhowkNx, IceDoomfist, Legion")
    end
)

-- [[ Lua Start ]] --

local ch0, ch1 = STAT_GET_INT("IH_SUB_OWNED")
if ch0 ~= 0 then
else
    if ch1 ~= 0 then
    else
        if ch0 == 0 and ch1 == 0 then
            notify("Warn", 20000)
        end
    end
end

if not MISC.FILE_EXISTS("C:\\X-Folder\\lua\\raidlib\\translation.xtr") then
    notify("Can't load Translation, file is missing!", 15000)
    log("\nCan't load Translation, file is missing!")
else
    log("")
    g_translation.load("C:\\X-Folder\\lua\\raidlib\\translation.xtr")
end

local user = PLAYER.PLAYER_ID()
--PLAYER.PLAYER_PED_ID()
local welply = PLAYER.GET_PLAYER_NAME(user)
notify(welply .. ", welcome to Raid Control :)", 8000)
log(welply .. ", welcome to Raid Control :)")

AUDIO.PLAY_SOUND(-1, "FocusIn", "HintCamSounds", false, 0, true)

--[[
_   _ _____ ___ ____ _____ ____  
| | | | ____|_ _/ ___|_   _/ ___| 
| |_| |  _|  | |\___ \ | | \___ \ 
|  _  | |___ | | ___) || |  ___) |
|_| |_|_____|___|____/ |_| |____/                                                                         
]]
--- [[ Cayo Perico Heist ]] ---

-- [[ Cayo Teleports ]] --

separator("CayoPericoHeist", "CayoTp")

-- [[ Quick Access ]] --

submenu("CayoPericoHeist", "Quick")

button(
    "Quick",
    "Board",
    "QuickBio",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 1561.224, 386.659, -49.685)
    end
)

button(
    "Quick",
    "Deck",
    "QuickBio",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 1563.218, 406.030, -49.667)
    end
)

button(
    "Quick",
    "Tunnel",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        local coords = ENTITY.GET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID())
        if PED.IS_PED_IN_ANY_VEHICLE(PLAYER.GET_PLAYER_PED(g_util.get_selected_player())) then
            if PED.IS_PED_IN_ANY_VEHICLE(ped) then
                local veh = PED.GET_VEHICLE_PED_IS_USING(ped)
                NETWORK.REQUEST_CONTROL_OF_ENTITY(veh)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 5044.726, -5816.164, -11.213)
            end
        end
        if not PED.IS_PED_IN_ANY_VEHICLE(PLAYER.GET_PLAYER_PED(g_util.get_selected_player())) then
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 5044.726, -5816.164, -11.213)
        end
    end
)

button(
    "Quick",
    "Tunnel2",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 5054.630, -5771.519, -4.807)
    end
)

button(
    "Quick",
    "MainT",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 5006.896, -5755.963, 15.487)
    end
)

button(
    "Quick",
    "Sec1",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 5001.196, -5747.470, 14.840)
    end
)

button(
    "Quick",
    "Sec2",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 5028.322, -5734.827, 17.865)
    end
)

button(
    "Quick",
    "Sec3",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 5084.066, -5757.433, 15.829)
    end
)

button(
    "Quick",
    "Sec4",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 5010.181, -5785.030, 17.831)
    end
)

button(
    "Quick",
    "Vault",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 5010.753, -5757.639, 28.845)
    end
)

button(
    "Quick",
    "Reduct",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 4992.854, -5718.537, 19.880)
    end
)

button(
    "Quick",
    "Ocean",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        local coords = ENTITY.GET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID())
        if PED.IS_PED_IN_ANY_VEHICLE(PLAYER.GET_PLAYER_PED(g_util.get_selected_player())) then
            if PED.IS_PED_IN_ANY_VEHICLE(ped) then
                local veh = PED.GET_VEHICLE_PED_IS_USING(ped)
                NETWORK.REQUEST_CONTROL_OF_ENTITY(veh)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(veh, 4771.792, -6166.055, -40.266)
            end
        end
        if not PED.IS_PED_IN_ANY_VEHICLE(PLAYER.GET_PLAYER_PED(g_util.get_selected_player())) then
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 4771.792, -6166.055, -40.266)
        end
    end
)

-- [[ Mansion ]] --

submenu("CayoPericoHeist", "Mansion")

button(
    "Mansion",
    "OutEn",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 5047.394, -5820.962, -12.447)
    end
)

button(
    "Mansion",
    "OutMain",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 4972.337, -5701.617, 19.887)
    end
)

button(
    "Mansion",
    "OutGrap",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 5041.111, -5675.523, 19.292)
    end
)

button(
    "Mansion",
    "OutNEn",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 5086.59, -5730.8, 15.773)
    end
)

button(
    "Mansion",
    "OutSGrap",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 4987.32, -5819.869, 19.548)
    end
)

button(
    "Mansion",
    "OutSDoorEn",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 4958.965, -5785.213, 20.839)
    end
)

-- [[ Airfield ]] --

submenu("CayoPericoHeist", "Airfield")

button(
    "Airfield",
    "CoTo",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 4374.47, -4577.694, 4.208)
    end
)

button(
    "Airfield",
    "PoSt",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 4478.387, -4591.498, 5.568)
    end
)

button(
    "Airfield",
    "AirEx",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 4493.552, -4472.608, 4.212)
    end
)

button(
    "Airfield",
    "HangLow",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 4437.678, -4449.029, 4.328)
    end
)

button(
    "Airfield",
    "HangUp",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 4445.451, -4444.368, 7.237)
    end
)

button(
    "Airfield",
    "LootOth",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 4503.399, -4552.043, 4.161)
    end
)

-- [[ North Dock ]] --

submenu("CayoPericoHeist", "NDock")

button(
    "NDock",
    "SaPlace",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 5064.167, -4587.988, 2.988)
    end
)

button(
    "NDock",
    "LoBl1",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 5065.108, -4592.708, 2.855)
    end
)

button(
    "NDock",
    "LoBl2",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 5134.84, -4609.992, 2.529)
    end
)

button(
    "NDock",
    "LoBl3",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 5090.356, -4682.487, 2.407)
    end
)

-- [[ Main Dock ]] --

submenu("CayoPericoHeist", "MDock")

button(
    "MDock",
    "SaPlace",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 4847.7, -5325.062, 15.017)
    end
)

button(
    "MDock",
    "LoBl1",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 4923.587, -5242.541, 2.523)
    end
)

button(
    "MDock",
    "LoBl2",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 4998.355, -5165.41, 2.764)
    end
)

button(
    "MDock",
    "LoBl3",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 4961.247, -5109.312, 2.982)
    end
)

-- [[ Communication Tower ]] --

submenu("CayoPericoHeist", "ComTow")

button(
    "ComTow",
    "Base",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 5270.362, -5422.213, 65.579)
    end
)

button(
    "ComTow",
    "Level1",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 5262.419, -5428.451, 90.724)
    end
)

button(
    "ComTow",
    "Level2",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 5263.550, -5428.477, 109.148)
    end
)

button(
    "ComTow",
    "Level3Top",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 5266.207, -5427.754, 141.047)
    end
)

-- [[ Exits ]] --

submenu("CayoPericoHeist", "Exits")

button(
    "Exits",
    "MaExMain",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 4986.727, -5723.624, 19.88)
    end
)

button(
    "Exits",
    "MaExNGrapl",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 5024.82, -5682.374, 19.877)
    end
)

button(
    "Exits",
    "MaExSGrapl",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 4998.833, -5801.947, 20.877)
    end
)

button(
    "Exits",
    "MaExNDoor",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 5084.957, -5739.043, 15.677)
    end
)

button(
    "Exits",
    "MaExSDoor",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 4967.008, -5783.731, 20.878)
    end
)

-- [[ Chests ]] --

submenu("CayoPericoHeist", "Chests")

input(
    "Chests",
    "Land",
    0,
    1,
    10,
    function(tpl)
        local ped = PLAYER.PLAYER_PED_ID()
        if (tpl == 1) then
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 5176.394, -4678.343, 2.427)
        end
        if (tpl == 2) then
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 4855.533, -5561.123, 27.534)
        end
        if (tpl == 3) then
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 4877.224, -4781.618, 2.068)
        end
        if (tpl == 4) then
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 5591.956, -5215.923, 14.351)
        end
        if (tpl == 5) then
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 5458.669, -5860.041, 19.973)
        end
        if (tpl == 6) then
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 4855.781, -5163.507, 2.439)
        end
        if (tpl == 7) then
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 3898.093, -4710.935, 4.771)
        end
        if (tpl == 8) then
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 4822.828, -4322.015, 5.617)
        end
        if (tpl == 9) then
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 4535.064, -4702.882, 2.431)
        end
        if (tpl == 10) then
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 4179.426, -4358.279, 2.686)
        end
    end
)

input(
    "Chests",
    "Ocean",
    0,
    1,
    9,
    function(tpo)
        local ped = PLAYER.PLAYER_PED_ID()
        if (tpo == 1) then
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 4415.093, -4653.384, -4.172)
        end
        if (tpo == 2) then
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 4560.742, -4355.47, -7.187)
        end
        if (tpo == 3) then
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 5262.87, -4919.246, -1.878)
        end
        if (tpo == 4) then
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 4561.338, -4768.874, -2.167)
        end
        if (tpo == 5) then
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 4943.188, -4294.895, -5.481)
        end
        if (tpo == 6) then
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 5599.706, -5604.149, -5.064)
        end
        if (tpo == 7) then
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 3982.371, -4542.297, -5.194)
        end
        if (tpo == 8) then
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 4775.263, -5394.031, -4.116)
        end
        if (tpo == 9) then
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 4940.111, -5167.373, -2.564)
        end
    end
)

-- [[ Remaining ]] --

submenu("CayoPericoHeist", "Remaining")

button(
    "Remaining",
    "WeFie",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 5331.424, -5269.504, 33.186)
    end
)

button(
    "Remaining",
    "ArLo",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 5193.133, -5134.256, 3.345)
    end
)

-- [[ Cayo Perico Presets ]] --

separator("CayoPericoHeist", "CayoPreSep")

toggle(
    "CayoPericoHeist",
    "CayoQuick",
    false,
    "CayoQuickBio",
    function(on)
        quickcp = on
        while quickcp do
            SYSTEM.WAIT(100)
            if NETWORK then
                STAT_SET_INT("PROSTITUTES_FREQUENTE", 100)
                STAT_SET_INT("H4CNF_BS_GEN", 262143)
                STAT_SET_INT("H4CNF_BS_ENTR", 63)
                STAT_SET_INT("H4CNF_BS_ABIL", 63)
                STAT_SET_INT("H4CNF_WEP_DISRP", 3)
                STAT_SET_INT("H4CNF_ARM_DISRP", 3)
                STAT_SET_INT("H4CNF_HEL_DISRP", 3)
                STAT_SET_INT("H4CNF_BOLTCUT", 4424)
                STAT_SET_INT("H4CNF_UNIFORM", 5256)
                STAT_SET_INT("H4CNF_GRAPPEL", 5156)
                STAT_SET_INT("H4CNF_APPROACH", 0xFFFFFFF)
                STAT_SET_INT("H4LOOT_CASH_I", 0)
                STAT_SET_INT("H4LOOT_CASH_C", 0)
                STAT_SET_INT("H4LOOT_WEED_I", 0)
                STAT_SET_INT("H4LOOT_WEED_C", 0)
                STAT_SET_INT("H4LOOT_COKE_I", 0)
                STAT_SET_INT("H4LOOT_COKE_C", 0)
                STAT_SET_INT("H4LOOT_GOLD_I", 0)
                STAT_SET_INT("H4LOOT_GOLD_C", 0)
                STAT_SET_INT("H4LOOT_PAINT", 0)
                STAT_SET_INT("H4LOOT_CASH_V", 0)
                STAT_SET_INT("H4LOOT_COKE_V", 0)
                STAT_SET_INT("H4LOOT_GOLD_V", 0)
                STAT_SET_INT("H4LOOT_PAINT_V", 0)
                STAT_SET_INT("H4LOOT_WEED_V", 0)
                STAT_SET_INT("H4LOOT_CASH_I_SCOPED", 0)
                STAT_SET_INT("H4LOOT_CASH_C_SCOPED", 0)
                STAT_SET_INT("H4LOOT_WEED_I_SCOPED", 0)
                STAT_SET_INT("H4LOOT_WEED_C_SCOPED", 0)
                STAT_SET_INT("H4LOOT_COKE_I_SCOPED", 0)
                STAT_SET_INT("H4LOOT_COKE_C_SCOPED", 0)
                STAT_SET_INT("H4LOOT_GOLD_I_SCOPED", 0)
                STAT_SET_INT("H4LOOT_GOLD_C_SCOPED", 0)
                STAT_SET_INT("H4LOOT_PAINT_SCOPED", 0)
                STAT_SET_INT("H4CNF_TARGET", 5)
                STAT_SET_INT("H4CNF_WEAPONS", 1)
                STAT_SET_INT("H4_MISSIONS", 65283)
                STAT_SET_INT("H4_PROGRESS", 126823)
                STAT_SET_INT("H4_PLAYTHROUGH_STATUS", 5)
                -- INT
                SCRIPT.SET_GLOBAL_I(1974201, 100)
                SCRIPT.SET_GLOBAL_I(1974202, 145)
                SCRIPT.SET_GLOBAL_I(1974203, 145)
                SCRIPT.SET_GLOBAL_I(1974204, 145)
                SCRIPT.SET_GLOBAL_F(292124, 0.0)
                SCRIPT.SET_GLOBAL_F(292125, 0.0)
            -- GLOBAL
            end
        end
    end
)

toggle(
    "CayoPericoHeist",
    "CayoSolo",
    false,
    "CayoBio4",
    function(on)
        cp1 = on
        while cp1 do
            SYSTEM.WAIT(100)
            if NETWORK then
                STAT_SET_INT("PROSTITUTES_FREQUENTE", 100)
                STAT_SET_INT("H4CNF_BOLTCUT", 0xFFFFFFF)
                STAT_SET_INT("H4CNF_UNIFORM", 0xFFFFFFF)
                STAT_SET_INT("H4CNF_GRAPPEL", 0xFFFFFFF)
                STAT_SET_INT("H4_MISSIONS", 0xFFFFFFF)
                STAT_SET_INT("H4CNF_WEAPONS", 1)
                STAT_SET_INT("H4CNF_TROJAN", 5)
                STAT_SET_INT("H4_PLAYTHROUGH_STATUS", 100)
                STAT_SET_INT("H4CNF_TARGET", 5)
                STAT_SET_INT("H4LOOT_CASH_I", 5551206)
                STAT_SET_INT("H4LOOT_CASH_I_SCOPED", 5551206)
                STAT_SET_INT("H4LOOT_CASH_C", 0)
                STAT_SET_INT("H4LOOT_CASH_C_SCOPED", 0)
                STAT_SET_INT("H4LOOT_COKE_I", 4884838)
                STAT_SET_INT("H4LOOT_COKE_I_SCOPED", 4884838)
                STAT_SET_INT("H4LOOT_COKE_C", 0)
                STAT_SET_INT("H4LOOT_COKE_C_SCOPED", 0)
                STAT_SET_INT("H4LOOT_GOLD_I", 0)
                STAT_SET_INT("H4LOOT_GOLD_I_SCOPED", 0)
                STAT_SET_INT("H4LOOT_GOLD_C", 192)
                STAT_SET_INT("H4LOOT_GOLD_C_SCOPED", 192)
                STAT_SET_INT("H4LOOT_WEED_I", 0)
                STAT_SET_INT("H4LOOT_WEED_I_SCOPED", 0)
                STAT_SET_INT("H4LOOT_WEED_C", 0)
                STAT_SET_INT("H4LOOT_WEED_C_SCOPED", 0)
                STAT_SET_INT("H4LOOT_PAINT", 120)
                STAT_SET_INT("H4LOOT_PAINT_SCOPED", 120)
                STAT_SET_INT("H4LOOT_CASH_V", 224431)
                STAT_SET_INT("H4LOOT_COKE_V", 353863)
                STAT_SET_INT("H4LOOT_GOLD_V", 471817)
                STAT_SET_INT("H4LOOT_PAINT_V", 353863)
                STAT_SET_INT("H4LOOT_WEED_V", 0)
                STAT_SET_INT("H4_PROGRESS", 131055)
                STAT_SET_INT("H4CNF_BS_GEN", 0xFFFFFFF)
                STAT_SET_INT("H4CNF_BS_ENTR", 0xFFFFFFF)
                STAT_SET_INT("H4CNF_BS_ABIL", 0xFFFFFFF)
                STAT_SET_INT("H4CNF_WEP_DISRP", 3)
                STAT_SET_INT("H4CNF_ARM_DISRP", 3)
                STAT_SET_INT("H4CNF_HEL_DISRP", 3)
                STAT_SET_INT("H4CNF_APPROACH", 0xFFFFFFF)
                -- INT
                SCRIPT.SET_GLOBAL_I(1974201, 100)
                SCRIPT.SET_GLOBAL_I(291865, 1800)
                SCRIPT.SET_GLOBAL_F(292124, -0.1)
                SCRIPT.SET_GLOBAL_F(292125, -0.02)
            -- GLOBAL
            end
        end
    end
)

toggle(
    "CayoPericoHeist",
    "CayoDuo",
    false,
    "CayoBio4",
    function(on)
        cp2 = on
        while cp2 do
            SYSTEM.WAIT(100)
            if NETWORK then
                STAT_SET_INT("PROSTITUTES_FREQUENTE", 100)
                STAT_SET_INT("H4CNF_BOLTCUT", 4424)
                STAT_SET_INT("H4CNF_UNIFORM", 5256)
                STAT_SET_INT("H4CNF_GRAPPEL", 5156)
                STAT_SET_INT("H4_MISSIONS", 0xFFFFFFF)
                STAT_SET_INT("H4CNF_WEAPONS", 1)
                STAT_SET_INT("H4CNF_TROJAN", 5)
                STAT_SET_INT("H4_PLAYTHROUGH_STATUS", 100)
                STAT_SET_INT("H4CNF_TARGET", 5)
                STAT_SET_INT("H4LOOT_CASH_I", 2359448)
                STAT_SET_INT("H4LOOT_CASH_I_SCOPED", 2359448)
                STAT_SET_INT("H4LOOT_CASH_C", 0)
                STAT_SET_INT("H4LOOT_CASH_C_SCOPED", 0)
                STAT_SET_INT("H4LOOT_COKE_I", 2)
                STAT_SET_INT("H4LOOT_COKE_I_SCOPED", 2)
                STAT_SET_INT("H4LOOT_COKE_C", 0)
                STAT_SET_INT("H4LOOT_COKE_C_SCOPED", 0)
                STAT_SET_INT("H4LOOT_GOLD_I", 0)
                STAT_SET_INT("H4LOOT_GOLD_I_SCOPED", 0)
                STAT_SET_INT("H4LOOT_GOLD_C", 255)
                STAT_SET_INT("H4LOOT_GOLD_C_SCOPED", 255)
                STAT_SET_INT("H4LOOT_WEED_I", 0)
                STAT_SET_INT("H4LOOT_WEED_I_SCOPED", 0)
                STAT_SET_INT("H4LOOT_WEED_C", 0)
                STAT_SET_INT("H4LOOT_WEED_C_SCOPED", 0)
                STAT_SET_INT("H4LOOT_PAINT", 127)
                STAT_SET_INT("H4LOOT_PAINT_SCOPED", 127)
                STAT_SET_INT("H4LOOT_CASH_V", 474431)
                STAT_SET_INT("H4LOOT_COKE_V", 948863)
                STAT_SET_INT("H4LOOT_GOLD_V", 1265151)
                STAT_SET_INT("H4LOOT_PAINT_V", 948863)
                STAT_SET_INT("H4LOOT_WEED_V", 0)
                STAT_SET_INT("H4_PROGRESS", 126823)
                STAT_SET_INT("H4CNF_BS_GEN", 262143)
                STAT_SET_INT("H4CNF_BS_ENTR", 63)
                STAT_SET_INT("H4CNF_BS_ABIL", 63)
                STAT_SET_INT("H4CNF_WEP_DISRP", 3)
                STAT_SET_INT("H4CNF_ARM_DISRP", 3)
                STAT_SET_INT("H4CNF_HEL_DISRP", 3)
                STAT_SET_INT("H4CNF_APPROACH", 0xFFFFFFF)
                -- INT
                SCRIPT.SET_GLOBAL_I(1974201, 50)
                SCRIPT.SET_GLOBAL_I(1974202, 50)
                SCRIPT.SET_GLOBAL_I(291865, 1800)
                SCRIPT.SET_GLOBAL_F(292124, -0.1)
                SCRIPT.SET_GLOBAL_F(292125, -0.02)
            -- GLOBAL
            end
        end
    end
)

toggle(
    "CayoPericoHeist",
    "CayoTrio",
    false,
    "CayoBio4",
    function(on)
        cp3 = on
        while cp3 do
            SYSTEM.WAIT(100)
            if NETWORK then
                STAT_SET_INT("PROSTITUTES_FREQUENTE", 100)
                STAT_SET_INT("H4CNF_BOLTCUT", 4424)
                STAT_SET_INT("H4CNF_UNIFORM", 5256)
                STAT_SET_INT("H4CNF_GRAPPEL", 5156)
                STAT_SET_INT("H4_MISSIONS", 0xFFFFFFF)
                STAT_SET_INT("H4CNF_WEAPONS", 1)
                STAT_SET_INT("H4CNF_TROJAN", 5)
                STAT_SET_INT("H4_PLAYTHROUGH_STATUS", 100)
                STAT_SET_INT("H4CNF_TARGET", 5)
                STAT_SET_INT("H4LOOT_CASH_I", 2359448)
                STAT_SET_INT("H4LOOT_CASH_I_SCOPED", 2359448)
                STAT_SET_INT("H4LOOT_CASH_C", 0)
                STAT_SET_INT("H4LOOT_CASH_C_SCOPED", 0)
                STAT_SET_INT("H4LOOT_COKE_I", 4901222)
                STAT_SET_INT("H4LOOT_COKE_I_SCOPED", 4901222)
                STAT_SET_INT("H4LOOT_COKE_C", 0)
                STAT_SET_INT("H4LOOT_COKE_C_SCOPED", 0)
                STAT_SET_INT("H4LOOT_GOLD_I", 0)
                STAT_SET_INT("H4LOOT_GOLD_I_SCOPED", 0)
                STAT_SET_INT("H4LOOT_GOLD_C", 255)
                STAT_SET_INT("H4LOOT_GOLD_C_SCOPED", 255)
                STAT_SET_INT("H4LOOT_WEED_I", 0)
                STAT_SET_INT("H4LOOT_WEED_I_SCOPED", 0)
                STAT_SET_INT("H4LOOT_WEED_C", 0)
                STAT_SET_INT("H4LOOT_WEED_C_SCOPED", 0)
                STAT_SET_INT("H4LOOT_PAINT", 127)
                STAT_SET_INT("H4LOOT_PAINT_SCOPED", 127)
                STAT_SET_INT("H4LOOT_CASH_V", 515151)
                STAT_SET_INT("H4LOOT_COKE_V", 1030303)
                STAT_SET_INT("H4LOOT_GOLD_V", 1373737)
                STAT_SET_INT("H4LOOT_PAINT_V", 1030303)
                STAT_SET_INT("H4LOOT_WEED_V", 0)
                STAT_SET_INT("H4_PROGRESS", 126823)
                STAT_SET_INT("H4CNF_BS_GEN", 262143)
                STAT_SET_INT("H4CNF_BS_ENTR", 63)
                STAT_SET_INT("H4CNF_BS_ABIL", 63)
                STAT_SET_INT("H4CNF_WEP_DISRP", 3)
                STAT_SET_INT("H4CNF_ARM_DISRP", 3)
                STAT_SET_INT("H4CNF_HEL_DISRP", 3)
                STAT_SET_INT("H4CNF_APPROACH", 0xFFFFFFF)
                -- INT
                SCRIPT.SET_GLOBAL_I(1974201, 30)
                SCRIPT.SET_GLOBAL_I(1974202, 35)
                SCRIPT.SET_GLOBAL_I(1974203, 35)
                SCRIPT.SET_GLOBAL_I(291865, 1800)
                SCRIPT.SET_GLOBAL_F(292124, -0.1)
                SCRIPT.SET_GLOBAL_F(292125, -0.02)
            -- GLOBAL
            end
        end
    end
)

toggle(
    "CayoPericoHeist",
    "CayoSquad",
    false,
    "CayoBio4",
    function(on)
        cp4 = on
        while cp4 do
            SYSTEM.WAIT(100)
            if NETWORK then
                STAT_SET_INT("PROSTITUTES_FREQUENTE", 100)
                STAT_SET_INT("H4CNF_TARGET", 5)
                STAT_SET_INT("H4LOOT_CASH_I", 2359448)
                STAT_SET_INT("H4LOOT_CASH_I_SCOPED", 2359448)
                STAT_SET_INT("H4LOOT_CASH_C", 0)
                STAT_SET_INT("H4LOOT_CASH_C_SCOPED", 0)
                STAT_SET_INT("H4LOOT_COKE_I", 4901222)
                STAT_SET_INT("H4LOOT_COKE_I_SCOPED", 4901222)
                STAT_SET_INT("H4LOOT_COKE_C", 0)
                STAT_SET_INT("H4LOOT_COKE_C_SCOPED", 0)
                STAT_SET_INT("H4LOOT_GOLD_I", 0)
                STAT_SET_INT("H4LOOT_GOLD_I_SCOPED", 0)
                STAT_SET_INT("H4LOOT_GOLD_C", 255)
                STAT_SET_INT("H4LOOT_GOLD_C_SCOPED", 255)
                STAT_SET_INT("H4LOOT_WEED_I", 0)
                STAT_SET_INT("H4LOOT_WEED_I_SCOPED", 0)
                STAT_SET_INT("H4LOOT_WEED_C", 0)
                STAT_SET_INT("H4LOOT_WEED_C_SCOPED", 0)
                STAT_SET_INT("H4LOOT_PAINT", 127)
                STAT_SET_INT("H4LOOT_PAINT_SCOPED", 127)
                STAT_SET_INT("H4LOOT_CASH_V", 599431)
                STAT_SET_INT("H4LOOT_COKE_V", 1198863)
                STAT_SET_INT("H4LOOT_GOLD_V", 1598484)
                STAT_SET_INT("H4LOOT_PAINT_V", 1198863)
                STAT_SET_INT("H4LOOT_WEED_V", 0)
                STAT_SET_INT("H4_PROGRESS", 126823)
                STAT_SET_INT("H4CNF_BS_GEN", 262143)
                STAT_SET_INT("H4CNF_BS_ENTR", 63)
                STAT_SET_INT("H4CNF_BS_ABIL", 63)
                STAT_SET_INT("H4CNF_WEP_DISRP", 3)
                STAT_SET_INT("H4CNF_ARM_DISRP", 3)
                STAT_SET_INT("H4CNF_HEL_DISRP", 3)
                STAT_SET_INT("H4CNF_APPROACH", 0xFFFFFFF)
                STAT_SET_INT("H4CNF_BOLTCUT", 4424)
                STAT_SET_INT("H4CNF_UNIFORM", 5256)
                STAT_SET_INT("H4CNF_GRAPPEL", 5156)
                STAT_SET_INT("H4_MISSIONS", 0xFFFFFFF)
                STAT_SET_INT("H4CNF_WEAPONS", 1)
                STAT_SET_INT("H4CNF_TROJAN", 5)
                STAT_SET_INT("H4_PLAYTHROUGH_STATUS", 100)
                -- INT
                SCRIPT.SET_GLOBAL_I(1974201, 25)
                SCRIPT.SET_GLOBAL_I(1974202, 25)
                SCRIPT.SET_GLOBAL_I(1974203, 25)
                SCRIPT.SET_GLOBAL_I(1974204, 25)
                SCRIPT.SET_GLOBAL_I(291865, 1800)
                SCRIPT.SET_GLOBAL_F(292124, -0.1)
                SCRIPT.SET_GLOBAL_F(292125, -0.02)
            -- GLOBAL
            end
        end
    end
)

toggle(
    "CayoPericoHeist",
    "CayoNor",
    false,
    "CayoStd",
    function(on)
        sta = on
        while sta do
            SYSTEM.WAIT(100)
            if NETWORK then
                STAT_SET_INT("PROSTITUTES_FREQUENTE", 100)
                STAT_SET_INT("H4CNF_BS_GEN", 262143)
                STAT_SET_INT("H4CNF_BS_ENTR", 63)
                STAT_SET_INT("H4CNF_BS_ABIL", 63)
                STAT_SET_INT("H4CNF_WEP_DISRP", 3)
                STAT_SET_INT("H4CNF_ARM_DISRP", 3)
                STAT_SET_INT("H4CNF_HEL_DISRP", 3)
                STAT_SET_INT("H4CNF_BOLTCUT", 4424)
                STAT_SET_INT("H4CNF_UNIFORM", 5256)
                STAT_SET_INT("H4CNF_GRAPPEL", 5156)
                STAT_SET_INT("H4CNF_APPROACH", 0xFFFFFFF)
                STAT_SET_INT("H4LOOT_CASH_I", 1089792)
                STAT_SET_INT("H4LOOT_CASH_C", 0)
                STAT_SET_INT("H4LOOT_WEED_I", 9114214)
                STAT_SET_INT("H4LOOT_WEED_C", 37)
                STAT_SET_INT("H4LOOT_COKE_I", 6573209)
                STAT_SET_INT("H4LOOT_COKE_C", 26)
                STAT_SET_INT("H4LOOT_GOLD_I", 0)
                STAT_SET_INT("H4LOOT_GOLD_C", 192)
                STAT_SET_INT("H4LOOT_PAINT", 127)
                STAT_SET_INT("H4_PROGRESS", 124271)
                STAT_SET_INT("H4LOOT_CASH_V", 22500)
                STAT_SET_INT("H4LOOT_COKE_V", 55023)
                STAT_SET_INT("H4LOOT_GOLD_V", 83046)
                STAT_SET_INT("H4LOOT_PAINT_V", 47375)
                STAT_SET_INT("H4LOOT_WEED_V", 36967)
                STAT_SET_INT("H4LOOT_CASH_I_SCOPED", 1089792)
                STAT_SET_INT("H4LOOT_CASH_C_SCOPED", 0)
                STAT_SET_INT("H4LOOT_WEED_I_SCOPED", 9114214)
                STAT_SET_INT("H4LOOT_WEED_C_SCOPED", 37)
                STAT_SET_INT("H4LOOT_COKE_I_SCOPED", 6573209)
                STAT_SET_INT("H4LOOT_COKE_C_SCOPED", 26)
                STAT_SET_INT("H4LOOT_GOLD_I_SCOPED", 0)
                STAT_SET_INT("H4LOOT_GOLD_C_SCOPED", 192)
                STAT_SET_INT("H4LOOT_PAINT_SCOPED", 127)
                STAT_SET_INT("H4_MISSIONS", 0xFFFFFFF)
                STAT_SET_INT("H4_PLAYTHROUGH_STATUS", 5)
                -- INT
                STAT_SET_INT("H4CNF_TARGET", math.random(1, 5))
                STAT_SET_INT("H4CNF_WEAPONS", math.random(1, 5))
                -- INT RANDOM
            end
        end
    end
)

toggle(
    "CayoPericoHeist",
    "NoLim",
    false,
    "CayoNoLimit",
    function(on)
        nol = on
        while nol do
            SYSTEM.WAIT(100)
            if NETWORK then
                STAT_SET_INT("PROSTITUTES_FREQUENTE", 100)
                STAT_SET_INT("H4CNF_BS_GEN", 262143)
                STAT_SET_INT("H4CNF_BS_ENTR", 63)
                STAT_SET_INT("H4CNF_BS_ABIL", 63)
                STAT_SET_INT("H4CNF_WEP_DISRP", 3)
                STAT_SET_INT("H4CNF_ARM_DISRP", 3)
                STAT_SET_INT("H4CNF_HEL_DISRP", 3)
                STAT_SET_INT("H4CNF_BOLTCUT", 4424)
                STAT_SET_INT("H4CNF_UNIFORM", 5256)
                STAT_SET_INT("H4CNF_GRAPPEL", 5156)
                STAT_SET_INT("H4CNF_APPROACH", 0xFFFFFFF)
                STAT_SET_INT("H4LOOT_CASH_I", 1089792)
                STAT_SET_INT("H4LOOT_CASH_C", 0)
                STAT_SET_INT("H4LOOT_WEED_I", 9114214)
                STAT_SET_INT("H4LOOT_WEED_C", 37)
                STAT_SET_INT("H4LOOT_COKE_I", 6573209)
                STAT_SET_INT("H4LOOT_COKE_C", 26)
                STAT_SET_INT("H4LOOT_GOLD_I", 0)
                STAT_SET_INT("H4LOOT_GOLD_C", 192)
                STAT_SET_INT("H4LOOT_PAINT", 127)
                STAT_SET_INT("H4_PROGRESS", 124271)
                STAT_SET_INT("H4LOOT_CASH_V", 22500)
                STAT_SET_INT("H4LOOT_COKE_V", 55023)
                STAT_SET_INT("H4LOOT_GOLD_V", 83046)
                STAT_SET_INT("H4LOOT_PAINT_V", 47375)
                STAT_SET_INT("H4LOOT_WEED_V", 36967)
                STAT_SET_INT("H4LOOT_CASH_I_SCOPED", 1089792)
                STAT_SET_INT("H4LOOT_CASH_C_SCOPED", 0)
                STAT_SET_INT("H4LOOT_WEED_I_SCOPED", 9114214)
                STAT_SET_INT("H4LOOT_WEED_C_SCOPED", 37)
                STAT_SET_INT("H4LOOT_COKE_I_SCOPED", 6573209)
                STAT_SET_INT("H4LOOT_COKE_C_SCOPED", 26)
                STAT_SET_INT("H4LOOT_GOLD_I_SCOPED", 0)
                STAT_SET_INT("H4LOOT_GOLD_C_SCOPED", 192)
                STAT_SET_INT("H4LOOT_PAINT_SCOPED", 127)
                STAT_SET_INT("H4_MISSIONS", 0xFFFFFFF)
                STAT_SET_INT("H4_PLAYTHROUGH_STATUS", 5)
                STAT_SET_INT("H4CNF_TARGET", 5)
                STAT_SET_INT("H4CNF_WEAPONS", 1)
            -- INT
            end
        end
    end
)

button(
    "CayoPericoHeist",
    "CayoRe",
    function()
        if NETWORK then
            STAT_SET_INT("H4_MISSIONS", 0)
            STAT_SET_INT("H4_PROGRESS", 0)
            STAT_SET_INT("H4CNF_APPROACH", 0)
            STAT_SET_INT("H4CNF_BS_ENTR", 0)
            STAT_SET_INT("H4CNF_BS_GEN", 0)
            STAT_SET_INT("H4_PLAYTHROUGH_STATUS", 2)
        end
    end
)

-- [[ Cayo Advanced ]] --

separator("CayoPericoHeist", "CayoAdv")

-- [[ Player Cut Manager ]] --

submenu("CayoPericoHeist", "PlCuMan")

-- [[ Cayo Cut ]] --

separator("PlCuMan", "CayoCut")

input(
    "PlCuMan",
    "pl1",
    0,
    0,
    1000,
    function(cut1)
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(1974201, cut1)
        end
    end
)

input(
    "PlCuMan",
    "pl2",
    0,
    0,
    1000,
    function(cut2)
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(1974202, cut2)
        end
    end
)

input(
    "PlCuMan",
    "pl3",
    0,
    0,
    1000,
    function(cut3)
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(1974203, cut3)
        end
    end
)

input(
    "PlCuMan",
    "pl4",
    0,
    0,
    1000,
    function(cut4)
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(1974204, cut4)
        end
    end
)

-- [[ Cayo Bag Editor ]] --

submenu("CayoPericoHeist", "CayoBagEditor")

input(
    "CayoBagEditor",
    "CuBag",
    0,
    0,
    9999999,
    function(cus)
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(291865, cus)
        end
    end
)

-- [[ Change Cayo Loot Price ]] --

submenu("CayoPericoHeist", "LootPrice")

input(
    "LootPrice",
    "Cash",
    0,
    0,
    9999999,
    function(prc)
        if NETWORK then
            STAT_SET_INT("H4LOOT_CASH_V", prc)
        end
    end
)

input(
    "LootPrice",
    "Weed",
    0,
    0,
    9999999,
    function(prw)
        if NETWORK then
            STAT_SET_INT("H4LOOT_WEED_V", prw)
        end
    end
)

input(
    "LootPrice",
    "Coke",
    0,
    0,
    9999999,
    function(prco)
        if NETWORK then
            STAT_SET_INT("H4LOOT_COKE_V", prco)
        end
    end
)

input(
    "LootPrice",
    "Gold",
    0,
    0,
    9999999,
    function(prg)
        if NETWORK then
            STAT_SET_INT("H4LOOT_GOLD_V", prg)
        end
    end
)

input(
    "LootPrice",
    "Paint",
    0,
    0,
    99999999,
    function(prp)
        if NETWORK then
            STAT_SET_INT("H4LOOT_PAINT_V", prp)
        end
    end
)

-- [[ Change Main Target Price ]] --

submenu("CayoPericoHeist", "MainLootPrice")

input(
    "MainLootPrice",
    "PaSt",
    0,
    0,
    9999999,
    function(past)
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(292120, past)
        end
    end
)

input(
    "MainLootPrice",
    "PiDia",
    0,
    0,
    9999999,
    function(pidia)
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(292118, pidia)
        end
    end
)

input(
    "MainLootPrice",
    "BeBo",
    0,
    0,
    9999999,
    function(bebo)
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(292117, bebo)
        end
    end
)

input(
    "MainLootPrice",
    "RubyNeck",
    0,
    0,
    9999999,
    function(rubyneck)
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(292116, rubyneck)
        end
    end
)

input(
    "MainLootPrice",
    "Teq",
    0,
    0,
    9999999,
    function(teq)
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(50000, teq)
        end
    end
)

function stats()
    STAT_SET_INT("PROSTITUTES_FREQUENTE", 100)
    STAT_SET_INT("H4CNF_BS_GEN", 131071)
    STAT_SET_INT("H4CNF_BS_ENTR", 63)
    STAT_SET_INT("H4CNF_BS_ABIL", 63)
    STAT_SET_INT("H4CNF_WEAPONS", 5)
    STAT_SET_INT("H4CNF_WEP_DISRP", 3)
    STAT_SET_INT("H4CNF_ARM_DISRP", 3)
    STAT_SET_INT("H4CNF_HEL_DISRP", 3)
    STAT_SET_INT("H4CNF_TARGET", 5)
    STAT_SET_INT("H4CNF_TROJAN", 2)
    STAT_SET_INT("H4CNF_APPROACH", -1)
    STAT_SET_INT("H4LOOT_CASH_I", 0)
    STAT_SET_INT("H4LOOT_CASH_C", 0)
    STAT_SET_INT("H4LOOT_WEED_I", 0)
    STAT_SET_INT("H4LOOT_WEED_C", 0)
    STAT_SET_INT("H4LOOT_COKE_I", 0)
    STAT_SET_INT("H4LOOT_COKE_C", 0)
    STAT_SET_INT("H4LOOT_GOLD_I", -1)
    STAT_SET_INT("H4LOOT_GOLD_C", -1)
    STAT_SET_INT("H4LOOT_PAINT", -1)
    STAT_SET_INT("H4_PROGRESS", 126823)
    STAT_SET_INT("H4LOOT_CASH_I_SCOPED", 0)
    STAT_SET_INT("H4LOOT_CASH_C_SCOPED", 0)
    STAT_SET_INT("H4LOOT_WEED_I_SCOPED", 0)
    STAT_SET_INT("H4LOOT_WEED_C_SCOPED", 0)
    STAT_SET_INT("H4LOOT_COKE_I_SCOPED", 0)
    STAT_SET_INT("H4LOOT_COKE_C_SCOPED", 0)
    STAT_SET_INT("H4LOOT_GOLD_I_SCOPED", -1)
    STAT_SET_INT("H4LOOT_GOLD_C_SCOPED", -1)
    STAT_SET_INT("H4LOOT_PAINT_SCOPED", -1)
    STAT_SET_INT("H4_MISSIONS", 65535)
    STAT_SET_INT("H4_PLAYTHROUGH_STATUS", 40000)
end

function menu1()
    CONTROL.SET_CONTROL_NORMAL(0, 206, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 206, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 218, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 201, 1)

    while SCRIPT.GET_GLOBAL_I(1837281) ~= 1 do
        better_yield(1)
    end

    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 188, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 201, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 188, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 201, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(2, 201, 1)
    better_yield(1)
end

function menu2(bool)
    CONTROL.SET_CONTROL_NORMAL(0, 201, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 187, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 187, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 201, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 205, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 206, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 187, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 201, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 201, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 205, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 206, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 187, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 187, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 201, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 201, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 205, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 206, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 187, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 187, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 187, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 201, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 201, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 205, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 206, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 187, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 187, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 187, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 187, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 201, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 201, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 205, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 206, 1)
    better_yield(1)

    SCRIPT.SET_GLOBAL_I(1974201, 100)
    SCRIPT.SET_GLOBAL_I(1974202, 0)
    SCRIPT.SET_GLOBAL_I(1974203, 0)
    SCRIPT.SET_GLOBAL_I(1974204, 0)

    if bool then
        SCRIPT.SET_GLOBAL_I(1974201, 150)
        SCRIPT.SET_GLOBAL_I(1974202, 150)
        SCRIPT.SET_GLOBAL_I(1974203, 150)
        SCRIPT.SET_GLOBAL_I(1974204, 150)
    end

    CONTROL.SET_CONTROL_NORMAL(0, 218, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 201, 1)
    better_yield(1)

    while SCRIPT.GET_GLOBAL_I(1835497) ~= 1 do
        better_yield(1)
    end

    better_yield(1)

    CONTROL.SET_CONTROL_NORMAL(0, 188, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 201, 1)
    better_yield(1)
end

function menu2b(bool)
    CONTROL.SET_CONTROL_NORMAL(0, 201, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 201, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 205, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 206, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 187, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 201, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 187, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 187, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 187, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 201, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 205, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 206, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 187, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 187, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 201, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 201, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 205, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 206, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 187, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 187, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 187, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 201, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 201, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 205, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 206, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 187, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 187, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 187, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 187, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 201, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 201, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 205, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 206, 1)
    better_yield(1)

    SCRIPT.SET_GLOBAL_I(1974201, 100)
    SCRIPT.SET_GLOBAL_I(1974202, 0)
    SCRIPT.SET_GLOBAL_I(1974203, 0)
    SCRIPT.SET_GLOBAL_I(1974204, 0)

    if bool then
        SCRIPT.SET_GLOBAL_I(1974201, 150)
        SCRIPT.SET_GLOBAL_I(1974202, 150)
        SCRIPT.SET_GLOBAL_I(1974203, 150)
        SCRIPT.SET_GLOBAL_I(1974204, 150)
    end

    CONTROL.SET_CONTROL_NORMAL(0, 218, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 201, 1)
    better_yield(1)

    while SCRIPT.GET_GLOBAL_I(1835497) ~= 1 do
        better_yield(1)
    end

    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 188, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(0, 201, 1)
    better_yield(1)
end

function mission()
    CUTSCENE.STOP_CUTSCENE_IMMEDIATELY()

    better_yield(5)

    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PLAYER.PLAYER_PED_ID(), 4979.253, -5709.971, 20.374)

    better_yield(2)

    CONTROL.SET_CONTROL_NORMAL(0, 51, 1)

    better_yield(11)

    CUTSCENE.STOP_CUTSCENE_IMMEDIATELY()

    better_yield(5)

    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PLAYER.PLAYER_PED_ID(), 5010.407, -5755.905, 15.55)

    better_yield(2)

    while not SCRIPT.IS_SCRIPT_LOADED(g_util.joaat("fm_mission_controller_2020")) do
        better_yield(1)
        if loop then
            break
        end
    end

    better_yield(1)

    SCRIPT.SET_LOCAL_F(g_util.joaat("fm_mission_controller_2020"), 28736 + 3, 100)

    SCRIPT.SET_LOCAL_I(g_util.joaat("fm_mission_controller_2020"), 28268, 2)

    while SCRIPT.GET_LOCAL_I(g_util.joaat("fm_mission_controller_2020"), 28268) ~= 0 do
        better_yield(1)
    end

    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PLAYER.PLAYER_PED_ID(), 4992.341, -5719.833, 19.87)

    better_yield(2)

    CONTROL.SET_CONTROL_NORMAL(0, 51, 1)

    better_yield(25)

    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PLAYER.PLAYER_PED_ID(), 4397.290, -4380.540, 8.70)
    better_yield(2)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PLAYER.PLAYER_PED_ID(), 7999.764, -5749.864, 2.84)
    better_yield(1)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PLAYER.PLAYER_PED_ID(), 4397.290, -4380.540, 8.70)
    better_yield(1)
end

function missionb()
    CUTSCENE.STOP_CUTSCENE_IMMEDIATELY()

    better_yield(3)

    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PLAYER.PLAYER_PED_ID(), 5044.726, -5816.164, -11.213)

    better_yield(1)

    local grill = 2997331308

    for i = 0, POOL.GET_OBJECT_COUNT() do
        local door = POOL.GET_OBJECT_AT_INDEX(i)
        local entry = ENTITY.GET_ENTITY_MODEL(door)

        if entry == grill then
            g_util.trigger_request_control_event(door)

            if NETWORK.HAS_CONTROL_OF_ENTITY(door) then
                ENTITY.SET_ENTITY_AS_MISSION_ENTITY(door, true, true)
                ENTITY.DELETE_ENTITY(door)
            end
        end
    end

    better_yield(1)

    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PLAYER.PLAYER_PED_ID(), 5054.630, -5771.519, -4.807)

    better_yield(5)

    while not SCRIPT.IS_SCRIPT_LOADED(g_util.joaat("fm_mission_controller_2020")) do
        better_yield(1)
        if loop then
            break
        end
    end

    CONTROL.SET_CONTROL_NORMAL(0, 51, 1)

    better_yield(27)

    for i = 0, POOL.GET_PED_COUNT() do
        local ped = POOL.GET_PED_AT_INDEX(i)
        if not PED.IS_PED_A_PLAYER(ped) then
            PED.SET_PED_HEALTH(ped, 0)
            SYSTEM.WAIT(50)
            ENTITY.SET_ENTITY_AS_MISSION_ENTITY(ped, true, true)
            ENTITY.DELETE_ENTITY(ped)
        end
    end

    better_yield(1)

    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PLAYER.PLAYER_PED_ID(), 5006.896, -5755.963, 15.487)

    better_yield(1)

    SCRIPT.SET_LOCAL_F(g_util.joaat("fm_mission_controller_2020"), 28736 + 3, 100)

    SCRIPT.SET_LOCAL_I(g_util.joaat("fm_mission_controller_2020"), 28268, 2)

    while SCRIPT.GET_LOCAL_I(g_util.joaat("fm_mission_controller_2020"), 28268) ~= 0 do
        better_yield(1)
    end

    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PLAYER.PLAYER_PED_ID(), 4992.341, -5719.833, 19.87)

    for i = 0, POOL.GET_PED_COUNT() do
        local ped = POOL.GET_PED_AT_INDEX(i)
        if not PED.IS_PED_A_PLAYER(ped) then
            PED.SET_PED_HEALTH(ped, 0)
            SYSTEM.WAIT(50)
            ENTITY.SET_ENTITY_AS_MISSION_ENTITY(ped, true, true)
            ENTITY.DELETE_ENTITY(ped)
        end
    end

    better_yield(2)

    CONTROL.SET_CONTROL_NORMAL(0, 51, 1)

    better_yield(25)

    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PLAYER.PLAYER_PED_ID(), 4397.290, -4380.540, 8.70)
    better_yield(2)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PLAYER.PLAYER_PED_ID(), 7999.764, -5749.864, 2.84)
    better_yield(1)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PLAYER.PLAYER_PED_ID(), 4397.290, -4380.540, 8.70)
    better_yield(1)
end

-- [[ Cayo Bot ]] --

submenu("CayoPericoHeist", "CayoBot")

-- [[ Solo ]] --

separator("CayoBot", "Solo")

toggle(
    "CayoBot",
    "AggMode",
    false,
    "BotBio",
    function(on)
        bota = on
        while bota do
            g_util.yield()
            if SCRIPT.GET_GLOBAL_I(2815059 + 1801) ~= 0 then
                g_gui.show_menu_ui(false)

                stats()

                if not bota then
                    break
                end

                SCRIPT.SET_GLOBAL_I(1575015, 10)
                SCRIPT.SET_GLOBAL_I(1574589, 1)

                better_yield(1)

                SCRIPT.SET_GLOBAL_I(1574589, 0)

                if not bota then
                    break
                end

                better_yield(5)

                if not bota then
                    break
                end

                while SCRIPT.GET_GLOBAL_I(2678391 + 1865) ~= 1 do
                    better_yield(1)
                    if not bota then
                        break
                    end
                end

                better_yield(1)

                if not bota then
                    break
                end

                local player = ENTITY.GET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID())

                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(
                    PLAYER.PLAYER_PED_ID(),
                    player.x + 2.5799560547,
                    player.y + 2.6019897461,
                    player.z + 3.598968505859
                )

                better_yield(5)

                if not bota then
                    break
                end

                while not SCRIPT.IS_SCRIPT_LOADED(g_util.joaat("heist_island_planning")) do
                    better_yield(1)
                    if not bota then
                        break
                    end
                end

                better_yield(1)

                if not bota then
                    break
                end

                SCRIPT.SET_LOCAL_I(g_util.joaat("heist_island_planning"), 1428, 2)

                if not bota then
                    break
                end

                while not SCRIPT.IS_SCRIPT_LOADED(g_util.joaat("heist_island_planning")) do
                    better_yield(1)
                    if not bota then
                        break
                    end
                end

                if not bota then
                    break
                end

                while SCRIPT.GET_LOCAL_I(g_util.joaat("heist_island_planning"), 1428) ~= 4 do
                    better_yield(1)
                    if not bota then
                        break
                    end
                end

                if not bota then
                    break
                end

                menu1()

                if not bota then
                    break
                end

                while not SCRIPT.IS_SCRIPT_LOADED(g_util.joaat("heist_island_planning")) do
                    better_yield(1)
                    if not bota then
                        break
                    end
                end

                if not bota then
                    break
                end

                while SCRIPT.GET_LOCAL_I(g_util.joaat("heist_island_planning"), 986 + 1 + 7 * 9) ~= 1 do
                    better_yield(1)
                    if not bota then
                        break
                    end
                end

                better_yield(1)

                if not bota then
                    break
                end

                menu2(true)

                if not bota then
                    break
                end

                while not SCRIPT.IS_SCRIPT_LOADED(g_util.joaat("fm_mission_controller_2020")) do
                    better_yield(1)
                    if not bota then
                        break
                    end
                end

                if not bota then
                    break
                end

                better_yield(5)

                if not bota then
                    break
                end

                while SCRIPT.GET_LOCAL_I(g_util.joaat("fm_mission_controller_2020"), 2803) ~= 1 do
                    better_yield(1)
                    if not bota then
                        break
                    end
                end

                better_yield(1)

                if not bota then
                    break
                end

                mission()

                if not bota then
                    break
                end

                notify("Not16")
                log("Not16")
                better_yield(360)
                notify("Not10")
                log("Not10")
                better_yield(300)
                notify("Not5")
                log("Not5")
                better_yield(300)
                notify("NotNew")
                log("NotNew")
                g_util.yield()
            end
            better_yield(1)
        end
        g_util.yield()
    end
)

toggle(
    "CayoBot",
    "SlMode",
    false,
    "BotBio",
    function(on)
        botb = on
        while botb do
            g_util.yield()
            if SCRIPT.GET_GLOBAL_I(2815059 + 1801) ~= 0 then
                g_gui.show_menu_ui(false)

                stats()

                if not botb then
                    break
                end

                SCRIPT.SET_GLOBAL_I(1575015, 10)
                SCRIPT.SET_GLOBAL_I(1574589, 1)

                better_yield(1)

                SCRIPT.SET_GLOBAL_I(1574589, 0)

                if not botb then
                    break
                end

                better_yield(5)

                if not botb then
                    break
                end

                while SCRIPT.GET_GLOBAL_I(2678391 + 1865) ~= 1 do
                    better_yield(1)
                    if not botb then
                        break
                    end
                end

                better_yield(1)

                if not botb then
                    break
                end

                local player = ENTITY.GET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID())

                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(
                    PLAYER.PLAYER_PED_ID(),
                    player.x + 2.5799560547,
                    player.y + 2.6019897461,
                    player.z + 3.598968505859
                )

                better_yield(5)

                if not botb then
                    break
                end

                while not SCRIPT.IS_SCRIPT_LOADED(g_util.joaat("heist_island_planning")) do
                    better_yield(1)
                    if not botb then
                        break
                    end
                end

                better_yield(1)

                if not botb then
                    break
                end

                SCRIPT.SET_LOCAL_I(g_util.joaat("heist_island_planning"), 1428, 2)

                if not botb then
                    break
                end

                while not SCRIPT.IS_SCRIPT_LOADED(g_util.joaat("heist_island_planning")) do
                    better_yield(1)
                    if not botb then
                        break
                    end
                end

                if not botb then
                    break
                end

                while SCRIPT.GET_LOCAL_I(g_util.joaat("heist_island_planning"), 1428) ~= 4 do
                    better_yield(1)
                    if not botb then
                        break
                    end
                end

                if not botb then
                    break
                end

                menu1()

                if not botb then
                    break
                end

                while not SCRIPT.IS_SCRIPT_LOADED(g_util.joaat("heist_island_planning")) do
                    better_yield(1)
                    if not botb then
                        break
                    end
                end

                if not botb then
                    break
                end

                while SCRIPT.GET_LOCAL_I(g_util.joaat("heist_island_planning"), 986 + 1 + 7 * 9) ~= 1 do
                    better_yield(1)
                    if not botb then
                        break
                    end
                end

                better_yield(1)

                if not botb then
                    break
                end

                menu2b(true)

                if not botb then
                    break
                end

                while not SCRIPT.IS_SCRIPT_LOADED(g_util.joaat("fm_mission_controller_2020")) do
                    better_yield(1)
                    if not botb then
                        break
                    end
                end

                if not botb then
                    break
                end

                better_yield(5)

                if not botb then
                    break
                end

                while SCRIPT.GET_LOCAL_I(g_util.joaat("fm_mission_controller_2020"), 2803) ~= 1 do
                    better_yield(1)
                    if not botb then
                        break
                    end
                end

                better_yield(1)

                if not botb then
                    break
                end

                missionb()

                if not botb then
                    break
                end

                notify("Not16")
                log("Not16")
                better_yield(360)
                notify("Not10")
                log("Not10")
                better_yield(300)
                notify("Not5")
                log("Not5")
                better_yield(300)
                notify("NotNew")
                log("NotNew")
                g_util.yield()
            end
            better_yield(1)
        end
        g_util.yield()
    end
)

-- [[ More Cayo Bots ]] --

separator("CayoBot", "MCayoBots")

toggle(
    "CayoBot",
    "SlMode2",
    false,
    "BotBio",
    function(on)
        botb = on
        while botb do
            g_util.yield()
            if SCRIPT.GET_GLOBAL_I(2815059 + 1801) ~= 0 then
                g_gui.show_menu_ui(false)

                stats()

                if not botb then
                    break
                end

                SCRIPT.SET_GLOBAL_I(1575015, 10)
                SCRIPT.SET_GLOBAL_I(1574589, 1)

                better_yield(1)

                SCRIPT.SET_GLOBAL_I(1574589, 0)

                if not botb then
                    break
                end

                better_yield(5)

                if not botb then
                    break
                end

                while SCRIPT.GET_GLOBAL_I(2678391 + 1865) ~= 1 do
                    better_yield(1)
                    if not botb then
                        break
                    end
                end

                better_yield(1)

                if not botb then
                    break
                end

                local player = ENTITY.GET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID())

                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(
                    PLAYER.PLAYER_PED_ID(),
                    player.x + 2.5799560547,
                    player.y + 2.6019897461,
                    player.z + 3.598968505859
                )

                better_yield(5)

                if not botb then
                    break
                end

                while not SCRIPT.IS_SCRIPT_LOADED(g_util.joaat("heist_island_planning")) do
                    better_yield(1)
                    if not botb then
                        break
                    end
                end

                better_yield(1)

                if not botb then
                    break
                end

                SCRIPT.SET_LOCAL_I(g_util.joaat("heist_island_planning"), 1428, 2)

                if not botb then
                    break
                end

                while not SCRIPT.IS_SCRIPT_LOADED(g_util.joaat("heist_island_planning")) do
                    better_yield(1)
                    if not botb then
                        break
                    end
                end

                if not botb then
                    break
                end

                while SCRIPT.GET_LOCAL_I(g_util.joaat("heist_island_planning"), 1428) ~= 4 do
                    better_yield(1)
                    if not botb then
                        break
                    end
                end

                if not botb then
                    break
                end

                menu1()

                if not botb then
                    break
                end

                while not SCRIPT.IS_SCRIPT_LOADED(g_util.joaat("heist_island_planning")) do
                    better_yield(1)
                    if not botb then
                        break
                    end
                end

                if not botb then
                    break
                end

                while SCRIPT.GET_LOCAL_I(g_util.joaat("heist_island_planning"), 986 + 1 + 7 * 9) ~= 1 do
                    better_yield(1)
                    if not botb then
                        break
                    end
                end

                better_yield(1)

                if not botb then
                    break
                end

                menu2b(true)

                if not botb then
                    break
                end

                while not SCRIPT.IS_SCRIPT_LOADED(g_util.joaat("fm_mission_controller_2020")) do
                    better_yield(1)
                    if not botb then
                        break
                    end
                end

                if not botb then
                    break
                end

                better_yield(5)

                if not botb then
                    break
                end

                while SCRIPT.GET_LOCAL_I(g_util.joaat("fm_mission_controller_2020"), 2803) ~= 1 do
                    better_yield(1)
                    if not botb then
                        break
                    end
                end

                better_yield(1)

                if not botb then
                    break
                end

                missionb()

                if not botb then
                    break
                end

                notify("Not16")
                log("Not16")
                better_yield(360)
                notify("Not10")
                log("Not10")
                better_yield(300)
                notify("Not5")
                log("Not5")
                better_yield(300)
                notify("NotNew")
                log("NotNew")
            end
            better_yield(1)
        end
        g_util.yield()
    end
)

input(
    "CayoPericoHeist",
    "RealTk",
    289700,
    100000,
    8691000,
    function(realval)
        SCRIPT.SET_LOCAL_I(g_util.joaat("fm_mission_controller_2020"), 41707 + 1392 + 53, realval)
    end
)

input(
    "CayoPericoHeist",
    "CayoCrLi",
    0,
    0,
    50,
    function(ccr)
        if SCRIPT.IS_SCRIPT_LOADED(g_util.joaat("fm_mission_controller_2020")) then
            SCRIPT.SET_LOCAL_I(g_util.joaat("fm_mission_controller_2020"), 44664 + 865 + 1, ccr)
        else
            notify("Wait 5 Seconds to use it after the Cutscene", 10000)
            log("Wait 5 Seconds to use it after the Cutscene")
        end
    end
)

button(
    "CayoPericoHeist",
    "CayoInstaHeist",
    function()
        if SCRIPT.IS_SCRIPT_LOADED(g_util.joaat("fm_mission_controller_2020")) then
            SCRIPT.SET_LOCAL_I(g_util.joaat("fm_mission_controller_2020"), 38397, 51338752)
            SCRIPT.SET_LOCAL_I(g_util.joaat("fm_mission_controller_2020"), 39772, 50)
        end
    end
)

button(
    "CayoPericoHeist",
    "ByDrainCut",
    function()
        if SCRIPT.IS_SCRIPT_LOADED(g_util.joaat("fm_mission_controller_2020")) then
            SCRIPT.SET_LOCAL_I(g_util.joaat("fm_mission_controller_2020"), 27500, 6)
        end
    end
)

button(
    "CayoPericoHeist",
    "ByFingPrint",
    function()
    if SCRIPT.IS_SCRIPT_LOADED(g_util.joaat("fm_mission_controller_2020")) then
            SCRIPT.SET_LOCAL_I(g_util.joaat("fm_mission_controller_2020"), 23385, 5)
        end
    end
)

--[[
button(
    "CayoPericoHeist",
    "VoltLab",
    function()
        if SCRIPT.IS_SCRIPT_LOADED(g_util.joaat("fm_mission_controller_2020")) then
            local ped = PLAYER.PLAYER_PED_ID()
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 4372.79, -4578.36, 4.21)

            better_yield(2)
    
            local vopos = SCRIPT.GET_LOCAL_I(g_util.joaat("fm_mission_controller_2020"), 1777)
            SCRIPT.SET_LOCAL_I(g_util.joaat("fm_mission_controller_2020"), 1776, vopos)
        end
    end
)
]]--

button(
    "CayoPericoHeist",
    "SkPlCut",
    function()
        if SCRIPT.IS_SCRIPT_LOADED(g_util.joaat("fm_mission_controller_2020")) then
            SCRIPT.SET_LOCAL_F(g_util.joaat("fm_mission_controller_2020"), 28736 + 3, 999)
        end
    end
)

button(
    "CayoPericoHeist",
    "ReDrainPipe",
    function()
        if SCRIPT.IS_SCRIPT_LOADED(g_util.joaat("fm_mission_controller_2020")) then
            local grill = 2997331308

            for i = 0, POOL.GET_OBJECT_COUNT() do
                local door = POOL.GET_OBJECT_AT_INDEX(i)
                local entry = ENTITY.GET_ENTITY_MODEL(door)

                if entry == grill then
                    g_util.trigger_request_control_event(door)

                    if NETWORK.HAS_CONTROL_OF_ENTITY(door) then
                        ENTITY.SET_ENTITY_AS_MISSION_ENTITY(door, true, true)
                        ENTITY.DELETE_ENTITY(door)
                    end
                end
            end
        end
    end
)

button(
    "CayoPericoHeist",
    "ReCams",
    function()
        if SCRIPT.IS_SCRIPT_LOADED(g_util.joaat("fm_mission_controller_2020")) then
            local cam = 3061645218

            for i = 0, POOL.GET_OBJECT_COUNT() do
                local cams = POOL.GET_OBJECT_AT_INDEX(i)
                local ent = ENTITY.GET_ENTITY_MODEL(cams)

                if ent == cam then
                    g_util.trigger_request_control_event(cams)

                    if NETWORK.HAS_CONTROL_OF_ENTITY(cams) then
                        ENTITY.SET_ENTITY_AS_MISSION_ENTITY(cams, true, true)
                        ENTITY.DELETE_ENTITY(cams)
                    end
                end
            end
        end
    end
)

-- [[ Cayo Equipment ]] --

separator("CayoPericoHeist", "Equip")

-- [[ Cayo Primary Target ]] --

submenu("CayoPericoHeist", "CayoPri")

button(
    "CayoPri",
    "PantherST",
    function()
        if NETWORK then
            STAT_SET_INT("H4CNF_TARGET", 5)
        end
    end
)

button(
    "CayoPri",
    "File",
    function()
        if NETWORK then
            STAT_SET_INT("H4CNF_TARGET", 4)
        end
    end
)

button(
    "CayoPri",
    "Dia",
    function()
        if NETWORK then
            STAT_SET_INT("H4CNF_TARGET", 3)
        end
    end
)

button(
    "CayoPri",
    "Bearer",
    function()
        if NETWORK then
            STAT_SET_INT("H4CNF_TARGET", 2)
        end
    end
)

button(
    "CayoPri",
    "Ruby",
    function()
        if NETWORK then
            STAT_SET_INT("H4CNF_TARGET", 1)
        end
    end
)

button(
    "CayoPri",
    "Tequila",
    function()
        if NETWORK then
            STAT_SET_INT("H4CNF_TARGET", 0)
        end
    end
)

-- [[ Cayo Secondary Target ]] --

submenu("CayoPericoHeist", "CayoSec")

button(
    "CayoSec",
    "Cash",
    function()
        if NETWORK then
            STAT_SET_INT("H4LOOT_CASH_C", -1)
            STAT_SET_INT("H4LOOT_CASH_V", 90000)
            STAT_SET_INT("H4LOOT_WEED_C", 0)
            STAT_SET_INT("H4LOOT_WEED_V", 0)
            STAT_SET_INT("H4LOOT_COKE_C", 0)
            STAT_SET_INT("H4LOOT_COKE_V", 0)
            STAT_SET_INT("H4LOOT_GOLD_C", 0)
            STAT_SET_INT("H4LOOT_GOLD_V", 0)
            STAT_SET_INT("H4LOOT_PAINT", 127)
            STAT_SET_INT("H4LOOT_PAINT_V", 190000)
            STAT_SET_INT("H4LOOT_CASH_C_SCOPED", -1)
            STAT_SET_INT("H4LOOT_WEED_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_COKE_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_GOLD_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_PAINT_SCOPED", 127)
        end
    end
)

button(
    "CayoSec",
    "Weed",
    function()
        if NETWORK then
            STAT_SET_INT("H4LOOT_CASH_C", 0)
            STAT_SET_INT("H4LOOT_CASH_V", 0)
            STAT_SET_INT("H4LOOT_WEED_C", -1)
            STAT_SET_INT("H4LOOT_WEED_V", 140000)
            STAT_SET_INT("H4LOOT_COKE_C", 0)
            STAT_SET_INT("H4LOOT_COKE_V", 0)
            STAT_SET_INT("H4LOOT_GOLD_C", 0)
            STAT_SET_INT("H4LOOT_PAINT", 127)
            STAT_SET_INT("H4LOOT_PAINT_V", 190000)
            STAT_SET_INT("H4LOOT_CASH_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_WEED_C_SCOPED", -1)
            STAT_SET_INT("H4LOOT_COKE_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_GOLD_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_PAINT_SCOPED", 127)
        end
    end
)

button(
    "CayoSec",
    "Coke",
    function()
        if NETWORK then
            STAT_SET_INT("H4LOOT_CASH_C", 0)
            STAT_SET_INT("H4LOOT_CASH_V", 0)
            STAT_SET_INT("H4LOOT_WEED_C", 0)
            STAT_SET_INT("H4LOOT_WEED_V", 0)
            STAT_SET_INT("H4LOOT_COKE_C", -1)
            STAT_SET_INT("H4LOOT_COKE_V", 210000)
            STAT_SET_INT("H4LOOT_GOLD_C", 0)
            STAT_SET_INT("H4LOOT_PAINT", 127)
            STAT_SET_INT("H4LOOT_PAINT_V", 190000)
            STAT_SET_INT("H4LOOT_CASH_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_WEED_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_COKE_C_SCOPED", -1)
            STAT_SET_INT("H4LOOT_GOLD_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_PAINT_SCOPED", 127)
        end
    end
)

button(
    "CayoSec",
    "Gold",
    function()
        if NETWORK then
            STAT_SET_INT("H4LOOT_CASH_C", 0)
            STAT_SET_INT("H4LOOT_CASH_V", 0)
            STAT_SET_INT("H4LOOT_WEED_C", 0)
            STAT_SET_INT("H4LOOT_WEED_V", 0)
            STAT_SET_INT("H4LOOT_COKE_C", 0)
            STAT_SET_INT("H4LOOT_COKE_V", 0)
            STAT_SET_INT("H4LOOT_GOLD_C", -1)
            STAT_SET_INT("H4LOOT_GOLD_V", 320000)
            STAT_SET_INT("H4LOOT_PAINT", 127)
            STAT_SET_INT("H4LOOT_PAINT_V", 190000)
            STAT_SET_INT("H4LOOT_GOLD_C_SCOPED", -1)
            STAT_SET_INT("H4LOOT_CASH_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_WEED_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_COKE_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_PAINT_SCOPED", 127)
        end
    end
)

button(
    "CayoSec",
    "Paint",
    function()
        if NETWORK then
            STAT_SET_INT("H4LOOT_CASH_C", 0)
            STAT_SET_INT("H4LOOT_CASH_V", 0)
            STAT_SET_INT("H4LOOT_WEED_C", 0)
            STAT_SET_INT("H4LOOT_WEED_V", 0)
            STAT_SET_INT("H4LOOT_COKE_C", 0)
            STAT_SET_INT("H4LOOT_COKE_V", 0)
            STAT_SET_INT("H4LOOT_GOLD_C", 0)
            STAT_SET_INT("H4LOOT_GOLD_V", 0)
            STAT_SET_INT("H4LOOT_GOLD_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_CASH_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_WEED_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_COKE_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_PAINT", 127)
            STAT_SET_INT("H4LOOT_PAINT_V", 190000)
            STAT_SET_INT("H4LOOT_PAINT_SCOPED", 127)
        end
    end
)

button(
    "CayoSec",
    "Mix",
    function()
        if NETWORK then
            STAT_SET_INT("H4LOOT_CASH_C", 2)
            STAT_SET_INT("H4LOOT_CASH_V", 474431)
            STAT_SET_INT("H4LOOT_WEED_C", 17)
            STAT_SET_INT("H4LOOT_WEED_V", 759090)
            STAT_SET_INT("H4LOOT_COKE_C", 132)
            STAT_SET_INT("H4LOOT_COKE_V", 948863)
            STAT_SET_INT("H4LOOT_GOLD_C", 104)
            STAT_SET_INT("H4LOOT_GOLD_V", 1265151)
            STAT_SET_INT("H4LOOT_PAINT", 127)
            STAT_SET_INT("H4LOOT_PAINT_V", 948863)
            STAT_SET_INT("H4LOOT_CASH_C_SCOPED", 2)
            STAT_SET_INT("H4LOOT_WEED_C_SCOPED", 17)
            STAT_SET_INT("H4LOOT_COKE_C_SCOPED", 132)
            STAT_SET_INT("H4LOOT_GOLD_C_SCOPED", 104)
            STAT_SET_INT("H4LOOT_PAINT_SCOPED", 127)
        end
    end
)

button(
    "CayoSec",
    "RePa",
    function()
        if NETWORK then
            STAT_SET_INT("H4LOOT_PAINT", 0)
            STAT_SET_INT("H4LOOT_PAINT_V", 0)
            STAT_SET_INT("H4LOOT_PAINT_SCOPED", 0)
        end
    end
)

button(
    "CayoSec",
    "ReAll",
    function()
        if NETWORK then
            STAT_SET_INT("H4LOOT_CASH_C", 0)
            STAT_SET_INT("H4LOOT_WEED_C", 0)
            STAT_SET_INT("H4LOOT_COKE_C", 0)
            STAT_SET_INT("H4LOOT_GOLD_C", 0)
            STAT_SET_INT("H4LOOT_GOLD_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_CASH_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_WEED_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_COKE_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_PAINT", 0)
            STAT_SET_INT("H4LOOT_PAINT_SCOPED", 0)
        end
    end
)

-- [[ Cayo Vehicles ]] --

submenu("CayoPericoHeist", "CayoVeh")

button(
    "CayoVeh",
    "Kos",
    function()
        if NETWORK then
            STAT_SET_INT("H4_MISSIONS", 65283)
        end
    end
)

button(
    "CayoVeh",
    "Alk",
    function()
        if NETWORK then
            STAT_SET_INT("H4_MISSIONS", 65413)
        end
    end
)

button(
    "CayoVeh",
    "Vel",
    function()
        if NETWORK then
            STAT_SET_INT("H4_MISSIONS", 65289)
        end
    end
)

button(
    "CayoVeh",
    "Anni",
    function()
        if NETWORK then
            STAT_SET_INT("H4_MISSIONS", 65425)
        end
    end
)

button(
    "CayoVeh",
    "Pato",
    function()
        if NETWORK then
            STAT_SET_INT("H4_MISSIONS", 65313)
        end
    end
)

button(
    "CayoVeh",
    "Longf",
    function()
        if NETWORK then
            STAT_SET_INT("H4_MISSIONS", 65345)
        end
    end
)

button(
    "CayoVeh",
    "CayoAllVeh",
    function()
        if NETWORK then
            STAT_SET_INT("H4_MISSIONS", -1)
        end
    end
)

-- [[ Cayo Weapons ]] --

submenu("CayoPericoHeist", "CayoWep")

button(
    "CayoWep",
    "Ages",
    function()
        if NETWORK then
            STAT_SET_INT("H4CNF_WEAPONS", 1)
        end
    end
)

button(
    "CayoWep",
    "Con",
    function()
        if NETWORK then
            STAT_SET_INT("H4CNF_WEAPONS", 2)
        end
    end
)

button(
    "CayoWep",
    "Crack",
    function()
        if NETWORK then
            STAT_SET_INT("H4CNF_WEAPONS", 3)
        end
    end
)

button(
    "CayoWep",
    "Sabo",
    function()
        if NETWORK then
            STAT_SET_INT("H4CNF_WEAPONS", 4)
        end
    end
)

button(
    "CayoWep",
    "Marks",
    function()
        if NETWORK then
            STAT_SET_INT("H4CNF_WEAPONS", 5)
        end
    end
)

button(
    "CayoWep",
    "ReSupp",
    function()
        if NETWORK then
            STAT_SET_INT("H4CNF_BS_GEN", 126975)
        end
    end
)

-- [[ Cayo Equipment ]] --

submenu("CayoPericoHeist", "CayoEq")

button(
    "CayoEq",
    "AirpEq",
    function()
        if NETWORK then
            STAT_SET_INT("H4CNF_GRAPPEL", 2022)
            STAT_SET_INT("H4CNF_UNIFORM", 12)
            STAT_SET_INT("H4CNF_BOLTCUT", 4161)
            STAT_SET_INT("H4CNF_TROJAN", 1)
        end
    end
)

button(
    "CayoEq",
    "DkEq",
    function()
        if NETWORK then
            STAT_SET_INT("H4CNF_GRAPPEL", 3671)
            STAT_SET_INT("H4CNF_UNIFORM", 5256)
            STAT_SET_INT("H4CNF_BOLTCUT", 4424)
            STAT_SET_INT("H4CNF_TROJAN", 2)
        end
    end
)

button(
    "CayoEq",
    "CompEq",
    function()
        if NETWORK then
            STAT_SET_INT("H4CNF_GRAPPEL", 85324)
            STAT_SET_INT("H4CNF_UNIFORM", 61034)
            STAT_SET_INT("H4CNF_BOLTCUT", 4612)
            STAT_SET_INT("H4CNF_TROJAN", 5)
        end
    end
)

-- [[ Cayo Truck ]] --

submenu("CayoPericoHeist", "CayoTru")

button(
    "CayoTru",
    "TruAirp",
    function()
        if NETWORK then
            STAT_SET_INT("H4CNF_TROJAN", 1)
        end
    end
)

button(
    "CayoTru",
    "TruNDk",
    function()
        if NETWORK then
            STAT_SET_INT("H4CNF_TROJAN", 2)
        end
    end
)

button(
    "CayoTru",
    "TruEDk",
    function()
        if NETWORK then
            STAT_SET_INT("H4CNF_TROJAN", 3)
        end
    end
)

button(
    "CayoTru",
    "TruWAirp",
    function()
        if NETWORK then
            STAT_SET_INT("H4CNF_TROJAN", 4)
        end
    end
)

button(
    "CayoTru",
    "TruComp",
    function()
        if NETWORK then
            STAT_SET_INT("H4CNF_TROJAN", 5)
        end
    end
)

-- [[ Cayo Difficulty ]] --

submenu("CayoPericoHeist", "CayoDif")

button(
    "CayoDif",
    "DifHard",
    function()
        if NETWORK then
            STAT_SET_INT("H4_PROGRESS", 131055)
        end
    end
)

button(
    "CayoDif",
    "DifNor",
    function()
        if NETWORK then
            STAT_SET_INT("H4_PROGRESS", 126823)
        end
    end
)

-- [[ More Options ]] --

separator("CayoPericoHeist", "MoOp")

button(
    "CayoPericoHeist",
    "CompAllMis",
    function()
        if NETWORK then
            STAT_SET_INT("PROSTITUTES_FREQUENTE", 100)
            STAT_SET_INT("H4_MISSIONS", -1)
            STAT_SET_INT("H4CNF_APPROACH", -1)
            STAT_SET_INT("H4CNF_BS_ENTR", 63)
            STAT_SET_INT("H4CNF_BS_GEN", 63)
            STAT_SET_INT("H4CNF_WEP_DISRP", 3)
            STAT_SET_INT("H4CNF_ARM_DISRP", 3)
            STAT_SET_INT("H4CNF_HEL_DISRP", 3)
        end
    end
)

--- [[ Doomsday Heist ]] ---

-- [[ Doomsday Teleports ]] --

separator("DoomsdayHeist", "DoomTpSep")

button(
    "DoomsdayHeist",
    "1TpAccII",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 515.528, 4835.353, -62.587)
    end
)

button(
    "DoomsdayHeist",
    "2TpAccII",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 512.888, 4833.033, -68.989)
    end
)

-- [[ Doomsday Presets ]] --

separator("DoomsdayHeist", "DoomPreSep")

toggle(
    "DoomsdayHeist",
    "ACTI",
    false,
    "ActIBio",
    function(on)
        acta = on
        while acta do
            SYSTEM.WAIT(100)
            if NETWORK then
                STAT_SET_INT("GANGOPS_FLOW_MISSION_PROG", 503)
                STAT_SET_INT("GANGOPS_HEIST_STATUS", -229383)
                STAT_SET_INT("GANGOPS_FLOW_NOTIFICATIONS", 1557)
                SCRIPT.SET_GLOBAL_I(1963409, 313)
                SCRIPT.SET_GLOBAL_I(1963410, 313)
                SCRIPT.SET_GLOBAL_I(1963411, 313)
                SCRIPT.SET_GLOBAL_I(1963412, 313)
            end
        end
    end
)

toggle(
    "DoomsdayHeist",
    "ACTII",
    false,
    "ActIBio",
    function(on)
        actb = on
        while actb do
            SYSTEM.WAIT(100)
            if NETWORK then
                STAT_SET_INT("GANGOPS_FLOW_MISSION_PROG", 240)
                STAT_SET_INT("GANGOPS_HEIST_STATUS", -229378)
                STAT_SET_INT("GANGOPS_FLOW_NOTIFICATIONS", 1557)
                SCRIPT.SET_GLOBAL_I(1963409, 214)
                SCRIPT.SET_GLOBAL_I(1963410, 214)
                SCRIPT.SET_GLOBAL_I(1963411, 214)
                SCRIPT.SET_GLOBAL_I(1963412, 214)
            end
        end
    end
)

toggle(
    "DoomsdayHeist",
    "ACTIII",
    false,
    "ActIBio",
    function(on)
        actc = on
        while actc do
            SYSTEM.WAIT(100)
            if NETWORK then
                STAT_SET_INT("GANGOPS_FLOW_MISSION_PROG", 16368)
                STAT_SET_INT("GANGOPS_HEIST_STATUS", -229380)
                STAT_SET_INT("GANGOPS_FLOW_NOTIFICATIONS", 1557)
                SCRIPT.SET_GLOBAL_I(1963409, 170)
                SCRIPT.SET_GLOBAL_I(1963410, 170)
                SCRIPT.SET_GLOBAL_I(1963411, 170)
                SCRIPT.SET_GLOBAL_I(1963412, 170)
            end
        end
    end
)

button(
    "DoomsdayHeist",
    "ReHei",
    function()
        if NETWORK then
            STAT_SET_INT("GANGOPS_FLOW_MISSION_PROG", 240)
            STAT_SET_INT("GANGOPS_HEIST_STATUS", 0)
            STAT_SET_INT("GANGOPS_FLOW_NOTIFICATIONS", 1557)
        end
    end
)

-- [[ Doomsday Advanced ]] --

separator("DoomsdayHeist", "DoomAdv")

-- [[ Player Cut Manager ]] --

submenu("DoomsdayHeist", "PlCuMan")

-- [[ Doomsday Cut ]] --

separator("PlCuMan", "DoomCut")

input(
    "PlCuMan",
    "pl1",
    0,
    0,
    1000,
    function(cut1)
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(1963409, cut1)
        end
    end
)

input(
    "PlCuMan",
    "pl2",
    0,
    0,
    1000,
    function(cut2)
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(1963410, cut2)
        end
    end
)

input(
    "PlCuMan",
    "pl3",
    0,
    0,
    1000,
    function(cut3)
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(1963411, cut3)
        end
    end
)

input(
    "PlCuMan",
    "pl4",
    0,
    0,
    1000,
    function(cut4)
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(1963412, cut4)
        end
    end
)

-- [[ More Options ]] --

separator("DoomsdayHeist", "MoOp")

button(
    "DoomsdayHeist",
    "UnAllDoomHei",
    "UnAllDoomHeiBio",
    function()
        if NETWORK then
            STAT_SET_INT("GANGOPS_HEIST_STATUS", -1)
            STAT_SET_INT("GANGOPS_HEIST_STATUS", -229384)
        end
    end
)

button(
    "DoomsdayHeist",
    "CompAllPrep",
    function()
        if NETWORK then
            STAT_SET_INT("GANGOPS_FM_MISSION_PROG", -1)
        end
    end
)

--- [[ Classic Heists ]] ---

-- [[ Fleeca Heist ]] --

separator("ClassicHeists", "FleHei")

-- [[ Player Cut Manager ]] --

submenu("ClassicHeists", "PlCuMan")

-- [[ Fleeca Cut ]] --

separator("PlCuMan", "FleCut")

input(
    "PlCuMan",
    "pl1",
    0,
    0,
    9999999,
    function(fcut1)
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(1936917, fcut1)
        end
    end
)

input(
    "PlCuMan",
    "pl2",
    0,
    0,
    9999999,
    function(fcut2)
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(1936918, fcut2)
        end
    end
)

input(
    "PlCuMan",
    "pl3",
    0,
    0,
    9999999,
    function(fcut3)
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(1936919, fcut3)
        end
    end
)

input(
    "PlCuMan",
    "pl4",
    0,
    0,
    9999999,
    function(fcut4)
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(1936920, fcut4)
        end
    end
)

-- [[ Fleeca Payout Presets ]] --

submenu("ClassicHeists", "FlePayuPre")

toggle(
    "FlePayuPre",
    "5Mil",
    false,
    "FlePreBio",
    function(on)
        fl5 = on
        while fl5 do
            SYSTEM.WAIT(100)
            if NETWORK then
                SCRIPT.SET_GLOBAL_I(1936917, 3500)
            end
        end
    end
)

toggle(
    "FlePayuPre",
    "10Mil",
    false,
    "FlePreBio",
    function(on)
        fl10 = on
        while fl10 do
            SYSTEM.WAIT(100)
            if NETWORK then
                SCRIPT.SET_GLOBAL_I(1936917, 7000)
            end
        end
    end
)

toggle(
    "FlePayuPre",
    "15Mil",
    false,
    "FlePreBio",
    function(on)
        fl15 = on
        while fl15 do
            SYSTEM.WAIT(100)
            if NETWORK then
                SCRIPT.SET_GLOBAL_I(1936917, 10434)
            end
        end
    end
)

function GET_CLOSEST_VEHICLE(x, y, z, radius, model, flags)
    g_native.start()
    g_native.push_float(x)
    g_native.push_float(y)
    g_native.push_float(z)
    g_native.push_float(radius)
    g_native.push_int(model)
    g_native.push_int(flags)
    return g_native.call_int(0xF73EB622C4F1689B)
end

function flplan1()
    CONTROL.SET_CONTROL_NORMAL(0, 51, 1)
    better_yield(2)
    CONTROL.SET_CONTROL_NORMAL(2, 201, 1)
    better_yield(15)
    CONTROL.SET_CONTROL_NORMAL(2, 190, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(2, 188, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(2, 201, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(2, 190, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(2, 187, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(2, 201, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(2, 188, 1)
    better_yield(1)
    CONTROL.SET_CONTROL_NORMAL(2, 188, 1)
    better_yield(45)
    CONTROL.SET_CONTROL_NORMAL(2, 201, 1)
    better_yield(25)
    CUTSCENE.STOP_CUTSCENE_IMMEDIATELY()
    better_yield(10)
end

toggle(
    "ClassicHeists",
    "FleBot",
    false,
    "FleBotBio",
    function(on)
        flbot = on
        while flbot do
            g_util.yield()
            if SCRIPT.GET_GLOBAL_I(2815059 + 1801) ~= 0 then
                g_gui.show_menu_ui(false)

                if not flbot then
                    break
                end

                SCRIPT.SET_GLOBAL_I(1575015, 1)
                SCRIPT.SET_GLOBAL_I(1574589, 1)

                better_yield(1)

                SCRIPT.SET_GLOBAL_I(1574589, 0)

                better_yield(22)

                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PLAYER.PLAYER_PED_ID(), -902.18, -448.41, 126.53)

                better_yield(4)

                flplan1()

                local ped = PLAYER.PLAYER_PED_ID()
                local pos = ENTITY.GET_ENTITY_COORDS(ped)

                PED.CLEAR_PED_TASKS_IMMEDIATELY(ped)
                PED.SET_PED_INTO_VEHICLE(ped, GET_CLOSEST_VEHICLE(pos.x, pos.y, pos.z, 50, 0, 71), -1)

                better_yield(15)

                --[[ local pedveh = VEHICLE.GET_PED_IN_VEHICLE_SEAT(GET_CLOSEST_VEHICLE(pos.x, pos.y, pos.z, 50, 0, 71), 0)

                        if pedveh then
                                notify("test")
                                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PLAYER.PLAYER_PED_ID(), -2974.49, 447.05, 14.83)
                        end --]]
                better_yield(100)
            end
        end
    end
)

-- [[ More Options ]] --

separator("ClassicHeists", "MoOp")

button(
    "ClassicHeists",
    "StHei",
    function()
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(1575015, 1)
            SCRIPT.SET_GLOBAL_I(1574589, 1)
            better_yield(1)
            SCRIPT.SET_GLOBAL_I(1574589, 0)
        end
    end
)

button(
    "ClassicHeists",
    "CompAllSet",
    "CompAllSetBio",
    function()
        if NETWORK then
            STAT_SET_INT("HEIST_PLANNING_STAGE", -1)
        end
    end
)

-- [[ LS Contract ]] --

separator("LSContract", "LSContract")

toggle(
    "LSContract",
    "IncPay1M",
    false,
    function(on)
        ls = on
        while ls do
            SYSTEM.WAIT(100)
            if NETWORK then
                SCRIPT.SET_GLOBAL_I(262145 + 30691 + 0, 1000000)
                SCRIPT.SET_GLOBAL_I(262145 + 30691 + 1, 1000000)
                SCRIPT.SET_GLOBAL_I(262145 + 30691 + 2, 1000000)
                SCRIPT.SET_GLOBAL_I(262145 + 30691 + 3, 1000000)
                SCRIPT.SET_GLOBAL_I(262145 + 30691 + 4, 1000000)
                SCRIPT.SET_GLOBAL_I(262145 + 30691 + 5, 1000000)
                SCRIPT.SET_GLOBAL_I(262145 + 30691 + 6, 1000000)
                SCRIPT.SET_GLOBAL_I(262145 + 30691 + 7, 1000000)
                SCRIPT.SET_GLOBAL_I(262145 + 30690, 1000000)
                SCRIPT.SET_GLOBAL_F(262145 + 30687, 0)
            end
        end
    end
)

-- [[ LS Robbery ]] --

submenu("LSContract", "LSRob")

button(
    "LSRob",
    "UniDep",
    function()
        if NETWORK then
            STAT_SET_INT("TUNER_GEN_BS", 12543)
            STAT_SET_INT("TUNER_CURRENT", 0)
        end
    end
)

button(
    "LSRob",
    "SuperDol",
    function()
        if NETWORK then
            STAT_SET_INT("TUNER_GEN_BS", 4351)
            STAT_SET_INT("TUNER_CURRENT", 1)
        end
    end
)

button(
    "LSRob",
    "BankCon",
    function()
        if NETWORK then
            STAT_SET_INT("TUNER_GEN_BS", 12543)
            STAT_SET_INT("TUNER_CURRENT", 2)
        end
    end
)

button(
    "LSRob",
    "ECU",
    function()
        if NETWORK then
            STAT_SET_INT("TUNER_GEN_BS", 12543)
            STAT_SET_INT("TUNER_CURRENT", 3)
        end
    end
)

button(
    "LSRob",
    "PriCon",
    function()
        if NETWORK then
            STAT_SET_INT("TUNER_GEN_BS", 12543)
            STAT_SET_INT("TUNER_CURRENT", 4)
        end
    end
)

button(
    "LSRob",
    "AgeDeal",
    function()
        if NETWORK then
            STAT_SET_INT("TUNER_GEN_BS", 12543)
            STAT_SET_INT("TUNER_CURRENT", 5)
        end
    end
)

button(
    "LSRob",
    "LostCon",
    function()
        if NETWORK then
            STAT_SET_INT("TUNER_GEN_BS", 12543)
            STAT_SET_INT("TUNER_CURRENT", 6)
        end
    end
)

button(
    "LSRob",
    "DataCon",
    function()
        if NETWORK then
            STAT_SET_INT("TUNER_GEN_BS", 12543)
            STAT_SET_INT("TUNER_CURRENT", 7)
        end
    end
)

button(
    "LSContract",
    "ReMis",
    function()
        if NETWORK then
            STAT_SET_INT("TUNER_GEN_BS", 12467)
        end
    end
)

button(
    "LSContract",
    "ReCon",
    function()
        if NETWORK then
            STAT_SET_INT("TUNER_GEN_BS", 8371)
            STAT_SET_INT("TUNER_CURRENT", 0xFFFFFFF)
        end
    end
)

button(
    "LSContract",
    "ReGaMi",
    function()
        if NETWORK then
            STAT_SET_INT("TUNER_COUNT", 0)
            STAT_SET_INT("TUNER_EARNINGS", 0)
        end
    end
)

-- [[ More Options ]] --

separator("LSContract", "MoOp")

button(
    "LSContract",
    "CompMis",
    function()
        if NETWORK then
            STAT_SET_INT("TUNER_GEN_BS", 0xFFFFFFF)
        end
    end
)

-- [[ The Contract ]] --

separator("TheContract", "TheContract")

-- [[ Preps and Missions ]] --

submenu("TheContract", "PrepsMis")

button(
    "PrepsMis",
    "NightPrep",
    function()
        if NETWORK then
            STAT_SET_INT("FIXER_GENERAL_BS", -1)
            STAT_SET_INT("FIXER_COMPLETED_BS", -1)
            STAT_SET_INT("FIXER_STORY_BS", 3)
            STAT_SET_INT("FIXER_STORY_COOLDOWN", -1)
        end
    end
)

button(
    "PrepsMis",
    "MarinaPrep",
    function()
        if NETWORK then
            STAT_SET_INT("FIXER_GENERAL_BS", -1)
            STAT_SET_INT("FIXER_COMPLETED_BS", -1)
            STAT_SET_INT("FIXER_STORY_BS", 4)
            STAT_SET_INT("FIXER_STORY_COOLDOWN", -1)
        end
    end
)

button(
    "PrepsMis",
    "NightLiMission",
    function()
        if NETWORK then
            STAT_SET_INT("FIXER_GENERAL_BS", -1)
            STAT_SET_INT("FIXER_COMPLETED_BS", -1)
            STAT_SET_INT("FIXER_STORY_BS", 12)
            STAT_SET_INT("FIXER_STORY_COOLDOWN", -1)
        end
    end
)

button(
    "PrepsMis",
    "CountryCluPrep",
    function()
        if NETWORK then
            STAT_SET_INT("FIXER_GENERAL_BS", -1)
            STAT_SET_INT("FIXER_COMPLETED_BS", -1)
            STAT_SET_INT("FIXER_STORY_STRAND", -1)
            STAT_SET_INT("FIXER_STORY_BS", 28)
            STAT_SET_INT("FIXER_STORY_COOLDOWN", -1)
        end
    end
)

button(
    "PrepsMis",
    "GuestPrep",
    function()
        if NETWORK then
            STAT_SET_INT("FIXER_GENERAL_BS", -1)
            STAT_SET_INT("FIXER_COMPLETED_BS", -1)
            STAT_SET_INT("FIXER_STORY_STRAND", -1)
            STAT_SET_INT("FIXER_STORY_BS", 60)
            STAT_SET_INT("FIXER_STORY_COOLDOWN", -1)
        end
    end
)

button(
    "PrepsMis",
    "SocietyMis",
    function()
        if NETWORK then
            STAT_SET_INT("FIXER_GENERAL_BS", -1)
            STAT_SET_INT("FIXER_COMPLETED_BS", -1)
            STAT_SET_INT("FIXER_STORY_STRAND", -1)
            STAT_SET_INT("FIXER_STORY_BS", 124)
            STAT_SET_INT("FIXER_STORY_COOLDOWN", -1)
        end
    end
)

button(
    "PrepsMis",
    "DavisPrep",
    function()
        if NETWORK then
            STAT_SET_INT("FIXER_GENERAL_BS", -1)
            STAT_SET_INT("FIXER_COMPLETED_BS", -1)
            STAT_SET_INT("FIXER_STORY_STRAND", -1)
            STAT_SET_INT("FIXER_STORY_BS", 252)
            STAT_SET_INT("FIXER_STORY_COOLDOWN", -1)
        end
    end
)

button(
    "PrepsMis",
    "BallasPrep",
    function()
        if NETWORK then
            STAT_SET_INT("FIXER_GENERAL_BS", -1)
            STAT_SET_INT("FIXER_COMPLETED_BS", -1)
            STAT_SET_INT("FIXER_STORY_STRAND", -1)
            STAT_SET_INT("FIXER_STORY_BS", 508)
            STAT_SET_INT("FIXER_STORY_COOLDOWN", -1)
        end
    end
)

button(
    "PrepsMis",
    "StudioMis",
    function()
        if NETWORK then
            STAT_SET_INT("FIXER_GENERAL_BS", -1)
            STAT_SET_INT("FIXER_COMPLETED_BS", -1)
            STAT_SET_INT("FIXER_STORY_STRAND", -1)
            STAT_SET_INT("FIXER_STORY_BS", 2044)
            STAT_SET_INT("FIXER_STORY_COOLDOWN", -1)
        end
    end
)

button(
    "PrepsMis",
    "FinalContract",
    function()
        if NETWORK then
            STAT_SET_INT("FIXER_GENERAL_BS", -1)
            STAT_SET_INT("FIXER_COMPLETED_BS", -1)
            STAT_SET_INT("FIXER_STORY_STRAND", -1)
            STAT_SET_INT("FIXER_STORY_BS", 4092)
            STAT_SET_INT("FIXER_STORY_COOLDOWN", -1)
        end
    end
)

toggle(
    "TheContract",
    "RemovePyCold",
    false,
    function(on)
        fp = on
        while fp do
            SYSTEM.WAIT(100)
            if NETWORK then
                SCRIPT.SET_GLOBAL_I(262145 + 31345, 0)
                SCRIPT.SET_GLOBAL_I(262145 + 31423, 0)
                SCRIPT.SET_GLOBAL_I(2720311, 0)
            end
        end
    end
)

-- [[ Payouts ]] --

separator("TheContract", "Pyout")

toggle(
    "TheContract",
    "ModFinPay",
    false,
    function(on)
        pb = on
        while pb do
            SYSTEM.WAIT(100)
            if NETWORK then
                SCRIPT.SET_GLOBAL_I(262145 + 31389, 2400000)
            end
        end
    end
)

-- [[ More Options ]] --

separator("TheContract", "MoOp")

button(
    "TheContract",
    "CompAllMis",
    function()
        if NETWORK then
            STAT_SET_INT("FIXER_GENERAL_BS", -1)
            STAT_SET_INT("FIXER_COMPLETED_BS", -1)
            STAT_SET_INT("FIXER_STORY_BS", -1)
            STAT_SET_INT("FIXER_STORY_COOLDOWN", -1)
        end
    end
)

--- [[ Diamond Casino Heist ]] ---

-- [[ Casino Teleports ]] --

separator("DiamondCasinoHeist", "CsTp")

button(
    "DiamondCasinoHeist",
    "PlanBo",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 2711.773, -369.458, -54.781)
    end
)

button(
    "DiamondCasinoHeist",
    "GarEx",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 2677.237, -361.494, -55.187)
    end
)

-- [[ Casino Presets ]] --

separator("DiamondCasinoHeist", "CsPre")

local ExecuteOnce = {
    {"H3_COMPLETEDPOSIX", -1},
    {"H3OPT_MASKS", 4},
    {"H3OPT_WEAPS", 1},
    {"H3OPT_VEHS", 3}
}

local SILENT_SNEAKY_PRESET = {
    {"CAS_HEIST_FLOW", -1},
    {"H3_LAST_APPROACH", 0},
    {"H3OPT_APPROACH", 1},
    {"H3_HARD_APPROACH", 0},
    {"H3OPT_TARGET", 3},
    {"H3OPT_POI", 1023},
    {"H3OPT_ACCESSPOINTS", 2047},
    {"H3OPT_CREWWEAP", 4},
    {"H3OPT_CREWDRIVER", 3},
    {"H3OPT_CREWHACKER", 4},
    {"H3OPT_DISRUPTSHIP", 3},
    {"H3OPT_BODYARMORLVL", -1},
    {"H3OPT_KEYLEVELS", 2},
    {"H3OPT_BITSET1", 127},
    {"H3OPT_BITSET0", 262270}
}

toggle(
    "DiamondCasinoHeist",
    "SilSneak",
    false,
    "SilSneakBio",
    function(on)
        for i = 1, #ExecuteOnce do
            if NETWORK then
                STAT_SET_INT(ExecuteOnce[i][1], ExecuteOnce[i][2])
            -- INT
            end
        end
        silent = on
        while silent do
            SYSTEM.WAIT(100)
            if NETWORK then
                for i = 1, #SILENT_SNEAKY_PRESET do
                    STAT_SET_INT(SILENT_SNEAKY_PRESET[i][1], SILENT_SNEAKY_PRESET[i][2])
                    -- INT
                end
                SCRIPT.SET_GLOBAL_I(1966739 + 2326, 60)
                SCRIPT.SET_GLOBAL_I(1968860, 147)
                SCRIPT.SET_GLOBAL_I(1968861, 147)
                SCRIPT.SET_GLOBAL_I(1968862, 147)
                SCRIPT.SET_GLOBAL_I(262145 + 28472, 1410065408)
            -- GLOBAL
            end
        end
    end
)

local ExecuteOnce = {
    {"H3_COMPLETEDPOSIX", -1},
    {"H3OPT_MASKS", 2},
    {"H3OPT_WEAPS", 1},
    {"H3OPT_VEHS", 3}
}

local BIGCON_PRESET = {
    {"CAS_HEIST_FLOW", -1},
    {"H3_LAST_APPROACH", 0},
    {"H3OPT_APPROACH", 2},
    {"H3_HARD_APPROACH", 0},
    {"H3OPT_TARGET", 3},
    {"H3OPT_POI", 1023},
    {"H3OPT_ACCESSPOINTS", 2047},
    {"H3OPT_CREWWEAP", 4},
    {"H3OPT_CREWDRIVER", 3},
    {"H3OPT_CREWHACKER", 4},
    {"H3OPT_DISRUPTSHIP", 3},
    {"H3OPT_BODYARMORLVL", -1},
    {"H3OPT_KEYLEVELS", 2},
    {"H3OPT_BITSET1", 159},
    {"H3OPT_BITSET0", 524118}
}

toggle(
    "DiamondCasinoHeist",
    "BigCon",
    false,
    "BigConBio",
    function(on)
        for i = 1, #ExecuteOnce do
            if NETWORK then
                STAT_SET_INT(ExecuteOnce[i][1], ExecuteOnce[i][2])
            -- INT
            end
        end
        bigcon = on
        while bigcon do
            SYSTEM.WAIT(100)
            if NETWORK then
                for i = 1, #BIGCON_PRESET do
                    STAT_SET_INT(BIGCON_PRESET[i][1], BIGCON_PRESET[i][2])
                    -- INT
                end
                SCRIPT.SET_GLOBAL_I(1966739 + 2326, 60)
                SCRIPT.SET_GLOBAL_I(1968860, 147)
                SCRIPT.SET_GLOBAL_I(1968861, 147)
                SCRIPT.SET_GLOBAL_I(1968862, 147)
                SCRIPT.SET_GLOBAL_I(262145 + 28472, 1410065408)
            -- GLOBAL
            end
        end
    end
)

local ExecuteOnce = {
    {"H3_COMPLETEDPOSIX", -1},
    {"H3OPT_MASKS", 4},
    {"H3OPT_WEAPS", 1},
    {"H3OPT_VEHS", 3}
}

local AGGRESSIVE_PRESET = {
    {"CAS_HEIST_FLOW", -1},
    {"H3_LAST_APPROACH", 0},
    {"H3OPT_APPROACH", 3},
    {"H3_HARD_APPROACH", 0},
    {"H3OPT_TARGET", 3},
    {"H3OPT_POI", 1023},
    {"H3OPT_ACCESSPOINTS", 2047},
    {"H3OPT_CREWWEAP", 4},
    {"H3OPT_CREWDRIVER", 3},
    {"H3OPT_CREWHACKER", 4},
    {"H3OPT_DISRUPTSHIP", 3},
    {"H3OPT_BODYARMORLVL", -1},
    {"H3OPT_KEYLEVELS", 2},
    {"H3OPT_BITSET1", 799},
    {"H3OPT_BITSET0", 3670102}
}

toggle(
    "DiamondCasinoHeist",
    "Aggressive",
    false,
    "AggressiveBio",
    function(on)
        for i = 1, #ExecuteOnce do
            if NETWORK then
                STAT_SET_INT(ExecuteOnce[i][1], ExecuteOnce[i][2])
            -- INT
            end
        end
        agg = on
        while agg do
            SYSTEM.WAIT(100)
            if NETWORK then
                for i = 1, #AGGRESSIVE_PRESET do
                    STAT_SET_INT(AGGRESSIVE_PRESET[i][1], AGGRESSIVE_PRESET[i][2])
                    -- INT
                end
                SCRIPT.SET_GLOBAL_I(1966739 + 2326, 60)
                SCRIPT.SET_GLOBAL_I(1968860, 147)
                SCRIPT.SET_GLOBAL_I(1968861, 147)
                SCRIPT.SET_GLOBAL_I(1968862, 147)
                SCRIPT.SET_GLOBAL_I(262145 + 28472, 1410065408)
            -- GLOBAL
            end
        end
    end
)

local ExecuteOnce = {
    {"H3_COMPLETEDPOSIX", -1},
    {"H3OPT_MASKS", 2},
    {"H3OPT_WEAPS", 1},
    {"H3OPT_VEHS", 3}
}

local BIGCON_PRESET_NO_LIMIT = {
    {"CAS_HEIST_FLOW", -1},
    {"H3_LAST_APPROACH", 0},
    {"H3OPT_APPROACH", 2},
    {"H3_HARD_APPROACH", 0},
    {"H3OPT_TARGET", 3},
    {"H3OPT_POI", 1023},
    {"H3OPT_ACCESSPOINTS", 2047},
    {"H3OPT_CREWWEAP", 4},
    {"H3OPT_CREWDRIVER", 3},
    {"H3OPT_CREWHACKER", 4},
    {"H3OPT_DISRUPTSHIP", 3},
    {"H3OPT_BODYARMORLVL", -1},
    {"H3OPT_KEYLEVELS", 2},
    {"H3OPT_BITSET1", 159},
    {"H3OPT_BITSET0", 524118}
}

toggle(
    "DiamondCasinoHeist",
    "NoLim",
    false,
    "BigConNoLimBio",
    function(on)
        for i = 1, #ExecuteOnce do
            if NETWORK then
                STAT_SET_INT(ExecuteOnce[i][1], ExecuteOnce[i][2])
            -- INT
            end
        end
        bigconlim = on
        while bigconlim do
            SYSTEM.WAIT(100)
            if NETWORK then
                for i = 1, #BIGCON_PRESET_NO_LIMIT do
                    STAT_SET_INT(BIGCON_PRESET_NO_LIMIT[i][1], BIGCON_PRESET_NO_LIMIT[i][2])
                    -- INT
                end
                SCRIPT.SET_GLOBAL_I(1966739 + 2326, 60)
                SCRIPT.SET_GLOBAL_I(1968860, 147)
                SCRIPT.SET_GLOBAL_I(1968861, 147)
                SCRIPT.SET_GLOBAL_I(1968862, 147)
                SCRIPT.SET_GLOBAL_I(262145 + 28472, 1410065408)
            -- GLOBAL
            end
        end
    end
)

button(
    "DiamondCasinoHeist",
    "ReHei",
    function()
        if NETWORK then
            STAT_SET_INT("H3_LAST_APPROACH", 0)
            STAT_SET_INT("H3OPT_APPROACH", 0)
            STAT_SET_INT("H3_HARD_APPROACH", 0)
            STAT_SET_INT("H3OPT_TARGET", 0)
            STAT_SET_INT("H3OPT_POI", 0)
            STAT_SET_INT("H3OPT_ACCESSPOINTS", 0)
            STAT_SET_INT("H3OPT_BITSET1", 0)
            STAT_SET_INT("H3OPT_CREWWEAP", 0)
            STAT_SET_INT("H3OPT_CREWDRIVER", 0)
            STAT_SET_INT("H3OPT_CREWHACKER", 0)
            STAT_SET_INT("H3OPT_WEAPS", 0)
            STAT_SET_INT("H3OPT_VEHS", 0)
            STAT_SET_INT("H3OPT_DISRUPTSHIP", 0)
            STAT_SET_INT("H3OPT_BODYARMORLVL", 0)
            STAT_SET_INT("H3OPT_KEYLEVELS", 0)
            STAT_SET_INT("H3OPT_MASKS", 0)
            STAT_SET_INT("H3OPT_BITSET0", 0)
        end
    end
)

-- [[ Casino Advanced ]] --

separator("DiamondCasinoHeist", "CsAdv")

-- [[ Player Cut Manager ]] --

submenu("DiamondCasinoHeist", "PlCuMan")

-- [[ Casino Cut ]] --

separator("PlCuMan", "Casino Cut")

input(
    "PlCuMan",
    "pl1",
    0,
    0,
    1000,
    function(cut1)
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(1968860, cut1)
        end
    end
)

input(
    "PlCuMan",
    "pl2",
    0,
    0,
    1000,
    function(cut2)
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(1968861, cut2)
        end
    end
)

input(
    "PlCuMan",
    "pl3",
    0,
    0,
    1000,
    function(cut3)
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(1968862, cut3)
        end
    end
)

input(
    "PlCuMan",
    "pl4",
    0,
    0,
    1000,
    function(cut4)
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(1968863, cut4)
        end
    end
)

--[[ input("DiamondCasinoHeist, "CrLi", 0, 0, 50, function(dcr)
        if SCRIPT.IS_SCRIPT_LOADED(g_util.joaat("fm_mission_controller")) then
                SCRIPT.SET_LOCAL_I(g_util.joaat("fm_mission_controller"), 27589 + 4288 + 1, dcr)
        end
end) --]]

button(
    "DiamondCasinoHeist",
    "AgaBaker",
    "AgaBakerBio",
    function()
        if NETWORK then
            STAT_SET_INT("VCM_FLOW_PROGRESS", -1)
            STAT_SET_INT("VCM_STORY_PROGRESS", 5)
            STAT_SET_BOOL("AWD_LEADER", true)
            STAT_SET_BOOL("VCM_FLOW_CS_FIN_SEEN", true)
        end
    end
)

button(
    "DiamondCasinoHeist",
    "UnlPoAc",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_POI", -1)
            STAT_SET_INT("H3OPT_ACCESSPOINTS", -1)
        end
    end
)

button(
    "DiamondCasinoHeist",
    "UnCard2",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_KEYLEVELS", 2)
        end
    end
)

button(
    "DiamondCasinoHeist",
    "WeakDug",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_DISRUPTSHIP", 3)
        end
    end
)

button(
    "DiamondCasinoHeist",
    "ReDri",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_BITSET0", -8849)
        end
    end
)

button(
    "DiamondCasinoHeist",
    "ReDriBig",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_BITSET0", -186)
        end
    end
)

-- [[ Casino Equipment ]] --

separator("DiamondCasinoHeist", "CsEq")

-- [[ Casino Primary Target ]] --

submenu("DiamondCasinoHeist", "CsPriTar")

button(
    "CsPriTar",
    "CsDia",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_TARGET", 3)
        end
    end
)

button(
    "CsPriTar",
    "CsGold",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_TARGET", 1)
        end
    end
)

button(
    "CsPriTar",
    "CsArt",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_TARGET", 2)
        end
    end
)

button(
    "CsPriTar",
    "CsCash",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_TARGET", 0)
        end
    end
)

-- [[ Choose Mask ]] --

submenu("DiamondCasinoHeist", "CsMask")

button(
    "CsMask",
    "ReMask",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_MASKS", -1)
        end
    end
)

button(
    "CsMask",
    "GeoSet",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_MASKS", 1)
        end
    end
)

button(
    "CsMask",
    "HunterSet",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_MASKS", 2)
        end
    end
)

button(
    "CsMask",
    "OniMask",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_MASKS", 3)
        end
    end
)

button(
    "CsMask",
    "EmojiSet",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_MASKS", 4)
        end
    end
)

button(
    "CsMask",
    "OrnateSet",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_MASKS", 5)
        end
    end
)

button(
    "CsMask",
    "FruitSet",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_MASKS", 6)
        end
    end
)

button(
    "CsMask",
    "GuerillaSet",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_MASKS", 7)
        end
    end
)

button(
    "CsMask",
    "ClownSet",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_MASKS", 8)
        end
    end
)

button(
    "CsMask",
    "AnimalSet",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_MASKS", 9)
        end
    end
)

button(
    "CsMask",
    "RiotSet",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_MASKS", 10)
        end
    end
)

button(
    "CsMask",
    "OniSet",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_MASKS", 11)
        end
    end
)

button(
    "CsMask",
    "HocketSet",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_MASKS", 12)
        end
    end
)

-- [[ Change Gunman ]] -

submenu("DiamondCasinoHeist", "ChGun")

button(
    "ChGun",
    "McCoy",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_CREWWEAP", 4)
        end
    end
)

button(
    "ChGun",
    "Mota",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_CREWWEAP", 1)
        end
    end
)

button(
    "ChGun",
    "McReary",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_CREWWEAP", 5)
        end
    end
)

button(
    "ChGun",
    "Reed",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_CREWWEAP", 3)
        end
    end
)

button(
    "ChGun",
    "Abolaji",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_CREWWEAP", 1)
        end
    end
)

button(
    "ChGun",
    "NoGunMem",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_CREWWEAP", 6)
        end
    end
)

-- [[ Change Driver ]] -

submenu("DiamondCasinoHeist", "ChDriver")

button(
    "ChDriver",
    "McCoy",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_CREWDRIVER", 5)
        end
    end
)

button(
    "ChDriver",
    "Toh",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_CREWDRIVER", 3)
        end
    end
)

button(
    "ChDriver",
    "Martinez",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_CREWDRIVER", 2)
        end
    end
)

button(
    "ChDriver",
    "Nelson",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_CREWDRIVER", 4)
        end
    end
)

button(
    "ChDriver",
    "Denz",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_CREWDRIVER", 1)
        end
    end
)

button(
    "ChDriver",
    "NoDriver",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_CREWDRIVER", 6)
        end
    end
)

-- [[ Change Hacker ]] --

submenu("DiamondCasinoHeist", "ChHacker")

button(
    "ChHacker",
    "Schwartzman",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_CREWHACKER", 4)
        end
    end
)

button(
    "ChHacker",
    "Harris",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_CREWHACKER", 5)
        end
    end
)

button(
    "ChHacker",
    "Feltz",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_CREWHACKER", 2)
        end
    end
)

button(
    "ChHacker",
    "Blair",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_CREWHACKER", 3)
        end
    end
)

button(
    "ChHacker",
    "Luken",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_CREWHACKER", 1)
        end
    end
)

button(
    "ChHacker",
    "NoHacker",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_CREWHACKER", 6)
        end
    end
)

-- [[ Vehicle Variation ]] --

submenu("DiamondCasinoHeist", "VehVari")

button(
    "VehVari",
    "BestVariVeh",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_VEHS", 3)
        end
    end
)

button(
    "VehVari",
    "GoodVariVeh",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_VEHS", 2)
        end
    end
)

button(
    "VehVari",
    "FineVariVeh",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_VEHS", 1)
        end
    end
)

button(
    "VehVari",
    "WorstVariVeh",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_VEHS", 0)
        end
    end
)

-- [[ Weapon Variation ]] --

submenu("DiamondCasinoHeist", "WeaponVari")

button(
    "WeaponVari",
    "BestVariWep",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_WEAPS", 1)
        end
    end
)

button(
    "WeaponVari",
    "WorstVariWep",
    function()
        if NETWORK then
            STAT_SET_INT("H3OPT_WEAPS", 0)
        end
    end
)

-- [[ Casino Difficulty ]] --

submenu("DiamondCasinoHeist", "CsDif")

-- [[ Silent & Sneaky (Dif) ]] --

separator("CsDif", "Silent & Sneaky")

button(
    "CsDif",
    "Hard",
    function()
        if NETWORK then
            STAT_SET_INT("H3_LAST_APPROACH", 0)
            STAT_SET_INT("H3OPT_APPROACH", 1)
            STAT_SET_INT("H3_HARD_APPROACH", 1)
        end
    end
)

button(
    "CsDif",
    "Normal",
    function()
        if NETWORK then
            STAT_SET_INT("H3_LAST_APPROACH", 0)
            STAT_SET_INT("H3OPT_APPROACH", 1)
            STAT_SET_INT("H3_HARD_APPROACH", 0)
        end
    end
)

-- [[ The Big Con (Dif) ]] --

separator("CsDif", "The Big Con")

button(
    "CsDif",
    "Hard",
    function()
        if NETWORK then
            STAT_SET_INT("H3_LAST_APPROACH", 0)
            STAT_SET_INT("H3OPT_APPROACH", 2)
            STAT_SET_INT("H3_HARD_APPROACH", 2)
        end
    end
)

button(
    "CsDif",
    "Normal",
    function()
        if NETWORK then
            STAT_SET_INT("H3_LAST_APPROACH", 0)
            STAT_SET_INT("H3OPT_APPROACH", 2)
            STAT_SET_INT("H3_HARD_APPROACH", 0)
        end
    end
)

-- [[ Aggressive (Dif) ]] --

separator("CsDif", "Aggressive")

button(
    "CsDif",
    "Hard",
    function()
        if NETWORK then
            STAT_SET_INT("H3_LAST_APPROACH", 0)
            STAT_SET_INT("H3OPT_APPROACH", 3)
            STAT_SET_INT("H3_HARD_APPROACH", 2)
        end
    end
)

button(
    "CsDif",
    "Normal",
    function()
        if NETWORK then
            STAT_SET_INT("H3_LAST_APPROACH", 0)
            STAT_SET_INT("H3OPT_APPROACH", 3)
            STAT_SET_INT("H3_HARD_APPROACH", 0)
        end
    end
)

-- [[ Heist Board ]] --

separator("DiamondCasinoHeist", "HeiBo")

toggle(
    "DiamondCasinoHeist",
    "LoBo",
    false,
    function(on)
        lo = on
        while lo do
            SYSTEM.WAIT(100)
            if NETWORK then
                STAT_SET_INT("H3OPT_BITSET1", -1)
                STAT_SET_INT("H3OPT_BITSET0", -1)
            end
        end
    end
)

toggle(
    "DiamondCasinoHeist",
    "UnBo",
    false,
    function(on)
        unlo = on
        while unlo do
            SYSTEM.WAIT(100)
            if NETWORK then
                STAT_SET_INT("H3OPT_BITSET1", 0)
                STAT_SET_INT("H3OPT_BITSET0", 0)
            end
        end
    end
)

--- [[ Other ]] ---

-- [[ Unlocks ]] --

submenu("RemainingOptions", "Unlocks")

button(
    "Unlocks",
    "PerAw",
    "NewAcc",
    function()
        if NETWORK then
            -- BOOL
            STAT_SET_BOOL("AWD_INTELGATHER", true)
            STAT_SET_BOOL("AWD_COMPOUNDINFILT", true)
            STAT_SET_BOOL("AWD_LOOT_FINDER", true)
            STAT_SET_BOOL("AWD_MAX_DISRUPT", true)
            STAT_SET_BOOL("AWD_THE_ISLAND_HEIST", true)
            STAT_SET_BOOL("AWD_GOING_ALONE", true)
            STAT_SET_BOOL("AWD_TEAM_WORK", true)
            STAT_SET_BOOL("AWD_MIXING_UP", true)
            STAT_SET_BOOL("AWD_PRO_THIEF", true)
            STAT_SET_BOOL("AWD_CAT_BURGLAR", true)
            STAT_SET_BOOL("AWD_ONE_OF_THEM", true)
            STAT_SET_BOOL("AWD_GOLDEN_GUN", true)
            STAT_SET_BOOL("AWD_ELITE_THIEF", true)
            STAT_SET_BOOL("AWD_PROFESSIONAL", true)
            STAT_SET_BOOL("AWD_HELPING_OUT", true)
            STAT_SET_BOOL("AWD_COURIER", true)
            STAT_SET_BOOL("AWD_PARTY_VIBES", true)
            STAT_SET_BOOL("AWD_HELPING_HAND", true)
            STAT_SET_BOOL("AWD_ELEVENELEVEN", true)
            STAT_SET_BOOL("COMPLETE_H4_F_USING_VETIR", true)
            STAT_SET_BOOL("COMPLETE_H4_F_USING_LONGFIN", true)
            STAT_SET_BOOL("COMPLETE_H4_F_USING_ANNIH", true)
            STAT_SET_BOOL("COMPLETE_H4_F_USING_ALKONOS", true)
            STAT_SET_BOOL("COMPLETE_H4_F_USING_PATROLB", true)
            -- INT
            STAT_SET_INT("AWD_LOSTANDFOUND", 500000)
            STAT_SET_INT("AWD_SUNSET", 1800000)
            STAT_SET_INT("AWD_TREASURE_HUNTER", 1000000)
            STAT_SET_INT("AWD_WRECK_DIVING", 1000000)
            STAT_SET_INT("AWD_KEINEMUSIK", 1800000)
            STAT_SET_INT("AWD_PALMS_TRAX", 1800000)
            STAT_SET_INT("AWD_MOODYMANN", 1800000)
            STAT_SET_INT("AWD_FILL_YOUR_BAGS", 1000000000)
            STAT_SET_INT("AWD_WELL_PREPARED", 80)
            STAT_SET_INT("H4_H4_DJ_MISSIONS", 0xFFFFFFF)
        end
    end
)

button(
    "Unlocks",
    "CsAw",
    "NewAcc",
    function()
        if NETWORK then
            -- BOOL
            STAT_SET_BOOL("AWD_FIRST_TIME1", true)
            STAT_SET_BOOL("AWD_FIRST_TIME2", true)
            STAT_SET_BOOL("AWD_FIRST_TIME3", true)
            STAT_SET_BOOL("AWD_FIRST_TIME4", true)
            STAT_SET_BOOL("AWD_FIRST_TIME5", true)
            STAT_SET_BOOL("AWD_FIRST_TIME6", true)
            STAT_SET_BOOL("AWD_ALL_IN_ORDER", true)
            STAT_SET_BOOL("AWD_SUPPORTING_ROLE", true)
            STAT_SET_BOOL("AWD_LEADER", true)
            STAT_SET_BOOL("AWD_ODD_JOBS", true)
            STAT_SET_BOOL("AWD_SURVIVALIST", true)
            STAT_SET_BOOL("AWD_SCOPEOUT", true)
            STAT_SET_BOOL("AWD_CREWEDUP", true)
            STAT_SET_BOOL("AWD_MOVINGON", true)
            STAT_SET_BOOL("AWD_PROMOCAMP", true)
            STAT_SET_BOOL("AWD_GUNMAN", true)
            STAT_SET_BOOL("AWD_SMASHNGRAB", true)
            STAT_SET_BOOL("AWD_INPLAINSI", true)
            STAT_SET_BOOL("AWD_UNDETECTED", true)
            STAT_SET_BOOL("AWD_ALLROUND", true)
            STAT_SET_BOOL("AWD_ELITETHEIF", true)
            STAT_SET_BOOL("AWD_PRO", true)
            STAT_SET_BOOL("AWD_SUPPORTACT", true)
            STAT_SET_BOOL("AWD_SHAFTED", true)
            STAT_SET_BOOL("AWD_COLLECTOR", true)
            STAT_SET_BOOL("AWD_DEADEYE", true)
            STAT_SET_BOOL("AWD_PISTOLSATDAWN", true)
            STAT_SET_BOOL("AWD_TRAFFICAVOI", true)
            STAT_SET_BOOL("AWD_CANTCATCHBRA", true)
            STAT_SET_BOOL("AWD_WIZHARD", true)
            STAT_SET_BOOL("AWD_APEESCAPE", true)
            STAT_SET_BOOL("AWD_MONKEYKIND", true)
            STAT_SET_BOOL("AWD_AQUAAPE", true)
            STAT_SET_BOOL("AWD_KEEPFAITH", true)
            STAT_SET_BOOL("AWD_TRUELOVE", true)
            STAT_SET_BOOL("AWD_NEMESIS", true)
            STAT_SET_BOOL("AWD_FRIENDZONED", true)
            STAT_SET_BOOL("VCM_FLOW_CS_RSC_SEEN", true)
            STAT_SET_BOOL("VCM_FLOW_CS_BWL_SEEN", true)
            STAT_SET_BOOL("VCM_FLOW_CS_MTG_SEEN", true)
            STAT_SET_BOOL("VCM_FLOW_CS_OIL_SEEN", true)
            STAT_SET_BOOL("VCM_FLOW_CS_DEF_SEEN", true)
            STAT_SET_BOOL("VCM_FLOW_CS_FIN_SEEN", true)
            STAT_SET_BOOL("CAS_VEHICLE_REWARD", false)
            STAT_SET_BOOL("HELP_FURIA", true)
            STAT_SET_BOOL("HELP_MINITAN", true)
            STAT_SET_BOOL("HELP_YOSEMITE2", true)
            STAT_SET_BOOL("HELP_ZHABA", true)
            STAT_SET_BOOL("HELP_IMORGEN", true)
            STAT_SET_BOOL("HELP_SULTAN2", true)
            STAT_SET_BOOL("HELP_VAGRANT", true)
            STAT_SET_BOOL("HELP_VSTR", true)
            STAT_SET_BOOL("HELP_STRYDER", true)
            STAT_SET_BOOL("HELP_SUGOI", true)
            STAT_SET_BOOL("HELP_KANJO", true)
            STAT_SET_BOOL("HELP_FORMULA", true)
            STAT_SET_BOOL("HELP_FORMULA2", true)
            STAT_SET_BOOL("HELP_JB7002", true)
            -- INT
            STAT_SET_INT("CAS_HEIST_NOTS", -1)
            STAT_SET_INT("CAS_HEIST_FLOW", -1)
            STAT_SET_INT("CH_ARC_CAB_CLAW_TROPHY", -1)
            STAT_SET_INT("CH_ARC_CAB_LOVE_TROPHY", -1)
            STAT_SET_INT("SIGNAL_JAMMERS_COLLECTED", 50)
            STAT_SET_INT("AWD_ODD_JOBS", 52)
            STAT_SET_INT("AWD_PREPARATION", 40)
            STAT_SET_INT("AWD_ASLEEPONJOB", 20)
            STAT_SET_INT("AWD_DAICASHCRAB", 100000)
            STAT_SET_INT("AWD_BIGBRO", 40)
            STAT_SET_INT("AWD_SHARPSHOOTER", 40)
            STAT_SET_INT("AWD_RACECHAMP", 40)
            STAT_SET_INT("AWD_BATSWORD", 1000000)
            STAT_SET_INT("AWD_COINPURSE", 950000)
            STAT_SET_INT("AWD_ASTROCHIMP", 3000000)
            STAT_SET_INT("AWD_MASTERFUL", 40000)
            STAT_SET_INT("H3_BOARD_DIALOGUE0", -1)
            STAT_SET_INT("H3_BOARD_DIALOGUE1", -1)
            STAT_SET_INT("H3_BOARD_DIALOGUE2", -1)
            STAT_SET_INT("H3_VEHICLESUSED", -1)
            STAT_SET_INT("H3_CR_STEALTH_1A", 100)
            STAT_SET_INT("H3_CR_STEALTH_2B_RAPP", 100)
            STAT_SET_INT("H3_CR_STEALTH_2C_SIDE", 100)
            STAT_SET_INT("H3_CR_STEALTH_3A", 100)
            STAT_SET_INT("H3_CR_STEALTH_4A", 100)
            STAT_SET_INT("H3_CR_STEALTH_5A", 100)
            STAT_SET_INT("H3_CR_SUBTERFUGE_1A", 100)
            STAT_SET_INT("H3_CR_SUBTERFUGE_2A", 100)
            STAT_SET_INT("H3_CR_SUBTERFUGE_2B", 100)
            STAT_SET_INT("H3_CR_SUBTERFUGE_3A", 100)
            STAT_SET_INT("H3_CR_SUBTERFUGE_3B", 100)
            STAT_SET_INT("H3_CR_SUBTERFUGE_4A", 100)
            STAT_SET_INT("H3_CR_SUBTERFUGE_5A", 100)
            STAT_SET_INT("H3_CR_DIRECT_1A", 100)
            STAT_SET_INT("H3_CR_DIRECT_2A1", 100)
            STAT_SET_INT("H3_CR_DIRECT_2A2", 100)
            STAT_SET_INT("H3_CR_DIRECT_2BP", 100)
            STAT_SET_INT("H3_CR_DIRECT_2C", 100)
            STAT_SET_INT("H3_CR_DIRECT_3A", 100)
            STAT_SET_INT("H3_CR_DIRECT_4A", 100)
            STAT_SET_INT("H3_CR_DIRECT_5A", 100)
            STAT_SET_INT("CR_ORDER", 100)
        end
    end
)

button(
    "Unlocks",
    "ClAw",
    "NewAcc",
    function()
        if NETWORK then
            -- BOOL
            STAT_SET_BOOL("MPPLY_AWD_COMPLET_HEIST_MEM", true)
            STAT_SET_BOOL("MPPLY_AWD_COMPLET_HEIST_1STPER", true)
            STAT_SET_BOOL("MPPLY_AWD_FLEECA_FIN", true)
            STAT_SET_BOOL("MPPLY_AWD_HST_ORDER", true)
            STAT_SET_BOOL("MPPLY_AWD_HST_SAME_TEAM", true)
            STAT_SET_BOOL("MPPLY_AWD_HST_ULT_CHAL", true)
            STAT_SET_BOOL("MPPLY_AWD_HUMANE_FIN", true)
            STAT_SET_BOOL("MPPLY_AWD_PACIFIC_FIN", true)
            STAT_SET_BOOL("MPPLY_AWD_PRISON_FIN", true)
            STAT_SET_BOOL("MPPLY_AWD_SERIESA_FIN", true)
            STAT_SET_BOOL("AWD_FINISH_HEIST_NO_DAMAGE", true)
            STAT_SET_BOOL("AWD_SPLIT_HEIST_TAKE_EVENLY", true)
            STAT_SET_BOOL("AWD_ALL_ROLES_HEIST", true)
            STAT_SET_BOOL("AWD_MATCHING_OUTFIT_HEIST", true)
            STAT_SET_BOOL("HEIST_PLANNING_DONE_PRINT", true)
            STAT_SET_BOOL("HEIST_PLANNING_DONE_HELP_0", true)
            STAT_SET_BOOL("HEIST_PLANNING_DONE_HELP_1", true)
            STAT_SET_BOOL("HEIST_PRE_PLAN_DONE_HELP_0", true)
            STAT_SET_BOOL("HEIST_CUTS_DONE_FINALE", true)
            STAT_SET_BOOL("HEIST_IS_TUTORIAL", false)
            STAT_SET_BOOL("HEIST_STRAND_INTRO_DONE", true)
            STAT_SET_BOOL("HEIST_CUTS_DONE_ORNATE", true)
            STAT_SET_BOOL("HEIST_CUTS_DONE_PRISON", true)
            STAT_SET_BOOL("HEIST_CUTS_DONE_BIOLAB", true)
            STAT_SET_BOOL("HEIST_CUTS_DONE_NARCOTIC", true)
            STAT_SET_BOOL("HEIST_CUTS_DONE_TUTORIAL", true)
            STAT_SET_BOOL("HEIST_AWARD_DONE_PREP", true)
            STAT_SET_BOOL("HEIST_AWARD_BOUGHT_IN", true)
            -- INT
            STAT_SET_INT("AWD_FINISH_HEISTS", 900)
            STAT_SET_INT("MPPLY_WIN_GOLD_MEDAL_HEISTS", 900)
            STAT_SET_INT("AWD_DO_HEIST_AS_MEMBER", 900)
            STAT_SET_INT("AWD_DO_HEIST_AS_THE_LEADER", 900)
            STAT_SET_INT("AWD_FINISH_HEIST_SETUP_JOB", 900)
            STAT_SET_INT("AWD_FINISH_HEIST", 900)
            STAT_SET_INT("HEIST_COMPLETION", 900)
            STAT_SET_INT("HEISTS_ORGANISED", 900)
            STAT_SET_INT("AWD_CONTROL_CROWDS", 900)
            STAT_SET_INT("AWD_WIN_GOLD_MEDAL_HEISTS", 900)
            STAT_SET_INT("AWD_COMPLETE_HEIST_NOT_DIE", 900)
            STAT_SET_INT("HEIST_START", 900)
            STAT_SET_INT("HEIST_END", 900)
            STAT_SET_INT("CUTSCENE_MID_PRISON", 900)
            STAT_SET_INT("CUTSCENE_MID_HUMANE", 900)
            STAT_SET_INT("CUTSCENE_MID_NARC", 900)
            STAT_SET_INT("CUTSCENE_MID_ORNATE", 900)
            STAT_SET_INT("CR_FLEECA_PREP_1", 5000)
            STAT_SET_INT("CR_FLEECA_PREP_2", 5000)
            STAT_SET_INT("CR_FLEECA_FINALE", 5000)
            STAT_SET_INT("CR_PRISON_PLANE", 5000)
            STAT_SET_INT("CR_PRISON_BUS", 5000)
            STAT_SET_INT("CR_PRISON_STATION", 5000)
            STAT_SET_INT("CR_PRISON_UNFINISHED_BIZ", 5000)
            STAT_SET_INT("CR_PRISON_FINALE", 5000)
            STAT_SET_INT("CR_HUMANE_KEY_CODES", 5000)
            STAT_SET_INT("CR_HUMANE_ARMORDILLOS", 5000)
            STAT_SET_INT("CR_HUMANE_EMP", 5000)
            STAT_SET_INT("CR_HUMANE_VALKYRIE", 5000)
            STAT_SET_INT("CR_HUMANE_FINALE", 5000)
            STAT_SET_INT("CR_NARC_COKE", 5000)
            STAT_SET_INT("CR_NARC_TRASH_TRUCK", 5000)
            STAT_SET_INT("CR_NARC_BIKERS", 5000)
            STAT_SET_INT("CR_NARC_WEED", 5000)
            STAT_SET_INT("CR_NARC_STEAL_METH", 5000)
            STAT_SET_INT("CR_NARC_FINALE", 5000)
            STAT_SET_INT("CR_PACIFIC_TRUCKS", 5000)
            STAT_SET_INT("CR_PACIFIC_WITSEC", 5000)
            STAT_SET_INT("CR_PACIFIC_HACK", 5000)
            STAT_SET_INT("CR_PACIFIC_BIKES", 5000)
            STAT_SET_INT("CR_PACIFIC_CONVOY", 5000)
            STAT_SET_INT("CR_PACIFIC_FINALE", 5000)
            STAT_SET_INT("MPPLY_HEIST_ACH_TRACKER", -1)
        end
    end
)

button(
    "Unlocks",
    "TunAw",
    "NewAcc",
    function()
        if NETWORK then
            -- BOOL
            STAT_SET_BOOL("AWD_CAR_CLUB", true)
            STAT_SET_BOOL("AWD_PRO_CAR_EXPORT", true)
            STAT_SET_BOOL("AWD_UNION_DEPOSITORY", true)
            STAT_SET_BOOL("AWD_MILITARY_CONVOY", true)
            STAT_SET_BOOL("AWD_FLEECA_BANK", true)
            STAT_SET_BOOL("AWD_FREIGHT_TRAIN", true)
            STAT_SET_BOOL("AWD_BOLINGBROKE_ASS", true)
            STAT_SET_BOOL("AWD_IAA_RAID", true)
            STAT_SET_BOOL("AWD_METH_JOB", true)
            STAT_SET_BOOL("AWD_BUNKER_RAID", true)
            STAT_SET_BOOL("AWD_STRAIGHT_TO_VIDEO", true)
            STAT_SET_BOOL("AWD_MONKEY_C_MONKEY_DO", true)
            STAT_SET_BOOL("AWD_TRAINED_TO_KILL", true)
            STAT_SET_BOOL("AWD_DIRECTOR", true)
            -- INT
            STAT_SET_INT("AWD_CAR_CLUB_MEM", 100)
            STAT_SET_INT("AWD_SPRINTRACER", 50)
            STAT_SET_INT("AWD_STREETRACER", 50)
            STAT_SET_INT("AWD_PURSUITRACER", 50)
            STAT_SET_INT("AWD_TEST_CAR", 240)
            STAT_SET_INT("AWD_AUTO_SHOP", 50)
            STAT_SET_INT("AWD_CAR_EXPORT", 100)
            STAT_SET_INT("AWD_GROUNDWORK", 40)
            STAT_SET_INT("AWD_ROBBERY_CONTRACT", 100)
            STAT_SET_INT("AWD_FACES_OF_DEATH", 100)
        end
    end
)

button(
    "Unlocks",
    "AgAw",
    "NewAcc",
    function()
        if NETWORK then
            -- BOOL
            STAT_SET_BOOL("AWD_TEEING_OFF", true)
            STAT_SET_BOOL("AWD_PARTY_NIGHT", true)
            STAT_SET_BOOL("AWD_BILLIONAIRE_GAMES", true)
            STAT_SET_BOOL("AWD_HOOD_PASS", true)
            STAT_SET_BOOL("AWD_STUDIO_TOUR", true)
            STAT_SET_BOOL("AWD_DONT_MESS_DRE", true)
            STAT_SET_BOOL("AWD_BACKUP", true)
            STAT_SET_BOOL("AWD_SHORTFRANK_1", true)
            STAT_SET_BOOL("AWD_SHORTFRANK_2", true)
            STAT_SET_BOOL("AWD_SHORTFRANK_3", true)
            STAT_SET_BOOL("AWD_CONTR_KILLER", true)
            STAT_SET_BOOL("AWD_DOGS_BEST_FRIEND", true)
            STAT_SET_BOOL("AWD_MUSIC_STUDIO", true)
            STAT_SET_BOOL("AWD_SHORTLAMAR_1", true)
            STAT_SET_BOOL("AWD_SHORTLAMAR_2", true)
            STAT_SET_BOOL("AWD_SHORTLAMAR_3", true)
            -- INT
            STAT_SET_INT("AWD_CONTRACTOR", 50)
            STAT_SET_INT("AWD_COLD_CALLER", 50)
            STAT_SET_INT("AWD_PRODUCER", 60)
            STAT_SET_INT("FIXERTELEPHONEHITSCOMPL", 10)
            STAT_SET_INT("PAYPHONE_BONUS_KILL_METHOD", 10)
            STAT_SET_INT("FIXER_COUNT", 501)
            STAT_SET_INT("FIXER_SC_VEH_RECOVERED", 501)
            STAT_SET_INT("FIXER_SC_VAL_RECOVERED", 501)
            STAT_SET_INT("FIXER_SC_GANG_TERMINATED", 501)
            STAT_SET_INT("FIXER_SC_VIP_RESCUED", 501)
            STAT_SET_INT("FIXER_SC_ASSETS_PROTECTED", 501)
            STAT_SET_INT("FIXER_SC_EQ_DESTROYED", 501)
            STAT_SET_INT("FIXER_EARNINGS", 300000)
        end
    end
)

button(
    "Unlocks",
    "DoomAw",
    "NewAcc",
    function()
        if NETWORK then
            -- BOOL
            STAT_SET_BOOL_MPPLY("MPPLY_AWD_GANGOPS_IAA", true)
            STAT_SET_BOOL_MPPLY("MPPLY_AWD_GANGOPS_SUBMARINE", true)
            STAT_SET_BOOL_MPPLY("MPPLY_AWD_GANGOPS_MISSILE", true)
            STAT_SET_BOOL_MPPLY("MPPLY_AWD_GANGOPS_ALLINORDER", true)
            STAT_SET_BOOL_MPPLY("MPPLY_AWD_GANGOPS_LOYALTY", true)
            STAT_SET_BOOL_MPPLY("MPPLY_AWD_GANGOPS_LOYALTY2", true)
            STAT_SET_BOOL_MPPLY("MPPLY_AWD_GANGOPS_LOYALTY3", true)
            STAT_SET_BOOL_MPPLY("MPPLY_AWD_GANGOPS_CRIMMASMD", true)
            STAT_SET_BOOL_MPPLY("MPPLY_AWD_GANGOPS_CRIMMASMD2", true)
            STAT_SET_BOOL_MPPLY("MPPLY_AWD_GANGOPS_CRIMMASMD3", true)
            -- INT
            STAT_SET_INT("GANGOPS_FM_MISSION_PROG", 0xFFFFFFF)
            STAT_SET_INT("GANGOPS_FLOW_MISSION_PROG", 0xFFFFFFF)
            STAT_SET_INT_MPPLY("MPPLY_GANGOPS_ALLINORDER", 100)
            STAT_SET_INT_MPPLY("MPPLY_GANGOPS_LOYALTY", 100)
            STAT_SET_INT_MPPLY("MPPLY_GANGOPS_CRIMMASMD", 100)
            STAT_SET_INT_MPPLY("MPPLY_GANGOPS_LOYALTY2", 100)
            STAT_SET_INT_MPPLY("MPPLY_GANGOPS_LOYALTY3", 100)
            STAT_SET_INT_MPPLY("MPPLY_GANGOPS_CRIMMASMD2", 100)
            STAT_SET_INT_MPPLY("MPPLY_GANGOPS_CRIMMASMD3", 100)
            STAT_SET_INT_MPPLY("MPPLY_GANGOPS_SUPPORT", 100)
            STAT_SET_INT("CR_GANGOP_MORGUE", 10)
            STAT_SET_INT("CR_GANGOP_DELUXO", 10)
            STAT_SET_INT("CR_GANGOP_SERVERFARM", 10)
            STAT_SET_INT("CR_GANGOP_IAABASE_FIN", 10)
            STAT_SET_INT("CR_GANGOP_STEALOSPREY", 10)
            STAT_SET_INT("CR_GANGOP_FOUNDRY", 10)
            STAT_SET_INT("CR_GANGOP_RIOTVAN", 10)
            STAT_SET_INT("CR_GANGOP_SUBMARINECAR", 10)
            STAT_SET_INT("CR_GANGOP_SUBMARINE_FIN", 10)
            STAT_SET_INT("CR_GANGOP_PREDATOR", 10)
            STAT_SET_INT("CR_GANGOP_BMLAUNCHER", 10)
            STAT_SET_INT("CR_GANGOP_BCCUSTOM", 10)
            STAT_SET_INT("CR_GANGOP_STEALTHTANKS", 10)
            STAT_SET_INT("CR_GANGOP_SPYPLANE", 10)
            STAT_SET_INT("CR_GANGOP_FINALE", 10)
            STAT_SET_INT("CR_GANGOP_FINALE_P2", 10)
            STAT_SET_INT("CR_GANGOP_FINALE_P3", 10)
        end
    end
)

button(
    "Unlocks",
    "ArenaTrop",
    "NewAcc",
    function()
        if NETWORK then
            STAT_SET_BOOL("AWD_BEGINNER", true)
            STAT_SET_BOOL("AWD_FIELD_FILLER", true)
            STAT_SET_BOOL("AWD_ARMCHAIR_RACER", true)
            STAT_SET_BOOL("AWD_LEARNER", true)
            STAT_SET_BOOL("AWD_SUNDAY_DRIVER", true)
            STAT_SET_BOOL("AWD_THE_ROOKIE", true)
            STAT_SET_BOOL("AWD_BUMP_AND_RUN", true)
            STAT_SET_BOOL("AWD_GEAR_HEAD", true)
            STAT_SET_BOOL("AWD_DOOR_SLAMMER", true)
            STAT_SET_BOOL("AWD_HOT_LAP", true)
            STAT_SET_BOOL("AWD_ARENA_AMATEUR", true)
            STAT_SET_BOOL("AWD_PAINT_TRADER", true)
            STAT_SET_BOOL("AWD_SHUNTER", true)
            STAT_SET_BOOL("AWD_JOCK", true)
            STAT_SET_BOOL("AWD_WARRIOR", true)
            STAT_SET_BOOL("AWD_T_BONE", true)
            STAT_SET_BOOL("AWD_MAYHEM", true)
            STAT_SET_BOOL("AWD_WRECKER", true)
            STAT_SET_BOOL("AWD_CRASH_COURSE", true)
            STAT_SET_BOOL("AWD_ARENA_LEGEND", true)
            STAT_SET_BOOL("AWD_PEGASUS", true)
            STAT_SET_BOOL("AWD_UNSTOPPABLE", true)
            STAT_SET_BOOL("AWD_CONTACT_SPORT", true)
            -- BOOL
            STAT_SET_INT("ARN_BS_TRINKET_TICKERS", 0xFFFFFFF)
            STAT_SET_INT("ARN_BS_TRINKET_SAVED", 0xFFFFFFF)
            STAT_SET_INT("AWD_WATCH_YOUR_STEP", 50)
            STAT_SET_INT("AWD_TOWER_OFFENSE", 50)
            STAT_SET_INT("AWD_READY_FOR_WAR", 50)
            STAT_SET_INT("AWD_THROUGH_A_LENS", 50)
            STAT_SET_INT("AWD_SPINNER", 50)
            STAT_SET_INT("AWD_YOUMEANBOOBYTRAPS", 50)
            STAT_SET_INT("AWD_MASTER_BANDITO", 50)
            STAT_SET_INT("AWD_SITTING_DUCK", 50)
            STAT_SET_INT("AWD_CROWDPARTICIPATION", 50)
            STAT_SET_INT("AWD_KILL_OR_BE_KILLED", 50)
            STAT_SET_INT("AWD_MASSIVE_SHUNT", 50)
            STAT_SET_INT("AWD_YOURE_OUTTA_HERE", 200)
            STAT_SET_INT("AWD_WEVE_GOT_ONE", 50)
            STAT_SET_INT("AWD_ARENA_WAGEWORKER", 1000000)
            STAT_SET_INT("AWD_TIME_SERVED", 1000)
            STAT_SET_INT("AWD_TOP_SCORE", 55000)
            STAT_SET_INT("AWD_CAREER_WINNER", 1000)
            STAT_SET_INT("ARENAWARS_SP", 209)
            STAT_SET_INT("ARENAWARS_SKILL_LEVEL", 20)
            STAT_SET_INT("ARENAWARS_SP_LIFETIME", 209)
            STAT_SET_INT("ARENAWARS_AP_TIER", 1000)
            STAT_SET_INT("ARENAWARS_AP_LIFETIME", 47551850)
            STAT_SET_INT("ARENAWARS_CARRER_UNLK", 44)
            STAT_SET_INT("ARN_W_THEME_SCIFI", 1000)
            STAT_SET_INT("ARN_W_THEME_APOC", 1000)
            STAT_SET_INT("ARN_W_THEME_CONS", 1000)
            STAT_SET_INT("ARN_W_PASS_THE_BOMB", 1000)
            STAT_SET_INT("ARN_W_DETONATION", 1000)
            STAT_SET_INT("ARN_W_ARCADE_RACE", 1000)
            STAT_SET_INT("ARN_W_CTF", 1000)
            STAT_SET_INT("ARN_W_TAG_TEAM", 1000)
            STAT_SET_INT("ARN_W_DESTR_DERBY", 1000)
            STAT_SET_INT("ARN_W_CARNAGE", 1000)
            STAT_SET_INT("ARN_W_MONSTER_JAM", 1000)
            STAT_SET_INT("ARN_W_GAMES_MASTERS", 1000)
            STAT_SET_INT("ARN_L_PASS_THE_BOMB", 500)
            STAT_SET_INT("ARN_L_DETONATION", 500)
            STAT_SET_INT("ARN_L_ARCADE_RACE", 500)
            STAT_SET_INT("ARN_L_CTF", 500)
            STAT_SET_INT("ARN_L_TAG_TEAM", 500)
            STAT_SET_INT("ARN_L_DESTR_DERBY", 500)
            STAT_SET_INT("ARN_L_CARNAGE", 500)
            STAT_SET_INT("ARN_L_MONSTER_JAM", 500)
            STAT_SET_INT("ARN_L_GAMES_MASTERS", 500)
            STAT_SET_INT("NUMBER_OF_CHAMP_BOUGHT", 1000)
            STAT_SET_INT("ARN_SPECTATOR_KILLS", 1000)
            STAT_SET_INT("ARN_LIFETIME_KILLS", 1000)
            STAT_SET_INT("ARN_LIFETIME_DEATHS", 500)
            STAT_SET_INT("ARENAWARS_CARRER_WINS", 1000)
            STAT_SET_INT("ARENAWARS_CARRER_WINT", 1000)
            STAT_SET_INT("ARENAWARS_MATCHES_PLYD", 1000)
            STAT_SET_INT("ARENAWARS_MATCHES_PLYDT", 1000)
            STAT_SET_INT("ARN_SPEC_BOX_TIME_MS", 86400000)
            STAT_SET_INT("ARN_SPECTATOR_DRONE", 1000)
            STAT_SET_INT("ARN_SPECTATOR_CAMS", 1000)
            STAT_SET_INT("ARN_SMOKE", 1000)
            STAT_SET_INT("ARN_DRINK", 1000)
            STAT_SET_INT("ARN_VEH_MONSTER", 31000)
            STAT_SET_INT("ARN_VEH_MONSTER", 41000)
            STAT_SET_INT("ARN_VEH_MONSTER", 51000)
            STAT_SET_INT("ARN_VEH_CERBERUS", 1000)
            STAT_SET_INT("ARN_VEH_CERBERUS2", 1000)
            STAT_SET_INT("ARN_VEH_CERBERUS3", 1000)
            STAT_SET_INT("ARN_VEH_BRUISER", 1000)
            STAT_SET_INT("ARN_VEH_BRUISER2", 1000)
            STAT_SET_INT("ARN_VEH_BRUISER3", 1000)
            STAT_SET_INT("ARN_VEH_SLAMVAN4", 1000)
            STAT_SET_INT("ARN_VEH_SLAMVAN5", 1000)
            STAT_SET_INT("ARN_VEH_SLAMVAN6", 1000)
            STAT_SET_INT("ARN_VEH_BRUTUS", 1000)
            STAT_SET_INT("ARN_VEH_BRUTUS2", 1000)
            STAT_SET_INT("ARN_VEH_BRUTUS3", 1000)
            STAT_SET_INT("ARN_VEH_SCARAB", 1000)
            STAT_SET_INT("ARN_VEH_SCARAB2", 1000)
            STAT_SET_INT("ARN_VEH_SCARAB3", 1000)
            STAT_SET_INT("ARN_VEH_DOMINATOR4", 1000)
            STAT_SET_INT("ARN_VEH_DOMINATOR5", 1000)
            STAT_SET_INT("ARN_VEH_DOMINATOR6", 1000)
            STAT_SET_INT("ARN_VEH_IMPALER2", 1000)
            STAT_SET_INT("ARN_VEH_IMPALER3", 1000)
            STAT_SET_INT("ARN_VEH_IMPALER4", 1000)
            STAT_SET_INT("ARN_VEH_ISSI4", 1000)
            STAT_SET_INT("ARN_VEH_ISSI5", 1000)
            STAT_SET_INT("ARN_VEH_ISSI", 61000)
            STAT_SET_INT("ARN_VEH_IMPERATOR", 1000)
            STAT_SET_INT("ARN_VEH_IMPERATOR2", 1000)
            STAT_SET_INT("ARN_VEH_IMPERATOR3", 1000)
            STAT_SET_INT("ARN_VEH_ZR380", 1000)
            STAT_SET_INT("ARN_VEH_ZR3802", 1000)
            STAT_SET_INT("ARN_VEH_ZR3803", 1000)
            STAT_SET_INT("ARN_VEH_DEATHBIKE", 1000)
            STAT_SET_INT("ARN_VEH_DEATHBIKE2", 1000)
            STAT_SET_INT("ARN_VEH_DEATHBIKE3", 1000)
        -- INT
        end
    end
)

button(
    "Unlocks",
    "ArenaClo",
    "NewAcc",
    function()
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(262145 + 25506, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25507, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25508, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25509, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25510, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25511, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25512, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25513, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25514, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25515, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25516, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25517, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25518, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25519, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25520, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25521, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25522, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25523, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25524, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25525, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25526, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25527, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25528, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25529, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25530, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25531, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25532, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25533, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25534, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25535, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25536, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25537, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25538, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25539, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25540, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25541, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25542, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25543, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25544, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25545, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25546, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25547, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25548, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25549, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25550, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25551, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25552, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25553, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25554, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25555, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25556, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25557, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25558, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25559, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25560, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25561, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25562, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25563, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25564, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25565, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25566, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25567, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25568, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25569, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25570, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25571, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25572, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25573, 1)
        end
    end
)

button(
    "Unlocks",
    "SumAw",
    "NewAcc",
    function()
        if NETWORK then
            STAT_SET_BOOL("AWD_KINGOFQUB3D", true)
            STAT_SET_BOOL("AWD_QUBISM", true)
            STAT_SET_BOOL("AWD_QUIBITS", true)
            STAT_SET_BOOL("AWD_GODOFQUB3D", true)
            STAT_SET_BOOL("AWD_GOFOR11TH", true)
            STAT_SET_BOOL("AWD_ELEVENELEVEN", true)
        end
    end
)

button(
    "Unlocks",
    "SumClo",
    "NewAcc",
    function()
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(262145 + 29349, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29350, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29351, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29352, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29353, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29354, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29355, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29356, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29357, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29358, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29359, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29360, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29361, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29362, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29363, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29364, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29365, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29366, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29367, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29368, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29369, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29370, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29371, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29372, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29373, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29374, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29375, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29376, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29377, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29378, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29379, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29380, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29381, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29382, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29383, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29384, 1)
        end
    end
)

button(
    "Unlocks",
    "TunOutf",
    "NewAcc",
    function()
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(262145 + 30833, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30834, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30835, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30836, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30837, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30838, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30839, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30840, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30841, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30842, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30843, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30844, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30845, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30846, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30847, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30848, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30849, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30850, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30851, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30852, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30853, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30854, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30669, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30670, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30671, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30672, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30673, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30674, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30675, 1)
            SCRIPT.SET_GLOBAL_I(2863964, 1)
        end
    end
)

button(
    "Unlocks",
    "ArcadeTrop",
    "NewAcc",
    function()
        if NETWORK then
            STAT_SET_BOOL("AWD_SCOPEOUT", true)
            STAT_SET_BOOL("AWD_CREWEDUP", true)
            STAT_SET_BOOL("AWD_MOVINGON", true)
            STAT_SET_BOOL("AWD_PROMOCAMP", true)
            STAT_SET_BOOL("AWD_GUNMAN", true)
            STAT_SET_BOOL("AWD_SMASHNGRAB", true)
            STAT_SET_BOOL("AWD_INPLAINSI", true)
            STAT_SET_BOOL("AWD_UNDETECTED", true)
            STAT_SET_BOOL("AWD_ALLROUND", true)
            STAT_SET_BOOL("AWD_ELITETHEIF", true)
            STAT_SET_BOOL("AWD_PRO", true)
            STAT_SET_BOOL("AWD_SUPPORTACT", true)
            STAT_SET_BOOL("AWD_SHAFTED", true)
            STAT_SET_BOOL("AWD_COLLECTOR", true)
            STAT_SET_BOOL("AWD_DEADEYE", true)
            STAT_SET_BOOL("AWD_PISTOLSATDAWN", true)
            STAT_SET_BOOL("AWD_TRAFFICAVOI", true)
            STAT_SET_BOOL("AWD_CANTCATCHBRA", true)
            STAT_SET_BOOL("AWD_WIZHARD", true)
            STAT_SET_BOOL("AWD_APEESCAP", true)
            STAT_SET_BOOL("AWD_MONKEYKIND", true)
            STAT_SET_BOOL("AWD_AQUAAPE", true)
            STAT_SET_BOOL("AWD_KEEPFAITH", true)
            STAT_SET_BOOL("AWD_TRUELOVE", true)
            STAT_SET_BOOL("AWD_NEMESIS", true)
            STAT_SET_BOOL("AWD_FRIENDZONED", true)
            STAT_SET_BOOL("IAP_CHALLENGE_0", true)
            STAT_SET_BOOL("IAP_CHALLENGE_1", true)
            STAT_SET_BOOL("IAP_CHALLENGE_2", true)
            STAT_SET_BOOL("IAP_CHALLENGE_3", true)
            STAT_SET_BOOL("IAP_CHALLENGE_4", true)
            STAT_SET_BOOL("IAP_GOLD_TANK", true)
            STAT_SET_BOOL("SCGW_WON_NO_DEATHS", true)
            -- BOOL
            STAT_SET_INT("AWD_PREPARATION", 40)
            STAT_SET_INT("AWD_ASLEEPONJOB", 20)
            STAT_SET_INT("AWD_DAICASHCRAB", 100000)
            STAT_SET_INT("AWD_BIGBRO", 40)
            STAT_SET_INT("AWD_SHARPSHOOTER", 40)
            STAT_SET_INT("AWD_RACECHAMP", 40)
            STAT_SET_INT("AWD_BATSWORD", 1000000)
            STAT_SET_INT("AWD_COINPURSE", 950000)
            STAT_SET_INT("AWD_ASTROCHIMP", 3000000)
            STAT_SET_INT("AWD_MASTERFUL", 40000)
            STAT_SET_INT("SCGW_NUM_WINS_GANG_0", 50)
            STAT_SET_INT("SCGW_NUM_WINS_GANG_1", 50)
            STAT_SET_INT("SCGW_NUM_WINS_GANG_2", 50)
            STAT_SET_INT("SCGW_NUM_WINS_GANG_3", 50)
            STAT_SET_INT("CH_ARC_CAB_CLAW_TROPHY", 0xFFFFFFF)
            STAT_SET_INT("CH_ARC_CAB_LOVE_TROPHY", 0xFFFFFFF)
            STAT_SET_INT("IAP_MAX_MOON_DIST", 2147483647)
            STAT_SET_INT("IAP_INITIALS_0", 50)
            STAT_SET_INT("IAP_INITIALS_1", 50)
            STAT_SET_INT("IAP_INITIALS_2", 50)
            STAT_SET_INT("IAP_INITIALS_3", 50)
            STAT_SET_INT("IAP_INITIALS_4", 50)
            STAT_SET_INT("IAP_INITIALS_5", 50)
            STAT_SET_INT("IAP_INITIALS_6", 50)
            STAT_SET_INT("IAP_INITIALS_7", 50)
            STAT_SET_INT("IAP_INITIALS_8", 50)
            STAT_SET_INT("IAP_INITIALS_9", 50)
            STAT_SET_INT("IAP_SCORE_0", 69644)
            STAT_SET_INT("IAP_SCORE_1", 50333)
            STAT_SET_INT("IAP_SCORE_2", 63512)
            STAT_SET_INT("IAP_SCORE_3", 46136)
            STAT_SET_INT("IAP_SCORE_4", 21638)
            STAT_SET_INT("IAP_SCORE_5", 2133)
            STAT_SET_INT("IAP_SCORE_6", 1215)
            STAT_SET_INT("IAP_SCORE_7", 2444)
            STAT_SET_INT("IAP_SCORE_8", 38023)
            STAT_SET_INT("IAP_SCORE_9", 2233)
            STAT_SET_INT("SCGW_SCORE_1", 50)
            STAT_SET_INT("SCGW_SCORE_2", 50)
            STAT_SET_INT("SCGW_SCORE_3", 50)
            STAT_SET_INT("SCGW_SCORE_4", 50)
            STAT_SET_INT("SCGW_SCORE_5", 50)
            STAT_SET_INT("SCGW_SCORE_6", 50)
            STAT_SET_INT("SCGW_SCORE_7", 50)
            STAT_SET_INT("SCGW_SCORE_8", 50)
            STAT_SET_INT("SCGW_SCORE_9", 50)
            STAT_SET_INT("DG_DEFENDER_INITIALS_0", 69644)
            STAT_SET_INT("DG_DEFENDER_INITIALS_1", 69644)
            STAT_SET_INT("DG_DEFENDER_INITIALS_2", 69644)
            STAT_SET_INT("DG_DEFENDER_INITIALS_3", 69644)
            STAT_SET_INT("DG_DEFENDER_INITIALS_4", 69644)
            STAT_SET_INT("DG_DEFENDER_INITIALS_5", 69644)
            STAT_SET_INT("DG_DEFENDER_INITIALS_6", 69644)
            STAT_SET_INT("DG_DEFENDER_INITIALS_7", 69644)
            STAT_SET_INT("DG_DEFENDER_INITIALS_8", 69644)
            STAT_SET_INT("DG_DEFENDER_INITIALS_9", 69644)
            STAT_SET_INT("DG_DEFENDER_SCORE_1", 50)
            STAT_SET_INT("DG_DEFENDER_SCORE_2", 50)
            STAT_SET_INT("DG_DEFENDER_SCORE_3", 50)
            STAT_SET_INT("DG_DEFENDER_SCORE_4", 50)
            STAT_SET_INT("DG_DEFENDER_SCORE_5", 50)
            STAT_SET_INT("DG_DEFENDER_SCORE_6", 50)
            STAT_SET_INT("DG_DEFENDER_SCORE_7", 50)
            STAT_SET_INT("DG_DEFENDER_SCORE_8", 50)
            STAT_SET_INT("DG_DEFENDER_SCORE_9", 50)
            STAT_SET_INT("DG_MONKEY_INITIALS_0", 69644)
            STAT_SET_INT("DG_MONKEY_INITIALS_1", 69644)
            STAT_SET_INT("DG_MONKEY_INITIALS_2", 69644)
            STAT_SET_INT("DG_MONKEY_INITIALS_3", 69644)
            STAT_SET_INT("DG_MONKEY_INITIALS_4", 69644)
            STAT_SET_INT("DG_MONKEY_INITIALS_5", 69644)
            STAT_SET_INT("DG_MONKEY_INITIALS_6", 69644)
            STAT_SET_INT("DG_MONKEY_INITIALS_7", 69644)
            STAT_SET_INT("DG_MONKEY_INITIALS_8", 69644)
            STAT_SET_INT("DG_MONKEY_INITIALS_9", 69644)
            STAT_SET_INT("DG_MONKEY_SCORE_0", 50)
            STAT_SET_INT("DG_MONKEY_SCORE_1", 50)
            STAT_SET_INT("DG_MONKEY_SCORE_2", 50)
            STAT_SET_INT("DG_MONKEY_SCORE_3", 50)
            STAT_SET_INT("DG_MONKEY_SCORE_4", 50)
            STAT_SET_INT("DG_MONKEY_SCORE_5", 50)
            STAT_SET_INT("DG_MONKEY_SCORE_6", 50)
            STAT_SET_INT("DG_MONKEY_SCORE_7", 50)
            STAT_SET_INT("DG_MONKEY_SCORE_8", 50)
            STAT_SET_INT("DG_MONKEY_SCORE_9", 50)
            STAT_SET_INT("DG_PENETRATOR_INITIALS_0", 69644)
            STAT_SET_INT("DG_PENETRATOR_INITIALS_1", 69644)
            STAT_SET_INT("DG_PENETRATOR_INITIALS_2", 69644)
            STAT_SET_INT("DG_PENETRATOR_INITIALS_3", 69644)
            STAT_SET_INT("DG_PENETRATOR_INITIALS_4", 69644)
            STAT_SET_INT("DG_PENETRATOR_INITIALS_5", 69644)
            STAT_SET_INT("DG_PENETRATOR_INITIALS_6", 69644)
            STAT_SET_INT("DG_PENETRATOR_INITIALS_7", 69644)
            STAT_SET_INT("DG_PENETRATOR_INITIALS_8", 69644)
            STAT_SET_INT("DG_PENETRATOR_INITIALS_9", 69644)
            STAT_SET_INT("DG_PENETRATOR_SCORE_0", 50)
            STAT_SET_INT("DG_PENETRATOR_SCORE_1", 50)
            STAT_SET_INT("DG_PENETRATOR_SCORE_2", 50)
            STAT_SET_INT("DG_PENETRATOR_SCORE_3", 50)
            STAT_SET_INT("DG_PENETRATOR_SCORE_4", 50)
            STAT_SET_INT("DG_PENETRATOR_SCORE_5", 50)
            STAT_SET_INT("DG_PENETRATOR_SCORE_6", 50)
            STAT_SET_INT("DG_PENETRATOR_SCORE_7", 50)
            STAT_SET_INT("DG_PENETRATOR_SCORE_8", 50)
            STAT_SET_INT("DG_PENETRATOR_SCORE_9", 50)
            STAT_SET_INT("GGSM_INITIALS_0", 69644)
            STAT_SET_INT("GGSM_INITIALS_1", 69644)
            STAT_SET_INT("GGSM_INITIALS_2", 69644)
            STAT_SET_INT("GGSM_INITIALS_3", 69644)
            STAT_SET_INT("GGSM_INITIALS_4", 69644)
            STAT_SET_INT("GGSM_INITIALS_5", 69644)
            STAT_SET_INT("GGSM_INITIALS_6", 69644)
            STAT_SET_INT("GGSM_INITIALS_7", 69644)
            STAT_SET_INT("GGSM_INITIALS_8", 69644)
            STAT_SET_INT("GGSM_INITIALS_9", 69644)
            STAT_SET_INT("GGSM_SCORE_0", 50)
            STAT_SET_INT("GGSM_SCORE_1", 50)
            STAT_SET_INT("GGSM_SCORE_2", 50)
            STAT_SET_INT("GGSM_SCORE_3", 50)
            STAT_SET_INT("GGSM_SCORE_4", 50)
            STAT_SET_INT("GGSM_SCORE_5", 50)
            STAT_SET_INT("GGSM_SCORE_6", 50)
            STAT_SET_INT("GGSM_SCORE_7", 50)
            STAT_SET_INT("GGSM_SCORE_8", 50)
            STAT_SET_INT("GGSM_SCORE_9", 50)
            STAT_SET_INT("TWR_INITIALS_0", 69644)
            STAT_SET_INT("TWR_INITIALS_1", 69644)
            STAT_SET_INT("TWR_INITIALS_2", 69644)
            STAT_SET_INT("TWR_INITIALS_3", 69644)
            STAT_SET_INT("TWR_INITIALS_4", 69644)
            STAT_SET_INT("TWR_INITIALS_5", 69644)
            STAT_SET_INT("TWR_INITIALS_6", 69644)
            STAT_SET_INT("TWR_INITIALS_7", 69644)
            STAT_SET_INT("TWR_INITIALS_8", 69644)
            STAT_SET_INT("TWR_INITIALS_9", 69644)
            STAT_SET_INT("TWR_SCORE_0", 50)
            STAT_SET_INT("TWR_SCORE_1", 50)
            STAT_SET_INT("TWR_SCORE_2", 50)
            STAT_SET_INT("TWR_SCORE_3", 50)
            STAT_SET_INT("TWR_SCORE_4", 50)
            STAT_SET_INT("TWR_SCORE_5", 50)
            STAT_SET_INT("TWR_SCORE_6", 50)
            STAT_SET_INT("TWR_SCORE_7", 50)
            STAT_SET_INT("TWR_SCORE_8", 50)
            STAT_SET_INT("TWR_SCORE_9", 50)
        -- INT
        end
    end
)

button(
    "Unlocks",
    "ArcadeClo",
    "NewAcc",
    function()
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(262145 + 27980, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 27981, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 27982, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 27983, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 27984, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 27985, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 27986, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 27987, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 27988, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 27989, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 27990, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 27991, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 27992, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 27993, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 27994, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 27995, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 27996, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 27997, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 27998, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 27999, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 28000, 1)
        end
    end
)

button(
    "Unlocks",
    "NightAw",
    "NewAcc",
    function()
        if NETWORK then
            STAT_SET_BOOL("AWD_CLUB_HOTSPOT", true)
            STAT_SET_BOOL("AWD_CLUB_CLUBBER", true)
            STAT_SET_BOOL("AWD_CLUB_COORD", true)
            -- BOOL
            STAT_SET_INT("AWD_DANCE_TO_SOLOMUN", 120)
            STAT_SET_INT("AWD_DANCE_TO_TALEOFUS", 120)
            STAT_SET_INT("AWD_DANCE_TO_DIXON", 120)
            STAT_SET_INT("AWD_DANCE_TO_BLKMAD", 120)
            STAT_SET_INT("AWD_CLUB_DRUNK", 200)
            STAT_SET_INT("NIGHTCLUB_VIP_APPEAR", 700)
            STAT_SET_INT("NIGHTCLUB_JOBS_DONE", 700)
            STAT_SET_INT("NIGHTCLUB_EARNINGS", 20721002)
            STAT_SET_INT("HUB_SALES_COMPLETED", 1001)
            STAT_SET_INT("HUB_EARNINGS", 320721002)
            STAT_SET_INT("DANCE_COMBO_DURATION_MINS", 3600000)
            STAT_SET_INT("NIGHTCLUB_PLAYER_APPEAR", 9506)
            STAT_SET_INT("LIFETIME_HUB_GOODS_SOLD", 784672)
            STAT_SET_INT("LIFETIME_HUB_GOODS_MADE", 507822)
            STAT_SET_INT("DANCEPERFECTOWNCLUB", 120)
            STAT_SET_INT("NUMUNIQUEPLYSINCLUB", 120)
            STAT_SET_INT("DANCETODIFFDJS", 4)
            STAT_SET_INT("NIGHTCLUB_HOTSPOT_TIME_MS", 3600000)
            STAT_SET_INT("NIGHTCLUB_CONT_TOTAL", 20)
            STAT_SET_INT("NIGHTCLUB_CONT_MISSION", 0xFFFFFFF)
            STAT_SET_INT("CLUB_CONTRABAND_MISSION", 1000)
            STAT_SET_INT("HUB_CONTRABAND_MISSION", 1000)
        -- INT
        end
    end
)

button(
    "Unlocks",
    "Cosm",
    "NewAcc",
    function()
        if NETWORK then
            STAT_SET_INT("LIFETIME_BUY_COMPLETE", 1000)
            STAT_SET_INT("LIFETIME_BUY_UNDERTAKEN", 1000)
            STAT_SET_INT("LIFETIME_SELL_COMPLETE", 1000)
            STAT_SET_INT("LIFETIME_SELL_UNDERTAKEN", 1000)
            STAT_SET_INT("LIFETIME_CONTRA_EARNINGS", 20000000)
            STAT_SET_INT("LIFETIME_BIKER_BUY_COMPLET", 1000)
            STAT_SET_INT("LIFETIME_BIKER_BUY_UNDERTA", 1000)
            STAT_SET_INT("LIFETIME_BIKER_SELL_COMPLET", 1000)
            STAT_SET_INT("LIFETIME_BIKER_SELL_UNDERTA", 1000)
            STAT_SET_INT("LIFETIME_BIKER_BUY_COMPLET1", 1000)
            STAT_SET_INT("LIFETIME_BIKER_BUY_UNDERTA1", 1000)
            STAT_SET_INT("LIFETIME_BIKER_SELL_COMPLET1", 1000)
            STAT_SET_INT("LIFETIME_BIKER_SELL_UNDERTA1", 1000)
            STAT_SET_INT("LIFETIME_BIKER_BUY_COMPLET2", 1000)
            STAT_SET_INT("LIFETIME_BIKER_BUY_UNDERTA2", 1000)
            STAT_SET_INT("LIFETIME_BIKER_SELL_COMPLET2", 1000)
            STAT_SET_INT("LIFETIME_BIKER_SELL_UNDERTA2", 1000)
            STAT_SET_INT("LIFETIME_BIKER_BUY_COMPLET3", 1000)
            STAT_SET_INT("LIFETIME_BIKER_BUY_UNDERTA3", 1000)
            STAT_SET_INT("LIFETIME_BIKER_SELL_COMPLET3", 1000)
            STAT_SET_INT("LIFETIME_BIKER_SELL_UNDERTA3", 1000)
            STAT_SET_INT("LIFETIME_BIKER_BUY_COMPLET4", 1000)
            STAT_SET_INT("LIFETIME_BIKER_BUY_UNDERTA4", 1000)
            STAT_SET_INT("LIFETIME_BIKER_SELL_COMPLET4", 1000)
            STAT_SET_INT("LIFETIME_BIKER_SELL_UNDERTA4", 1000)
            STAT_SET_INT("LIFETIME_BIKER_BUY_COMPLET5", 1000)
            STAT_SET_INT("LIFETIME_BIKER_BUY_UNDERTA5", 1000)
            STAT_SET_INT("LIFETIME_BIKER_SELL_COMPLET5", 1000)
            STAT_SET_INT("LIFETIME_BIKER_SELL_UNDERTA5", 1000)
            STAT_SET_INT("LIFETIME_BKR_SELL_EARNINGS0", 20000000)
            STAT_SET_INT("LIFETIME_BKR_SELL_EARNINGS1", 20000000)
            STAT_SET_INT("LIFETIME_BKR_SELL_EARNINGS2", 20000000)
            STAT_SET_INT("LIFETIME_BKR_SELL_EARNINGS3", 20000000)
            STAT_SET_INT("LIFETIME_BKR_SELL_EARNINGS4", 20000000)
            STAT_SET_INT("LIFETIME_BKR_SELL_EARNINGS5", 20000000)
        end
    end
)

button(
    "Unlocks",
    "XCont",
    "NewAcc",
    function()
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(262145 + 4723, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 4734, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 9185, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 9186, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 9187, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 9188, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 9189, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 9190, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 9191, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 9193, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 9194, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23176, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23177, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23178, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23179, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23180, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25498, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25499, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25500, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 8977, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 9241, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 9242, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 9243, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 12500, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23181, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23182, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23183, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23184, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23972, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 12501, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 12503, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 19051, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 22825, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 12606, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 12607, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 12608, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 12609, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 18910, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 18911, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 18912, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 18913, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23203, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23204, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23205, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23206, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25502, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25503, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25504, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25505, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 28354, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 28355, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 28356, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 28357, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30552, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 31398, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 31399, 1)
        end
    end
)

button(
    "Unlocks",
    "XLiv",
    "NewAcc",
    function()
        if NETWORK then
            STAT_SET_INT_MPPLY("MPPLY_XMASLIVERIES0", 0xFFFFFFF)
            STAT_SET_INT_MPPLY("MPPLY_XMASLIVERIES1", 0xFFFFFFF)
            STAT_SET_INT_MPPLY("MPPLY_XMASLIVERIES2", 0xFFFFFFF)
            STAT_SET_INT_MPPLY("MPPLY_XMASLIVERIES3", 0xFFFFFFF)
            STAT_SET_INT_MPPLY("MPPLY_XMASLIVERIES4", 0xFFFFFFF)
            STAT_SET_INT_MPPLY("MPPLY_XMASLIVERIES5", 0xFFFFFFF)
            STAT_SET_INT_MPPLY("MPPLY_XMASLIVERIES6", 0xFFFFFFF)
            STAT_SET_INT_MPPLY("MPPLY_XMASLIVERIES7", 0xFFFFFFF)
            STAT_SET_INT_MPPLY("MPPLY_XMASLIVERIES8", 0xFFFFFFF)
            STAT_SET_INT_MPPLY("MPPLY_XMASLIVERIES9", 0xFFFFFFF)
            STAT_SET_INT_MPPLY("MPPLY_XMASLIVERIES10", 0xFFFFFFF)
            STAT_SET_INT_MPPLY("MPPLY_XMASLIVERIES11", 0xFFFFFFF)
            STAT_SET_INT_MPPLY("MPPLY_XMASLIVERIES12", 0xFFFFFFF)
            STAT_SET_INT_MPPLY("MPPLY_XMASLIVERIES13", 0xFFFFFFF)
            STAT_SET_INT_MPPLY("MPPLY_XMASLIVERIES14", 0xFFFFFFF)
            STAT_SET_INT_MPPLY("MPPLY_XMASLIVERIES15", 0xFFFFFFF)
            STAT_SET_INT_MPPLY("MPPLY_XMASLIVERIES16", 0xFFFFFFF)
            STAT_SET_INT_MPPLY("MPPLY_XMASLIVERIES17", 0xFFFFFFF)
            STAT_SET_INT_MPPLY("MPPLY_XMASLIVERIES18", 0xFFFFFFF)
            STAT_SET_INT_MPPLY("MPPLY_XMASLIVERIES19", 0xFFFFFFF)
            STAT_SET_INT_MPPLY("MPPLY_XMASLIVERIES20", 0xFFFFFFF)
        end
    end
)

button(
    "Unlocks",
    "ValCont",
    "NewAcc",
    function()
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(262145 + 6856, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 11820, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 11821, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 11822, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 11823, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 11824, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 13186, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 13187, 1)
        end
    end
)

button(
    "Unlocks",
    "IndepCont",
    "NewAcc",
    function()
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(262145 + 8051, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 8060, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 8061, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 8064, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 8065, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 8066, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 8089, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 8090, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 8091, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 8092, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 8093, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 8094, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 8095, 1)
        end
    end
)

button(
    "Unlocks",
    "HalowCont",
    "NewAcc",
    function()
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(262145 + 11786, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 11826, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 11831, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 11832, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 11833, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 11835, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 11841, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 11842, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 11843, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 11849, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 12492, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 17288, 1)
        end
    end
)

button(
    "Unlocks",
    "HatShirtUn",
    "NewAcc",
    function()
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(262145 + 29883, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29884, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29885, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29886, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29887, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 12381, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 12382, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 12383, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 12384, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 12385, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 12386, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 12387, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 12388, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 12389, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 12390, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23973, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23978, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23980, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23981, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23983, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23985, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23986, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24505, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24506, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24507, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24508, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24509, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24510, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24511, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24512, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24513, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24514, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24515, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24516, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24517, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24518, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24519, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24520, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24521, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24522, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24523, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24524, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24465, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24466, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24467, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24468, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24469, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24470, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24471, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24472, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24473, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24680, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24681, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24682, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24683, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24684, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24685, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24686, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24687, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24688, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24689, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24690, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24691, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24692, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24693, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24694, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24695, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24696, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24697, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24698, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24699, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24700, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24701, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24702, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 24703, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20904, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20908, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20911, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20913, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20918, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20920, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20924, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20927, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20905, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20907, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20909, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20910, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20914, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20917, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20919, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20921, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20922, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20925, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20929, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20930, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20931, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20932, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20933, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20934, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20935, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20936, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20937, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20938, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20939, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20940, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20941, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25378, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 16591, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 16592, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 16593, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 16594, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 16595, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 16596, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 16597, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 14972, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 14973, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 14974, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 14975, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 14976, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 14977, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 14978, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 14980, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 14981, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 14983, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 14984, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 14985, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 14986, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23974, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23975, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23976, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23977, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23979, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23982, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23984, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23987, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23990, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23991, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23992, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23993, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23994, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23995, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23996, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23997, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23998, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23999, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 17332, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 17333, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 17334, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 17335, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 17336, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 17337, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 17338, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 17339, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 17340, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 17341, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 17342, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 17343, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 17344, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 17345, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 17346, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 17347, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 17348, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 17349, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 17350, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 17351, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 17352, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 17353, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 11745, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 11746, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 11747, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 11748, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 11749, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 11750, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 11751, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 11752, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 11753, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 11754, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 12391, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 12392, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 12393, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 12394, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 12395, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 12396, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 12397, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 12398, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 12399, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 12400, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 12401, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 12402, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 12403, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 14979, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23988, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 23989, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20903, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20906, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20912, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20915, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20916, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20923, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20926, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 20928, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25574, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25575, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25576, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25577, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25578, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25579, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25580, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25581, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25582, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 25583, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 26691, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 26692, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 26693, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 26694, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 26695, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 26696, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 26697, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 31465, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 31466, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 31467, 1)
        end
    end
)

button(
    "Unlocks",
    "LinTee",
    "NewAcc",
    function()
        if NETWORK then
            STAT_SET_INT("DCTL_WINS", 500)
            STAT_SET_INT("DCTL_PLAY_COUNT", 750)
        end
    end
)

button(
    "Unlocks",
    "TradePri",
    "NewAcc",
    function()
        if NETWORK then
            STAT_SET_INT("GANGOPS_FLOW_BITSET_MISS0", 0xFFFFFFF)
            STAT_SET_INT("LFETIME_HANGAR_BUY_UNDETAK", 42)
            STAT_SET_INT("LFETIME_HANGAR_BUY_COMPLET", 42)
            STAT_SET_INT("AT_FLOW_IMPEXP_NUM", 32)
            STAT_SET_INT("AT_FLOW_VEHICLE_BS", 0xFFFFFFF)
            STAT_SET_INT("WVM_FLOW_VEHICLE_BS", 0xFFFFFFF)
            STAT_SET_INT("H3_BOARD_DIALOGUE0", 0xFFFFFFF)
            STAT_SET_INT("H3_BOARD_DIALOGUE1", 0xFFFFFFF)
            STAT_SET_INT("H3_BOARD_DIALOGUE2", 0xFFFFFFF)
            STAT_SET_INT("H3_VEHICLESUSED", 0xFFFFFFF)
            STAT_SET_INT("WAM_FLOW_VEHICLE_BS", 0xFFFFFFF)
        end
    end
)

button(
    "Unlocks",
    "Sha",
    "NewAcc",
    function()
        if NETWORK then
            STAT_SET_INT("CRDEADLINE", 0xFFFFFFF)
        end
    end
)

button(
    "Unlocks",
    "SpecWeap",
    "NewAcc",
    function()
        if NETWORK then
            STAT_SET_BOOL_MPPLY("MPPLY_MELEECHLENGECOMPLETED", true)
            STAT_SET_BOOL_MPPLY("MPPLY_HEADSHOTCHLENGECOMPLETED", true)
            STAT_SET_BOOL_MPPLY("MPPLY_NAVYREVOLVERCOMPLETED", true)
            SCRIPT.SET_GLOBAL_I(102911, 90)
        end
    end
)

button(
    "Unlocks",
    "CsStore",
    "NewAcc",
    function()
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(262145 + 27194, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 27195, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 27196, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 27197, 1)
        end
    end
)

button(
    "Unlocks",
    "UniAw",
    "NewAcc",
    function()
        if NETWORK then
            STAT_SET_INT("LAP_DANCED_BOUGHT", 0)
            STAT_SET_INT("LAP_DANCED_BOUGHT", 5)
            STAT_SET_INT("LAP_DANCED_BOUGHT", 10)
            STAT_SET_INT("LAP_DANCED_BOUGHT", 15)
            STAT_SET_INT("LAP_DANCED_BOUGHT", 25)
            STAT_SET_INT("PROSTITUTES_FREQUENTED", 1000)
        end
    end
)

button(
    "Unlocks",
    "Tat",
    "TatBio",
    function()
        if NETWORK then
            STAT_SET_INT("TATTOO_FM_CURRENT_32", 0xFFFFFFF)
        end
    end
)

button(
    "Unlocks",
    "ReturnBo",
    "NewAcc",
    function()
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(151761, 2)
            SCRIPT.SET_GLOBAL_I(102912, 1)
        end
    end
)

button(
    "Unlocks",
    "BunkRes",
    "BunkResBio",
    function()
        if NETWORK then
            local index = STATS.STAT_GET_INT(g_util.joaat("MPPLY_LAST_MP_CHAR"))
            STATS.SET_PACKED_STAT_BOOL(15381, true, index)
            STATS.SET_PACKED_STAT_BOOL(15382, true, index)
            STATS.SET_PACKED_STAT_BOOL(15428, true, index)
            STATS.SET_PACKED_STAT_BOOL(15429, true, index)
            STATS.SET_PACKED_STAT_BOOL(15430, true, index)
            STATS.SET_PACKED_STAT_BOOL(15431, true, index)
            STATS.SET_PACKED_STAT_BOOL(15491, true, index)
            STATS.SET_PACKED_STAT_BOOL(15432, true, index)
            STATS.SET_PACKED_STAT_BOOL(15433, true, index)
            STATS.SET_PACKED_STAT_BOOL(15434, true, index)
            STATS.SET_PACKED_STAT_BOOL(15435, true, index)
            STATS.SET_PACKED_STAT_BOOL(15436, true, index)
            STATS.SET_PACKED_STAT_BOOL(15437, true, index)
            STATS.SET_PACKED_STAT_BOOL(15438, true, index)
            STATS.SET_PACKED_STAT_BOOL(15439, true, index)
            STATS.SET_PACKED_STAT_BOOL(15447, true, index)
            STATS.SET_PACKED_STAT_BOOL(15448, true, index)
            STATS.SET_PACKED_STAT_BOOL(15449, true, index)
            STATS.SET_PACKED_STAT_BOOL(15450, true, index)
            STATS.SET_PACKED_STAT_BOOL(15451, true, index)
            STATS.SET_PACKED_STAT_BOOL(15452, true, index)
            STATS.SET_PACKED_STAT_BOOL(15453, true, index)
            STATS.SET_PACKED_STAT_BOOL(15454, true, index)
            STATS.SET_PACKED_STAT_BOOL(15455, true, index)
            STATS.SET_PACKED_STAT_BOOL(15456, true, index)
            STATS.SET_PACKED_STAT_BOOL(15457, true, index)
            STATS.SET_PACKED_STAT_BOOL(15458, true, index)
            STATS.SET_PACKED_STAT_BOOL(15459, true, index)
            STATS.SET_PACKED_STAT_BOOL(15460, true, index)
            STATS.SET_PACKED_STAT_BOOL(15461, true, index)
            STATS.SET_PACKED_STAT_BOOL(15462, true, index)
            STATS.SET_PACKED_STAT_BOOL(15463, true, index)
            STATS.SET_PACKED_STAT_BOOL(15464, true, index)
            STATS.SET_PACKED_STAT_BOOL(15465, true, index)
            STATS.SET_PACKED_STAT_BOOL(15466, true, index)
            STATS.SET_PACKED_STAT_BOOL(15467, true, index)
            STATS.SET_PACKED_STAT_BOOL(15468, true, index)
            STATS.SET_PACKED_STAT_BOOL(15469, true, index)
            STATS.SET_PACKED_STAT_BOOL(15470, true, index)
            STATS.SET_PACKED_STAT_BOOL(15471, true, index)
            STATS.SET_PACKED_STAT_BOOL(15472, true, index)
            STATS.SET_PACKED_STAT_BOOL(15473, true, index)
            STATS.SET_PACKED_STAT_BOOL(15474, true, index)
            STATS.SET_PACKED_STAT_BOOL(15492, true, index)
            STATS.SET_PACKED_STAT_BOOL(15493, true, index)
            STATS.SET_PACKED_STAT_BOOL(15494, true, index)
            STATS.SET_PACKED_STAT_BOOL(15495, true, index)
            STATS.SET_PACKED_STAT_BOOL(15496, true, index)
            STATS.SET_PACKED_STAT_BOOL(15497, true, index)
            STATS.SET_PACKED_STAT_BOOL(15498, true, index)
            STATS.SET_PACKED_STAT_BOOL(15499, true, index)
        end
    end
)

button(
    "Unlocks",
    "AnimalCont",
    "NewAcc",
    function()
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(262145 + 31453, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 31454, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 31455, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 31456, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 31457, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 31458, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 31459, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 31460, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 31461, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 31462, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 31463, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 31464, 1)
        end
    end
)

button(
    "Unlocks",
    "ConraDJ",
    "NewAcc",
    function()
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(262145 + 31465, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 31466, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 31467, 1)
        end
    end
)

button(
    "Unlocks",
    "CayoUn",
    "NewAcc",
    function()
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(262145 + 29888, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29889, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29890, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29891, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29892, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29893, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29894, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29895, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29896, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29897, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29898, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29899, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29900, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29901, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29902, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29903, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29904, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29905, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29906, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29907, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29908, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29909, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29910, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29911, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29912, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29913, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29914, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29915, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29916, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29917, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29918, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29919, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29920, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29921, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29922, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29923, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29924, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29925, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29926, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29927, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29859, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29860, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29861, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29862, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29863, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29864, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29865, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29866, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29867, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29868, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29869, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29870, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29871, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29872, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29873, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29874, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29875, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29876, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29877, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29878, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29879, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29880, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29881, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29882, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29932, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29933, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29934, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29935, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29936, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29937, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29938, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29939, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29940, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29941, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29942, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29943, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29944, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29945, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29946, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29947, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29948, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29949, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29950, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 29951, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30516, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30517, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30518, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30519, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30520, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30521, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30522, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30523, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30524, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30525, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30526, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30527, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30528, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30529, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30530, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30531, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30532, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30533, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30534, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30535, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30536, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30537, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30538, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30539, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30540, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30541, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30542, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30543, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30544, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30545, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30546, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30547, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30548, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30549, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30550, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30551, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30561, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30562, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30563, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30564, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30565, 1)
            SCRIPT.SET_GLOBAL_I(262145 + 30566, 1)
        end
    end
)

button(
    "Unlocks",
    "UnYacht",
    "NewAcc",
    function()
        if NETWORK then
            STAT_SET_INT("YACHT_MISSION_PROG", 0)
            STAT_SET_INT("YACHT_MISSION_FLOW", 21845)
            STAT_SET_INT("CASINO_DECORATION_GIFT_1", 0xFFFFFFF)
        end
    end
)

button(
    "Unlocks",
    "UnCon",
    "NewAcc",
    function()
        if NETWORK then
            STAT_SET_INT("FM_ACT_PHN", 0xFFFFFFF)
            STAT_SET_INT("FM_ACT_PH2", 0xFFFFFFF)
            STAT_SET_INT("FM_ACT_PH3", 0xFFFFFFF)
            STAT_SET_INT("FM_ACT_PH4", 0xFFFFFFF)
            STAT_SET_INT("FM_ACT_PH5", 0xFFFFFFF)
            STAT_SET_INT("FM_VEH_TX1", 0xFFFFFFF)
            STAT_SET_INT("FM_ACT_PH6", 0xFFFFFFF)
            STAT_SET_INT("FM_ACT_PH7", 0xFFFFFFF)
            STAT_SET_INT("FM_ACT_PH8", 0xFFFFFFF)
            STAT_SET_INT("FM_ACT_PH9", 0xFFFFFFF)
            STAT_SET_INT("FM_CUT_DONE", 0xFFFFFFF)
            STAT_SET_INT("FM_CUT_DONE_2", 0xFFFFFFF)
        end
    end
)

button(
    "Unlocks",
    "UnLar",
    "NewAcc",
    function()
        if NETWORK then
            STAT_SET_BOOL("LOW_FLOW_CS_DRV_SEEN", true)
            STAT_SET_BOOL("LOW_FLOW_CS_TRA_SEEN", true)
            STAT_SET_BOOL("LOW_FLOW_CS_FUN_SEEN", true)
            STAT_SET_BOOL("LOW_FLOW_CS_PHO_SEEN", true)
            STAT_SET_BOOL("LOW_FLOW_CS_FIN_SEEN", true)
            STAT_SET_BOOL("LOW_BEN_INTRO_CS_SEEN", true)
            -- BOOL
            STAT_SET_INT("LOWRIDER_FLOW_COMPLETE", 3)
            STAT_SET_INT("LOW_FLOW_CURRENT_PROG", 9)
            STAT_SET_INT("LOW_FLOW_CURRENT_CALL", 9)
        -- INT
        end
    end
)

button(
    "Unlocks",
    "DailObj",
    function()
        if NETWORK then
            STAT_SET_BOOL("AWD_DAILYOBJWEEKBONUS", true)
            STAT_SET_BOOL("AWD_DAILYOBJMONTHBONUS", true)
            -- BOOL
            STAT_SET_INT("AWD_DAILYOBJCOMPLETED", 0)
            STAT_SET_INT("AWD_DAILYOBJCOMPLETED", 10)
            STAT_SET_INT("AWD_DAILYOBJCOMPLETED", 25)
            STAT_SET_INT("AWD_DAILYOBJCOMPLETED", 50)
            STAT_SET_INT("AWD_DAILYOBJCOMPLETED", 100)
            STAT_SET_INT("CONSECUTIVEWEEKCOMPLETED", 0)
            STAT_SET_INT("CONSECUTIVEWEEKCOMPLETED", 7)
            STAT_SET_INT("CONSECUTIVEWEEKCOMPLETED", 28)
        -- INT
        end
    end
)

-- [[ Custom Stats ]] --

submenu("RemainingOptions", "CustStats")

-- [[ General ]] --

separator("CustStats", "General")

button(
    "CustStats",
    "RandStats",
    "RandStatsBio",
    function()
        if NETWORK then
            -- PLAYTIME
            STAT_SET_INT_MPPLY("MPPLY_TOTAL_TIME_SPENT_DEATHMAT", math.random(150000000, 200000000))
            STAT_SET_INT_MPPLY("MPPLY_TOTAL_TIME_SPENT_FREEMODE", math.random(150000000, 200000000))
            STAT_SET_INT_MPPLY("MPPLY_TOTAL_TIME_MISSION_CREATO", math.random(150000000, 200000000))
            STAT_SET_INT_MPPLY("MPPLY_TOTAL_TIME_SPENT_RACES", math.random(150000000, 200000000))
            STAT_SET_INT_MPPLY("MPPLY_TOTAL_TIME_IN_LOBBY", math.random(150000000, 200000000))
            STAT_SET_INT_MPPLY("MPPLY_TOTAL_TIME_LOAD_SCREEN", math.random(150000000, 200000000))
            STAT_SET_INT_MPPLY("MPPLY_TOTAL_TIME_SPENT_ON_MISS", math.random(150000000, 200000000))
            STAT_SET_INT("LONGEST_PLAYING_TIME", math.random(15000000, 20000000))
            --[[ STAT_SET_INT("TOTAL_PLAYING_TIME", 0) 
                STAT_SET_ICR_MPPLY("MP_PLAYING_TIME", 365 * 8 * 86400000) --]]
            STAT_SET_INT("TOTAL_PLAYING_TIME", math.random(15000000, 20000000))
            -- OTHER STATS
            STAT_SET_INT_MPPLY("MPPLY_TOTAL_RACES_WON", math.random(200, 400))
            STAT_SET_INT_MPPLY("MPPLY_TOTAL_RACES_LOST", math.random(20, 40))
            STAT_SET_INT_MPPLY("MPPLY_TENNIS_MATCHES_WON", math.random(200, 400))
            STAT_SET_INT_MPPLY("MPPLY_TENNIS_MATCHES_LOST", math.random(20, 40))
        end
    end
)

-- [[ Playtime Editor ]] --

separator("CustStats", "PlayTEdit")

input(
    "CustStats",
    "TotPlayTime",
    0,
    0,
    2147483647,
    function(plyt)
        if NETWORK then
            STAT_SET_INT("TOTAL_PLAYING_TIME", plyt)
        end
    end
)

input(
    "CustStats",
    "LgPlayTime",
    0,
    0,
    2147483647,
    function(plyl)
        if NETWORK then
            STAT_SET_INT("LONGEST_PLAYING_TIME", plyl)
        end
    end
)

-- [[ Job Editor ]] --

separator("CustStats", "JobEdit")

input(
    "CustStats",
    "TotRacesWon",
    0,
    0,
    2147483647,
    function(racw)
        if NETWORK then
            STAT_SET_INT_MPPLY("MPPLY_TOTAL_RACES_WON", racw)
        end
    end
)

input(
    "CustStats",
    "TotRacesLost",
    0,
    0,
    2147483647,
    function(racl)
        if NETWORK then
            STAT_SET_INT_MPPLY("MPPLY_TOTAL_RACES_LOST", racl)
        end
    end
)

input(
    "CustStats",
    "TenMatchWon",
    0,
    0,
    2147483647,
    function(tmw)
        if NETWORK then
            STAT_SET_INT_MPPLY("MPPLY_TENNIS_MATCHES_WON", tmw)
        end
    end
)

-- [[ Account ]] --

--[[ separator("CustStats", "Account")

function STAT_SET_DATE(statHash, value, numFields, save)
        g_native.start()
        g_native.push_int(statHash)
        g_native.push_float(value)
        g_native.push_float(numFields)
        g_native.push_int(save)
        return g_native.call_int(0x2C29BFB64F4FCBE4)
end

input("CustStats", "Account Creation Date", 0, 0, 2147483647, function(crda)
        if NETWORK then
                local char = STATS.STAT_GET_BOOL(g_util.joaat("MPPLY_LAST_MP_CHAR"))
                STAT_SET_DATE(g_util.joaat("MP" .. char .. "_" .. "CHAR_DATE_CREATED"), crda, true)
        end
end) --]]
-- [[ Business Manager ]] --

submenu("RemainingOptions", "BuMang")

local show_man = false

function refresh_data()
    arcade_safe = STAT_GET_INT("ARCADE_SAFE_CASH_VALUE")
    club_popularity = STAT_GET_INT("CLUB_POPULARITY")
    club_safe = STAT_GET_INT("CLUB_SAFE_CASH_VALUE")

    stock_0 = STAT_GET_INT("MATTOTALFORFACTORY0")
    stock_1 = STAT_GET_INT("MATTOTALFORFACTORY1")
    stock_2 = STAT_GET_INT("MATTOTALFORFACTORY2")
    stock_3 = STAT_GET_INT("MATTOTALFORFACTORY3")
    stock_4 = STAT_GET_INT("MATTOTALFORFACTORY4")
    stock_5 = STAT_GET_INT("MATTOTALFORFACTORY5")

    if stock_0 > 100 then
        stock_0 = 100
    end
    if stock_1 > 100 then
        stock_1 = 100
    end
    if stock_2 > 100 then
        stock_2 = 100
    end
    if stock_3 > 100 then
        stock_3 = 100
    end
    if stock_4 > 100 then
        stock_4 = 100
    end
    if stock_5 > 100 then
        stock_5 = 100
    end

    pro_0 = STAT_GET_INT("PRODTOTALFORFACTORY0")
    pro_1 = STAT_GET_INT("PRODTOTALFORFACTORY1")
    pro_2 = STAT_GET_INT("PRODTOTALFORFACTORY2")
    pro_3 = STAT_GET_INT("PRODTOTALFORFACTORY3")
    pro_4 = STAT_GET_INT("PRODTOTALFORFACTORY4")
    pro_5 = STAT_GET_INT("PRODTOTALFORFACTORY5")

    if pro_0 > 10 then
        pro_0 = 10
    end
    if pro_1 > 20 then
        pro_1 = 20
    end
    if pro_2 > 40 then
        pro_2 = 40
    end
    if pro_3 > 80 then
        pro_3 = 80
    end
    if pro_4 > 60 then
        pro_4 = 60
    end
    if pro_5 > 100 then
        pro_5 = 100
    end

    if show_man then
        if stock_5 == 10 then
            STAT_SET_INT("PAYRESUPPLYTIMER5", 1)
        end
        if stock_0 == 10 then
            STAT_SET_INT("PAYRESUPPLYTIMER0", 1)
        end
        if stock_1 == 10 then
            STAT_SET_INT("PAYRESUPPLYTIMER1", 1)
        end
        if stock_2 == 10 then
            STAT_SET_INT("PAYRESUPPLYTIMER2", 1)
        end
        if stock_3 == 10 then
            STAT_SET_INT("PAYRESUPPLYTIMER3", 1)
        end
        if stock_4 == 10 then
            STAT_SET_INT("PAYRESUPPLYTIMER4", 1)
        end
    end

    night_0 = STAT_GET_INT("HUB_PROD_TOTAL_0")
    night_1 = STAT_GET_INT("HUB_PROD_TOTAL_1")
    night_2 = STAT_GET_INT("HUB_PROD_TOTAL_2")
    night_3 = STAT_GET_INT("HUB_PROD_TOTAL_3")
    night_4 = STAT_GET_INT("HUB_PROD_TOTAL_4")
    night_5 = STAT_GET_INT("HUB_PROD_TOTAL_5")
    night_6 = STAT_GET_INT("HUB_PROD_TOTAL_6")
    night_all = night_0 + night_1 + night_2 + night_3 + night_4 + night_5 + night_6

    cocaine_trg = STAT_GET_INT("FACTORYSETUP0")
    bunker_trg = STAT_GET_INT("FACTORYSETUP5")
    meth_trg = STAT_GET_INT("FACTORYSETUP1")
    counterfit_trg = STAT_GET_INT("FACTORYSETUP2")
    weed_trg = STAT_GET_INT("FACTORYSETUP3")
    document_trg = STAT_GET_INT("FACTORYSETUP4")

    upg_0_0 = check(STAT_GET_INT("FACTORYUPGRADES0"))
    upg_0_1 = check(STAT_GET_INT("FACTORYUPGRADES0_1"))
    upg_0_2 = check(STAT_GET_INT("FACTORYUPGRADES0_2"))

    upg_1_0 = check(STAT_GET_INT("FACTORYUPGRADES1"))
    upg_1_1 = check(STAT_GET_INT("FACTORYUPGRADES1_1"))
    upg_1_2 = check(STAT_GET_INT("FACTORYUPGRADES1_2"))

    upg_2_0 = check(STAT_GET_INT("FACTORYUPGRADES2"))
    upg_2_1 = check(STAT_GET_INT("FACTORYUPGRADES2_1"))
    upg_2_2 = check(STAT_GET_INT("FACTORYUPGRADES2_2"))

    upg_3_0 = check(STAT_GET_INT("FACTORYUPGRADES3"))
    upg_3_1 = check(STAT_GET_INT("FACTORYUPGRADES3_1"))
    upg_3_2 = check(STAT_GET_INT("FACTORYUPGRADES3_2"))

    upg_4_0 = check(STAT_GET_INT("FACTORYUPGRADES4"))
    upg_4_1 = check(STAT_GET_INT("FACTORYUPGRADES4_1"))
    upg_4_2 = check(STAT_GET_INT("FACTORYUPGRADES4_2"))

    bunker_decor = check(STAT_GET_INT("BUNKER_DECOR"))
    bunker_staff = check(STAT_GET_INT("BUNKER_STAFF"))
    bunker_equipment = check(STAT_GET_INT("BUNKER_EQUIPMENT"))
    bunker_sequrity = check(STAT_GET_INT("BUNKER_SECURITY"))
    bunker_savebed = check(STAT_GET_INT("BUNKER_SAVEBED"))
    bunker_gunlocker = check(STAT_GET_INT("BUNKER_GUNLOCKER"))
    bunker_firing_range = check(STAT_GET_INT("BUNKER_FIRING_RANGE"))
    bunker_transportation = check(STAT_GET_INT("BUNKER_TRANSPORTATION"))

    arc_0 = check(STAT_GET_INT("ARCADE_MAC_0"))
    arc_1 = check(STAT_GET_INT("ARCADE_MAC_1"))
    arc_2 = check(STAT_GET_INT("ARCADE_MAC_2"))
    arc_3 = check(STAT_GET_INT("ARCADE_MAC_3"))
    arc_4 = check(STAT_GET_INT("ARCADE_MAC_4"))
    arc_5 = check(STAT_GET_INT("ARCADE_MAC_5"))
    arc_6 = check(STAT_GET_INT("ARCADE_MAC_6"))
    arc_7 = check(STAT_GET_INT("ARCADE_MAC_7"))
    arc_8 = check(STAT_GET_INT("ARCADE_MAC_8"))
    arc_9 = check(STAT_GET_INT("ARCADE_MAC_9"))
    arc_10 = check(STAT_GET_INT("ARCADE_MAC_10"))
    arc_11 = check(STAT_GET_INT("ARCADE_MAC_11"))
    arc_12 = check(STAT_GET_INT("ARCADE_MAC_12"))
    arc_business_hub = check(STAT_GET_INT("ARCADE_BUS_HUB"))
    arc_drone_stat = check(STAT_GET_INT("ARCADE_DRON_ST"))

    arc_floor = check(STAT_GET_INT("ARCADE_FLOOR"))
    arc_ceiling = check(STAT_GET_INT("ARCADE_CEILING"))
    arc_wall = check(STAT_GET_INT("ARCADE_WALL"))
    arc_personal_quarters = check(STAT_GET_INT("ARCADE_PERSONAL_QUARTERS"))
    arc_garage = check(STAT_GET_INT("ARCADE_GARAGE"))
    arc_neon_lights = check(STAT_GET_INT("ARCADE_NEON_LIGHTS"))
    arc_screen = check(STAT_GET_INT("ARCADE_SCREENS"))

    nc_style = check(STAT_GET_INT("NIGHTCLUB_STYLE"))
    nc_lighting = check(STAT_GET_INT("NIGHTCLUB_LIGHTING"))
    nc_mod_4 = check(STAT_GET_INT("NIGHTCLUB_MOD_4"))
    nc_mod_5 = check(STAT_GET_INT("NIGHTCLUB_MOD_5"))
    nc_mod_6 = check(STAT_GET_INT("NIGHTCLUB_MOD_6"))
    nc_mod_7 = check(STAT_GET_INT("NIGHTCLUB_MOD_7"))
end

local show_ov = false
local arcade_safe = 0
local club_popularity = 0
local club_safe = 0
local pro_0 = 0
local pro_1 = 0
local pro_2 = 0
local pro_3 = 0
local pro_4 = 0
local pro_5 = 0
local stock_0 = 0
local stock_1 = 0
local stock_2 = 0
local stock_3 = 0
local stock_4 = 0
local stock_5 = 0

function ov()
    if show_ov then
        g_imgui.set_next_window_size(vec2(400, 600))
        if g_imgui.begin_window(trsl("Businesses"), 0) then
            g_imgui.separator()
            g_imgui.add_text(trsl("Safes"))
            g_imgui.separator()

            if arcade_safe == 100 then
                g_imgui.add_text(trsl("ArcSaf") .. arcade_safe .. trsl("100fu"))
            else
                g_imgui.add_text(trsl("ArcSaf") .. arcade_safe .. trsl("100k"))
            end
            if club_safe_value == 210 then
                g_imgui.add_text(trsl("ClubSaf") .. club_safe .. trsl("210fu"))
            else
                g_imgui.add_text(trsl("ClubSaf") .. club_safe .. trsl("210k"))
            end

            g_imgui.separator()
            g_imgui.add_text(trsl("Bunker"))
            g_imgui.separator()

            if stock_5 <= 30 then
                g_imgui.add_text(trsl("BunkerSt") .. stock_5 .. trsl("100StNo"))
                refill_5 = true
            else
                g_imgui.add_text(trsl("BunkerSt") .. stock_5 .. trsl("100"))
                refill_5 = false
            end
            if pro_5 == 30 then
                g_imgui.add_text(trsl("BunkerPro") .. pro_5 .. trsl("30f"))
                mc_5_full = true
            else
                g_imgui.add_text(trsl("BunkerPro") .. pro_5 .. trsl("30"))
                mc_5_full = false
            end

            g_imgui.separator()
            g_imgui.add_text(trsl("MCStock"))
            g_imgui.separator()

            if stock_0 <= 30 then
                g_imgui.add_text(trsl("CocSt") .. stock_0 .. trsl("100StNo"))
                refill_0 = true
            else
                g_imgui.add_text(trsl("CocSt") .. stock_0 .. trsl("100"))
                refill_0 = false
            end
            if stock_1 <= 30 then
                g_imgui.add_text(trsl("MethSt") .. stock_1 .. trsl("100StNo"))
                refill_1 = true
            else
                g_imgui.add_text(trsl("MethSt") .. stock_1 .. trsl("100"))
                refill_1 = false
            end
            if stock_2 <= 30 then
                g_imgui.add_text(trsl("CounterfitSt") .. stock_2 .. trsl("100StNo"))
                refill_2 = true
            else
                g_imgui.add_text(trsl("CounterfitSt") .. stock_2 .. trsl("100"))
                refill_2 = false
            end
            if stock_3 <= 30 then
                g_imgui.add_text(trsl("WeedSt") .. stock_3 .. trsl("100StNo"))
                refill_3 = true
            else
                g_imgui.add_text(trsl("WeedSt") .. stock_3 .. trsl("100"))
                refill_3 = false
            end
            if stock_4 <= 30 then
                g_imgui.add_text(trsl("DocumentsSt") .. stock_4 .. trsl("100StNo"))
                refill_4 = true
            else
                g_imgui.add_text(trsl("DocumentsSt") .. stock_4 .. trsl("100"))
                refill_4 = false
            end

            g_imgui.separator()
            g_imgui.add_text(trsl("MCProduct"))
            g_imgui.separator()

            if pro_0 == 10 then
                g_imgui.add_text(trsl("CocainePro") .. pro_0 .. trsl("10f"))
                mc_full_0 = true
            else
                g_imgui.add_text(trsl("CocainePro") .. pro_0 .. trsl("10"))
                mc_full_0 = false
            end
            if pro_1 == 20 then
                g_imgui.add_text(trsl("MethPro") .. pro_1 .. trsl("20f"))
                mc_full_1 = true
            else
                g_imgui.add_text(trsl("MethPro") .. pro_1 .. trsl("20"))
                mc_full_1 = false
            end
            if pro_2 == 40 then
                g_imgui.add_text(trsl("CounterfitPro") .. pro_2 .. trsl("40f"))
                mc_full_2 = true
            else
                g_imgui.add_text(trsl("CounterfitPro") .. pro_2 .. trsl("40"))
                mc_full_2 = false
            end
            if pro_3 == 80 then
                g_imgui.add_text(trsl("WeedPro") .. pro_3 .. trsl("80f"))
                mc_full_3 = true
            else
                g_imgui.add_text(trsl("WeedPro") .. pro_3 .. trsl("80"))
                mc_full_3 = false
            end
            if pro_4 == 60 then
                g_imgui.add_text(trsl("DocumentPro") .. pro_4 .. trsl("60f"))
                mc_full_4 = true
            else
                g_imgui.add_text(trsl("DocumentPro") .. pro_4 .. trsl("60"))
                mc_full_4 = false
            end

            g_imgui.separator()
            g_imgui.add_text(trsl("Nightclub"))
            g_imgui.separator()

            if club_popularity == 1000 then
                g_imgui.add_text(trsl("ClubPop") .. club_popularity .. trsl("1000f"))
            else
                g_imgui.add_text(trsl("ClubPop") .. club_popularity .. trsl("1000"))
            end
            if club_popularity <= 1000 then
                STAT_SET_INT("CLUB_POPULARITY", 1000)
            end
            if night_0 == 50 then
                g_imgui.add_text(trsl("CargoShip") .. night_0 .. trsl("50f"))
                night_full_0 = true
            else
                g_imgui.add_text(trsl("CargoShip") .. night_0 .. trsl("50"))
                night_full_0 = false
            end
            if night_1 == 100 then
                g_imgui.add_text(trsl("SportingGoods") .. night_1 .. trsl("100f"))
                night_full_1 = true
            else
                g_imgui.add_text(trsl("SportingGoods") .. night_1 .. trsl("100"))
                night_full_1 = false
            end
            if night_2 == 10 then
                g_imgui.add_text(trsl("SAmiImp") .. night_2 .. trsl("10f"))
                night_full_2 = true
            else
                g_imgui.add_text(trsl("SAmiImp") .. night_2 .. trsl("10"))
                night_full_2 = false
            end
            if night_3 == 20 then
                g_imgui.add_text(trsl("PharmaRes") .. night_3 .. trsl("20f"))
                night_full_3 = true
            else
                g_imgui.add_text(trsl("PharmaRes") .. night_3 .. trsl("20"))
                night_full_3 = false
            end
            if night_4 == 80 then
                g_imgui.add_text(trsl("OrganicPro") .. night_4 .. trsl("80f"))
                night_full_4 = true
            else
                g_imgui.add_text(trsl("OrganicPro") .. night_4 .. trsl("80"))
                night_full_4 = false
            end
            if night_5 == 60 then
                g_imgui.add_text(trsl("PrintCopy") .. night_5 .. trsl("60f"))
                night_full_5 = true
            else
                g_imgui.add_text(trsl("PrintCopy") .. night_5 .. trsl("60"))
                night_full_5 = false
            end
            if night_6 == 40 then
                g_imgui.add_text(trsl("CashCreation") .. night_6 .. trsl("40f"))
                night_full_6 = true
            else
                g_imgui.add_text(trsl("CashCreation") .. night_6 .. trsl("40"))
                night_full_6 = false
            end
            if night_7 == 360 then
                g_imgui.add_text(trsl("TotPro") .. night_all .. trsl("360f"))
                night_full_all = true
            else
                g_imgui.add_text(trsl("TotPro") .. night_all .. trsl("360"))
                night_full_all = false
            end

            g_imgui.separator()
            g_imgui.add_text(trsl("QuickOverseer"))
            g_imgui.separator()

            if prod_5 == 100 then
                g_imgui.add_text(trsl("BuFl"))
            end
            if stock_5 <= 30 then
                g_imgui.add_text(trsl("BunkResup"))
            end
            if club_safe == 210 then
                g_imgui.add_text(trsl("NightSafFl"))
            end
            if arcade_safe == 100 then
                g_imgui.add_text(trsl("ArcFl"))
            end

            prod_night = 0
            if hub_full_0 then
                prod_night = prod_night + 1
            end
            if hub_full_1 then
                prod_night = prod_night + 1
            end
            if hub_full_2 then
                prod_night = prod_night + 1
            end
            if hub_full_3 then
                prod_night = prod_night + 1
            end
            if hub_full_4 then
                prod_night = prod_night + 1
            end
            if hub_full_5 then
                prod_night = prod_night + 1
            end
            if hub_full_6 then
                prod_night = prod_night + 1
            end
            if prod_night >= 1 then
                g_imgui.add_text(prod_night .. trsl("7NightGoods"))
            end

            stock_mc = 0
            if refill_0 then
                stock_mc = stock_mc + 1
            end
            if refill_1 then
                stock_mc = stock_mc + 1
            end
            if refill_2 then
                stock_mc = stock_mc + 1
            end
            if refill_3 then
                stock_mc = stock_mc + 1
            end
            if refill_4 then
                stock_mc = stock_mc + 1
            end
            if stock_mc >= 1 then
                g_imgui.add_text(stock_mc .. trsl("5MCResup"))
            end

            pro_mc = 0
            if mc_full_0 then
                pro_mc = pro_mc + 1
            end
            if mc_full_1 then
                pro_mc = pro_mc + 1
            end
            if mc_full_2 then
                pro_mc = pro_mc + 1
            end
            if mc_full_3 then
                pro_mc = pro_mc + 1
            end
            if mc_full_4 then
                pro_mc = pro_mc + 1
            end
            if pro_mc >= 1 then
                g_imgui.add_text(pro_mc .. trsl("5MCFl"))
            end

            g_imgui.end_window()
        end
    end
end

g_hooking.register_D3D_hook(ov)

local show_upg = false

function ui_upg()
    if show_upg then
        g_imgui.set_next_window_size(vec2(400, 600))
        if g_imgui.begin_window(trsl("BusinessUp"), 0) then
            g_imgui.separator()
            g_imgui.add_text(trsl("Productions"))
            g_imgui.separator()

            g_imgui.add_text(trsl("CocaineTrig") .. check(cocaine_trg))
            g_imgui.add_text(trsl("BunkerTrig") .. check(bunker_trg))
            g_imgui.add_text(trsl("MethTrig") .. check(meth_trg))
            g_imgui.add_text(trsl("CounterfitTrig") .. check(counterfit_trg))
            g_imgui.add_text(trsl("WeedTrig") .. check(weed_trg))
            g_imgui.add_text(trsl("DocumentTrig") .. check(document_trg))

            g_imgui.separator()
            g_imgui.add_text(trsl("CocaineLockup"))
            g_imgui.separator()

            g_imgui.add_text(trsl("EquipmentUp") .. upg_0_0)
            g_imgui.add_text(trsl("StaffUp") .. upg_0_1)
            g_imgui.add_text(trsl("SecuirityUp") .. upg_0_2)

            g_imgui.separator()
            g_imgui.add_text(trsl("MethLab"))
            g_imgui.separator()

            g_imgui.add_text(trsl("EquipmentUp") .. upg_1_0)
            g_imgui.add_text(trsl("StaffUp") .. upg_1_1)
            g_imgui.add_text(trsl("SecuirityUp") .. upg_1_2)

            g_imgui.separator()
            g_imgui.add_text(trsl("CounterfitFactory"))
            g_imgui.separator()

            g_imgui.add_text(trsl("EquipmentUp") .. upg_2_0)
            g_imgui.add_text(trsl("StaffUp") .. upg_2_1)
            g_imgui.add_text(trsl("SecuirityUp") .. upg_2_2)

            g_imgui.separator()
            g_imgui.add_text(trsl("WeedFarm"))
            g_imgui.separator()

            g_imgui.add_text(trsl("EquipmentUp") .. upg_3_0)
            g_imgui.add_text(trsl("StaffUp") .. upg_3_1)
            g_imgui.add_text(trsl("SecuirityUp") .. upg_3_2)

            g_imgui.separator()
            g_imgui.add_text(trsl("DocumentForgery"))
            g_imgui.separator()

            g_imgui.add_text(trsl("EquipmentUp") .. upg_4_0)
            g_imgui.add_text(trsl("StaffUp") .. upg_4_1)
            g_imgui.add_text(trsl("SecuirityUp") .. upg_4_2)

            g_imgui.separator()
            g_imgui.add_text(trsl("Bunker"))
            g_imgui.separator()

            g_imgui.add_text(trsl("EquipmentUp") .. bunker_equipment)
            g_imgui.add_text(trsl("StaffUp") .. bunker_staff)
            g_imgui.add_text(trsl("SecuirityUp") .. bunker_sequrity)
            g_imgui.add_text(trsl("DecorUp") .. bunker_decor)
            g_imgui.add_text(trsl("FiringRangeUp") .. bunker_firing_range)
            g_imgui.add_text(trsl("GunlockerUp") .. bunker_gunlocker)
            g_imgui.add_text(trsl("PersonalQuartersUp") .. bunker_savebed)
            g_imgui.add_text(trsl("TransportationUp") .. bunker_transportation)

            g_imgui.separator()
            g_imgui.add_text(trsl("Arcade"))
            g_imgui.separator()

            g_imgui.add_text(trsl("Machine1") .. arc_0)
            g_imgui.add_text(trsl("Machine2") .. arc_1)
            g_imgui.add_text(trsl("Machine3") .. arc_2)
            g_imgui.add_text(trsl("Machine4") .. arc_3)
            g_imgui.add_text(trsl("Machine5") .. arc_4)
            g_imgui.add_text(trsl("Machine6") .. arc_5)
            g_imgui.add_text(trsl("Machine7") .. arc_6)
            g_imgui.add_text(trsl("Machine8") .. arc_7)
            g_imgui.add_text(trsl("Machine9") .. arc_8)
            g_imgui.add_text(trsl("Machine10") .. arc_9)
            g_imgui.add_text(trsl("Machine11") .. arc_10)
            g_imgui.add_text(trsl("Machine12") .. arc_11)
            g_imgui.add_text(trsl("Machine13") .. arc_12)
            g_imgui.add_text(trsl("DroneSta") .. arc_drone_stat)
            g_imgui.add_text(trsl("BusinessHub") .. arc_business_hub)
            g_imgui.add_text(trsl("Floor") .. arc_floor)
            g_imgui.add_text(trsl("Style") .. arc_ceiling)
            g_imgui.add_text(trsl("Wall") .. arc_wall)
            g_imgui.add_text(trsl("PerQuar") .. arc_personal_quarters)
            g_imgui.add_text(trsl("Garage") .. arc_garage)
            g_imgui.add_text(trsl("NeonLights") .. arc_neon_lights)
            g_imgui.add_text(trsl("HighScoreScreen") .. arc_screen)

            g_imgui.separator()
            g_imgui.add_text(trsl("Nightclub"))
            g_imgui.separator()

            g_imgui.add_text(trsl("Style") .. nc_style)
            g_imgui.add_text(trsl("Lighting") .. nc_lighting)
            g_imgui.add_text(trsl("Dancers") .. nc_mod_4)
            g_imgui.add_text(trsl("StaffUp") .. nc_mod_5)
            g_imgui.add_text(trsl("PaidDJs") .. nc_mod_6)

            g_imgui.end_window()
        end
    end
end

g_hooking.register_D3D_hook(ui_upg)

toggle(
    "BuMang",
    "EnableManager",
    false,
    function(on)
        if NETWORK then
            show_man = on
        end
    end
)

toggle(
    "BuMang",
    "ManagerOverlay",
    false,
    function(on)
        if NETWORK then
            show_ov = on
        end
    end
)

toggle(
    "BuMang",
    "ShUp",
    false,
    function(on)
        if NETWORK then
            show_upg = on
        end
    end
)

-- [[ MC Related Stuff ]] --

submenu("BuMang", "RelatStuff")

--- Broken ---
--[[ button("RelatStuff", "TrigPro", function()
        if NETWORK then
                function gbi(id)
                        return 1853131 + 1 + PLAYER.PLAYER_ID() * 888 + 267 + 187 + 1 + id * 13
                end
                    
                function bid(id)
                        local meth = { 1, 6, 11, 16 }
                        local weed = { 2, 7, 12, 17 }
                        local cocaine = { 3, 8, 13, 18 }
                        local cash = { 4, 9, 14, 19 }
                        local docs = { 5, 10, 15, 20 }
                        for i = 0, 4 do
                            local idx = SCRIPT.GET_GLOBAL_I(gbi(i))
                            if id == 0 then
                                if meth[i] == idx then
                                    return i
                                end
                            elseif id == 1 then
                                if weed[i] == idx then
                                    return i
                                end
                            elseif id == 2 then
                                if cocaine[i] == idx then
                                    return i
                                end
                            elseif id == 3 then
                                if cash[i] == idx then
                                    return i
                                end
                            elseif id == 4 then
                                if docs[i] == idx then
                                    return i
                                end
                           end
                      end
                end           

                local supplies = SCRIPT.GET_GLOBAL_I(gbi(bid(1)) + 2)
                SCRIPT.SET_GLOBAL_I(gbi(bid(1)) + 9, 0)

        end
end) --]]
button(
    "BuMang",
    "sell test",
    function()
        if NETWORK then
            SCRIPT.SET_LOCAL_I(g_util.joaat("gb_biker_contraband_sell"), 707 + 122)
        end
    end
)

button(
    "BuMang",
    "test tun",
    function()
        if NETWORK then
            SCRIPT.SET_TUNABLE_I(18747, 0)
            SCRIPT.SET_TUNABLE_I(17226, 150000)
            SCRIPT.SET_TUNABLE_I(17197, 360)
            SCRIPT.SET_TUNABLE_F(18861, 1.5)
            SCRIPT.SET_TUNABLE_I(18705, 200)
            SCRIPT.SET_TUNABLE_I(17211, 600)
            SCRIPT.SET_TUNABLE_I(17206, 600)
            SCRIPT.SET_TUNABLE_I(17221, 10)
        end
    end
)

-- [[ Nightclub Options ]] --

submenu("RelatStuff", "NightOpt")

button(
    "NightOpt",
    "TpNightSaf",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        local nightid = INTERIOR.GET_INTERIOR_FROM_ENTITY(ped)
        if NETWORK then
            if (nightid == 271617) then
                g_gui.show_menu_ui(false)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PLAYER.PLAYER_PED_ID(), -1615.74, -3015.78, -75.20)
                better_yield(1)
                CONTROL.SET_CONTROL_NORMAL(0, 51, 1)
            end
        end
    end
)

toggle(
    "NightOpt",
    "NightBot",
    false,
    function(on)
        nightbot = on
        while nightbot do
            SYSTEM.WAIT(100)
            local ped = PLAYER.PLAYER_PED_ID()
            local nightid = INTERIOR.GET_INTERIOR_FROM_ENTITY(ped)
            if NETWORK then
                if (nightid == 271617) then
                    g_gui.show_menu_ui(false)
                    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, -1615.74, -3015.78, -75.20)
                    better_yield(1)
                    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, -1618.67, -3012.75, -75.20)
                    STAT_SET_INT("CLUB_POPULARITY", 1000)
                    STAT_SET_INT("CLUB_PAY_TIME_LEFT", -1)
                    SYSTEM.WAIT(100)
                    STAT_SET_INT("CLUB_POPULARITY", 1000)
                end
            end
        end
    end
)

-- [[ Arcade Options ]] --

submenu("RelatStuff", "ArcOpt")

button(
    "ArcOpt",
    "TpArcSaf",
    function()
        local ped = PLAYER.PLAYER_PED_ID()
        local arcid = INTERIOR.GET_INTERIOR_FROM_ENTITY(ped)
        if NETWORK then
            if (arcid == 278273) then
                g_gui.show_menu_ui(false)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PLAYER.PLAYER_PED_ID(), 2728.57, -374.31, -47.39)
                better_yield(1)
                CONTROL.SET_CONTROL_NORMAL(0, 51, 1)
            end
        end
    end
)

toggle(
    "ArcOpt",
    "ArcBot",
    false,
    function(on)
        nightbot = on
        while nightbot do
            SYSTEM.WAIT(100)
            local ped = PLAYER.PLAYER_PED_ID()
            local arcid = INTERIOR.GET_INTERIOR_FROM_ENTITY(ped)
            if NETWORK then
                STAT_SET_INT("ARCADE_PAY_TIME_LEFT", -1)
                if (arcid == 278273) then
                    g_gui.show_menu_ui(false)
                    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 2728.57, -374.31, -47.39)
                    better_yield(1)
                    CONTROL.SET_CONTROL_NORMAL(0, 51, 1)
                    better_yield(10)
                    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 758.879, -814.56, 26.30)
                    better_yield(1)
                    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 770.55, -814.47, 26.30)
                    better_yield(20)
                    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, 758.879, -814.56, 26.30)
                    better_yield(3)
                    CONTROL.SET_CONTROL_NORMAL(0, 201, 1)
                    better_yield(5)
                end
                STAT_SET_INT("ARCADE_PAY_TIME_LEFT", -1)
            end
        end
    end
)

toggle(
    "RelatStuff",
    "NightSaf",
    false,
    function(on)
        nightsafe = on
        while nightsafe do
            SYSTEM.WAIT(100)
            if NETWORK then
                STAT_SET_INT("CLUB_POPULARITY", 1000)
                STAT_SET_INT("CLUB_PAY_TIME_LEFT", -1)
                STAT_SET_INT("CLUB_POPULARITY", 1000)
            end
        end
    end
)

toggle(
    "RelatStuff",
    "ArcSafAdd",
    false,
    function(on)
        arcsafe = on
        while arcsafe do
            SYSTEM.WAIT(100)
            if NETWORK then
                STAT_SET_INT("ARCADE_PAY_TIME_LEFT", -1)
            end
        end
    end
)

-- [[ Other Stuff ]] --

toggle(
    "RemainingOptions",
    "XBy",
    false,
    function(xby)
        xby = on
        while xby do
            SYSTEM.WAIT(100)
            if NETWORK then
                SCRIPT.SET_GLOBAL_I(262145 + 9185, 0)
                SCRIPT.SET_GLOBAL_I(262145 + 9186, 0)
                SCRIPT.SET_GLOBAL_I(262145 + 9187, 0)
                SCRIPT.SET_GLOBAL_I(262145 + 9188, 0)
                SCRIPT.SET_GLOBAL_I(262145 + 9189, 0)
                SCRIPT.SET_GLOBAL_I(262145 + 9190, 0)
                SCRIPT.SET_GLOBAL_I(262145 + 9191, 0)
                SCRIPT.SET_GLOBAL_I(262145 + 9192, 0)
                SCRIPT.SET_GLOBAL_I(262145 + 9193, 7)
                SCRIPT.SET_GLOBAL_I(262145 + 9194, 7)
            end
        end
    end
)

button(
    "RemainingOptions",
    "MaxNightPop",
    function()
        if NETWORK then
            STAT_SET_INT("CLUB_POPULARITY", 1000)
        end
    end
)

--[[ button("RemainingOptions", "MaxSnack", function()
        if NETWORK then
                SCRIPT.SET_GLOBAL_F(262145+112, 100.0) -- Ps & Qs
                SCRIPT.SET_GLOBAL_F(262145+113, 100.0) -- Egochaser
                SCRIPT.SET_GLOBAL_F(262145+114, 100.0) -- Meteorite
                SCRIPT.SET_GLOBAL_F(262145+115, 100.0) -- Redwood
                SCRIPT.SET_GLOBAL_F(262145+116, 100.0) -- eCola
        end
end)

button("RemainingOptions", "ReqBalAr", function()
        if NETWORK then
                SCRIPT.SET_GLOBAL_I(2815059+884, 1)
        end
end)

toggle("RemainingOptions", "ReVIPWork", false, function(on)
        rmc = on
        while rmc do
                SYSTEM.WAIT(100)
                if NETWORK then
                        SCRIPT.SET_GLOBAL_I(262145+12871, 0)
                end
        end
end)

toggle("RemainingOptions", "ReClient", false, function(on)
        cjc = on
        while cjc do
                SYSTEM.WAIT(100)
                if NETWORK then
                        SCRIPT.SET_GLOBAL_I(262145+24398, 0) -- Between Jobs
                        SCRIPT.SET_GLOBAL_I(262145+24399, 0) -- Robbery in Progress
                        SCRIPT.SET_GLOBAL_I(262145+24400, 0) -- Data Sweep
                        SCRIPT.SET_GLOBAL_I(262145+24401, 0) -- Targeted Data
                        SCRIPT.SET_GLOBAL_I(262145+24402, 0) -- Diamond Shopping
                end
        end
end) --]]
toggle(
    "RemainingOptions",
    "ReMissCow",
    false,
    function(on)
        rmc = on
        while rmc do
            SYSTEM.WAIT(100)
            if NETWORK then
                SCRIPT.SET_GLOBAL_I(262145 + 29837, 0)
                SCRIPT.SET_GLOBAL_I(262145 + 29838, 99999)
            end
        end
    end
)

toggle(
    "RemainingOptions",
    "InfPow",
    false,
    function(on)
        sthp = on
        while sthp do
            SYSTEM.WAIT(100)
            if NETWORK then
                SCRIPT.SET_GLOBAL_I(262145 + 25064, 999999)
                SCRIPT.SET_GLOBAL_I(262145 + 25065, 999999)
                SCRIPT.SET_GLOBAL_I(262145 + 25066, 0)
            end
        end
    end
)

button(
    "RemainingOptions",
    "ReChipCow",
    function()
        if NETWORK then
            STAT_SET_INT_MPPLY("MPPLY_CASINO_CHIPS_PUR_GD", 0)
            STAT_SET_INT_MPPLY("MPPLY_CASINO_CHIPS_PURTIM", 0)
        end
    end
)

button(
    "RemainingOptions",
    "ReflMCSup",
    function()
        if NETWORK then
            STAT_SET_INT("PAYRESUPPLYTIMER0", 1)
            STAT_SET_INT("PAYRESUPPLYTIMER1", 1)
            STAT_SET_INT("PAYRESUPPLYTIMER2", 1)
            STAT_SET_INT("PAYRESUPPLYTIMER3", 1)
            STAT_SET_INT("PAYRESUPPLYTIMER4", 1)
        end
    end
)

button(
    "RemainingOptions",
    "ReflBunkSup",
    function()
        if NETWORK then
            STAT_SET_INT("PAYRESUPPLYTIMER5", 1)
        end
    end
)

button(
    "RemainingOptions",
    "ReMent",
    function()
        STAT_SET_FLOAT("MPPLY_PLAYER_MENTAL_STATE", 0.0, true)
        STAT_SET_FLOAT("MP0_PLAYER_MENTAL_STATE", 0.0, true)
        STAT_SET_FLOAT("MP1_PLAYER_MENTAL_STATE", 0.0, true)
    end
)

button(
    "RemainingOptions",
    "ReDailyObj",
    function()
        if NETWORK then
            SCRIPT.SET_GLOBAL_I(8810, 1)
            SCRIPT.SET_GLOBAL_I(2785396, 1)
        end
    end
)

button(
    "Unlocks",
    "BeBad",
    function()
        if NETWORK then
            STAT_SET_INT("MPPLY_BADSPORT_MESSAGE", 2147483647, true)
            STAT_SET_INT("MPPLY_BECAME_BADSPORT_NUM", 2147483647, true)
            STAT_SET_FLOAT("MPPLY_OVERALL_BADSPORT", 60000, true)
            STAT_SET_BOOL("MPPLY_CHAR_IS_BADSPORT", true, true)
        end
    end
)

button(
    "Unlocks",
    "ReBad",
    function()
        if NETWORK then
            STAT_SET_INT("MPPLY_BADSPORT_MESSAGE", 0, true)
            STAT_SET_INT("MPPLY_BECAME_BADSPORT_NUM", 0, true)
            STAT_SET_FLOAT("MPPLY_OVERALL_BADSPORT", 0, true)
            STAT_SET_BOOL("MPPLY_CHAR_IS_BADSPORT", false, true)
        end
    end
)

input(
    "RemainingOptions",
    "SetRP",
    0,
    2,
    8000,
    function(rp)
        if NETWORK then
            local player = STATS.STAT_GET_INT(g_util.joaat("MPPLY_LAST_MP_CHAR"))
            local rp_amount = SCRIPT.GET_GLOBAL_I(1659760 + player)
            local rp_level = 0
            for i = 0, 8000 do
                if rp_amount < SCRIPT.GET_GLOBAL_I(295825 + i) then
                    break
                else
                    rp_level = i
                end
            end
            local new_rp = SCRIPT.GET_GLOBAL_I(295825 + rp)
            STAT_SET_INT("CHAR_SET_RP_GIFT_ADMIN", new_rp)
        end
    end
)

--[[
 ____  _        _ __   _______ ____     ___  ____ _____ ___ ___  _   _ ____  
|  _ \| |      / \\ \ / / ____|  _ \   / _ \|  _ \_   _|_ _/ _ \| \ | / ___| 
| |_) | |     / _ \\ V /|  _| | |_) | | | | | |_) || |  | | | | |  \| \___ \ 
|  __/| |___ / ___ \| | | |___|  _ <  | |_| |  __/ | |  | | |_| | |\  |___) |
|_|   |_____/_/   \_\_| |_____|_| \_\  \___/|_|    |_| |___\___/|_| \_|____/                                                                          
]]
-- [[ Helpful ]] --

separator("Raid Players", "Helpful")

-- [[ Gift Vehicle Options ]] --

submenu("Raid Players", "GiftVeh")

toggle(
    "GiftVeh",
    "SpFrPl",
    false,
    "SpFrPlBio",
    function(on)
        if NETWORK then
            spfrpl = on
        end
    end
)

toggle(
    "GiftVeh",
    "SpMax",
    false,
    function(on)
        if NETWORK then
            spmax = on
        end
    end
)

toggle(
    "GiftVeh",
    "SpF1",
    false,
    function(on)
        if NETWORK then
            spf1 = on
        end
    end
)

button(
    "GiftVeh",
    "GiftSecVeh",
    "GiftSecVehBio",
    function()
        if NETWORK then
            local player = g_util.get_selected_player()
            if spfrpl then
                if PED.IS_PED_IN_ANY_VEHICLE(player) then
                    ped = PLAYER.GET_PLAYER_PED(player)
                end
            else
                ped = PLAYER.PLAYER_PED_ID()
            end
            local get_veh = PED.GET_VEHICLE_PED_IS_USING(ped)
            local veh_hash = ENTITY.GET_ENTITY_MODEL(get_veh)
            local pos = PLAYER.GET_PLAYER_COORDS(player)
            local spawned_vehicle = VEHICLE.CREATE_VEHICLE(veh_hash, pos.x, pos.y, pos.z, 0, true, false, false)
            if spmax then
                if not (spawned_vehicle == 0) then
                    VEHICLE.SET_VEHICLE_MOD_KIT(spawned_vehicle, 0)
                    for tune = 0, 48 do
                        VEHICLE.SET_VEHICLE_MOD(
                            spawned_vehicle,
                            tune,
                            VEHICLE.GET_NUM_VEHICLE_MODS(spawned_vehicle, tune) - 1,
                            false
                        )
                    end
                    VEHICLE.TOGGLE_VEHICLE_MOD(spawned_vehicle, 22, true) -- enable xenon
                end
            end
            if spf1 then
                if PED.IS_PED_IN_ANY_VEHICLE(PLAYER.PLAYER_PED_ID()) then
                    g_util.trigger_request_control_event(spawned_vehicle)
                    VEHICLE.SET_VEHICLE_MOD_KIT(spawned_vehicle, 0)
                    VEHICLE.SET_VEHICLE_WHEEL_TYPE(spawned_vehicle, 10)
                    VEHICLE.SET_VEHICLE_MOD(spawned_vehicle, 23, 83, false)
                end
            end
            local player_hash = NETWORK.NETWORK_HASH_FROM_PLAYER(player)
            DECORATOR.DECOR_SET_INT(spawned_vehicle, "Player_Vehicle", player_hash)
            DECORATOR.DECOR_SET_INT(spawned_vehicle, "Veh_Modded_By_Player", player_hash)
            DECORATOR.DECOR_SET_INT(spawned_vehicle, "PV_Slot", 2)
            DECORATOR.DECOR_SET_INT(spawned_vehicle, "Previous_Owner", player_hash)
            if PED.IS_PED_IN_ANY_VEHICLE(PLAYER.PLAYER_PED_ID()) then
                local veh = PED.GET_VEHICLE_PED_IS_USING(PLAYER.PLAYER_PED_ID())
                ENTITY.SET_ENTITY_AS_MISSION_ENTITY(veh, false, false)
                ENTITY.DELETE_ENTITY(veh)
            end
            PED.SET_PED_INTO_VEHICLE(ped, spawned_vehicle, -1)
        end
    end
)

button(
    "Raid Players",
    "SpArmVeh",
    function()
        local vh_spawn = 0x187D938D
        STREAMING.REQUEST_MODEL(vh_spawn)
        while (not STREAMING.HAS_MODEL_LOADED(vh_spawn)) do
            g_util.yield()
        end
        local pos = PLAYER.GET_PLAYER_COORDS(g_util.get_selected_player())
        if PED.IS_PED_IN_ANY_VEHICLE(PLAYER.PLAYER_PED_ID()) then
            local veh = PED.GET_VEHICLE_PED_IS_USING(PLAYER.PLAYER_PED_ID())
            ENTITY.SET_ENTITY_AS_MISSION_ENTITY(veh, false, false)
            ENTITY.DELETE_ENTITY(veh)
        end
        local spawned_vehicle = VEHICLE.CREATE_VEHICLE(vh_spawn, pos.x, pos.y, pos.z, 0, true, false, false)
        ENTITY.SET_ENTITY_INVINCIBLE(spawned_vehicle, true)
    end
)

toggle(
    "Raid Players",
    "GivExpoAm",
    false,
    function(on)
        expam = on
        while expam do
            SYSTEM.WAIT(0)
            local ped = PLAYER.GET_PLAYER_PED(g_util.get_selected_player())
            if PED.IS_PED_SHOOTING(ped) then
                local pos = PED.GET_PED_LAST_WEAPON_IMPACT(ped)
                FIRE.ADD_EXPLOSION(pos.x, pos.y, pos.z, 7, 100, true, false, 0, false)
            end
        end
    end
)

-- [[ CEO ]] --

separator("Raid Players", "CEO")

toggle(
    "Raid Players",
    "10Work",
    false,
    "BioCEO",
    function(on)
        ceo1 = on
        while ceo1 do
            SYSTEM.WAIT(120000)
            if SCRIPT.GET_GLOBAL_I(2815059 + 1801) ~= 0 then
                for player = 0, 31 do
                    if ENTITY.DOES_ENTITY_EXIST(PLAYER.GET_PLAYER_PED(player)) then
                        local args = {
                            547083265,
                            player,
                            10000,
                            -1292453789,
                            0,
                            SCRIPT.GET_GLOBAL_I(1892703 + (1 + (player * 599) + 510)),
                            SCRIPT.GET_GLOBAL_I(1920255 + 9),
                            SCRIPT.GET_GLOBAL_I(1920255 + 10)
                        }
                        g_util.trigger_script_event(player, args)
                    end
                end
            end
        end
    end
)

toggle(
    "Raid Players",
    "10Special",
    false,
    "BioCEO",
    function(on)
        ceo2 = on
        while ceo2 do
            SYSTEM.WAIT(60000)
            if SCRIPT.GET_GLOBAL_I(2815059 + 1801) ~= 0 then
                for player = 0, 31 do
                    if ENTITY.DOES_ENTITY_EXIST(PLAYER.GET_PLAYER_PED(player)) then
                        local args = {
                            547083265,
                            player,
                            10000,
                            -1292453789,
                            1,
                            SCRIPT.GET_GLOBAL_I(1892703 + (1 + (player * 599) + 510)),
                            SCRIPT.GET_GLOBAL_I(1920255 + 9),
                            SCRIPT.GET_GLOBAL_I(1920255 + 10)
                        }
                        g_util.trigger_script_event(player, args)
                    end
                end
            end
        end
    end
)

toggle(
    "Raid Players",
    "10Veh",
    false,
    "BioCEO",
    function(on)
        ceo3 = on
        while ceo3 do
            SYSTEM.WAIT(60000)
            if SCRIPT.GET_GLOBAL_I(2815059 + 1801) ~= 0 then
                for player = 0, 31 do
                    if ENTITY.DOES_ENTITY_EXIST(PLAYER.GET_PLAYER_PED(player)) then
                        local args = {
                            547083265,
                            player,
                            10000,
                            -1292453789,
                            1,
                            SCRIPT.GET_GLOBAL_I(1892703 + (1 + (player * 599) + 510)),
                            SCRIPT.GET_GLOBAL_I(1920255 + 9),
                            SCRIPT.GET_GLOBAL_I(1920255 + 10)
                        }
                        g_util.trigger_script_event(player, args)
                    end
                end
            end
        end
    end
)

toggle(
    "Raid Players",
    "30Cargo",
    false,
    "BioCEO",
    function(on)
        ceo4 = on
        while ceo4 do
            SYSTEM.WAIT(120000)
            if SCRIPT.GET_GLOBAL_I(2815059 + 1801) ~= 0 then
                for player = 0, 31 do
                    if ENTITY.DOES_ENTITY_EXIST(PLAYER.GET_PLAYER_PED(player)) then
                        local args = {
                            547083265,
                            player,
                            30000,
                            198210293,
                            1,
                            SCRIPT.GET_GLOBAL_I(1892703 + (1 + (player * 599) + 510)),
                            SCRIPT.GET_GLOBAL_I(1920255 + 9),
                            SCRIPT.GET_GLOBAL_I(1920255 + 10)
                        }
                        g_util.trigger_script_event(player, args)
                    end
                end
            end
        end
    end
)

toggle(
    "Raid Players",
    "60CEOLoop",
    false,
    "BioCEO",
    function(on)
        ceo5 = on
        while ceo5 do
            SYSTEM.WAIT(60000)
            if SCRIPT.GET_GLOBAL_I(2815059 + 1801) ~= 0 then
                for player = 0, 31 do
                    local glob1 =  SCRIPT.GET_GLOBAL_I(1892703 + (1 + (player * 599) + 510))
                    local glob2 =  SCRIPT.GET_GLOBAL_I(1920255 + 9)
                    local glob3 =  SCRIPT.GET_GLOBAL_I(1920255 + 10)
                    if ENTITY.DOES_ENTITY_EXIST(PLAYER.GET_PLAYER_PED(player)) then
                        local args = {
                            547083265,
                            player,
                            10000,
                            -1292453789,
                            0,
                            glob1,
                            glob2,
                            glob3
                        }
                        g_util.trigger_script_event(player, args)
                    end
                    SYSTEM.WAIT(1500)
                    if ENTITY.DOES_ENTITY_EXIST(PLAYER.GET_PLAYER_PED(player)) then
                        local args = {
                            547083265,
                            player,
                            10000,
                            -1292453789,
                            1,
                            glob1,
                            glob2,
                            glob3
                        }
                        g_util.trigger_script_event(player, args)
                    end
                    SYSTEM.WAIT(1500)
                    if ENTITY.DOES_ENTITY_EXIST(PLAYER.GET_PLAYER_PED(player)) then
                        local args = {
                            547083265,
                            player,
                            10000,
                            -1292453789,
                            1,
                            glob1,
                            glob2,
                            glob3
                        }
                        g_util.trigger_script_event(player, args)
                    end
                    SYSTEM.WAIT(1500)
                    if ENTITY.DOES_ENTITY_EXIST(PLAYER.GET_PLAYER_PED(player)) then
                        local args = {
                            547083265,
                            player,
                            30000,
                            198210293,
                            1,
                            glob1,
                            glob2,
                            glob3
                        }
                        g_util.trigger_script_event(player, args)
                    end
                end
            end
        end
    end
)

while true do
    -- [[ Unload Key "Delete" (46) ]] --
    if g_util.is_key_pressed(46) then
        SYSTEM.WAIT(3000)
        g_lua.unregister()
    end
    -- [[ Main Loops ]] --
    handle_inputs()
    check_status()
    refresh_data()
    if BOX_ESP then
        Box_ESP()
    end
    g_util.yield()
end