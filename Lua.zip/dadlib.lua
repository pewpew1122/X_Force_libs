
local player_char = STATS.STAT_GET_INT(g_util.joaat("MPPLY_LAST_MP_CHAR"))


function getCrates()
    g_util.yield(1000)
   
    g_gui.add_toast("XF need to update crossmaps here to make it work",8000)
       local PlayerIndex = STATS.STAT_GET_INT(g_util.joaat("MPPLY_LAST_MP_CHAR"))
       local mpx = PlayerIndex if PlayerIndex == 0 then mpx = "MP0_" else mpx = "MP1_" end
        STATS.STAT_SET_BOOL_MASKED(g_util.joaat(mpx .. "FIXERPSTAT_BOOL1"), true, 12,true)
       
end

function sellCargo()
 SCRIPT.SET_GLOBAL_I(277988, 10000000)
 SCRIPT.SET_GLOBAL_I(277989, 5000000)
 SCRIPT.SET_GLOBAL_I(277990, 3333333)
 g_gui.add_toast("Done",2000)

 g_gui.add_toast("Works only in solo session",8000)
end

function resetsellCargo()

 	SCRIPT.SET_GLOBAL_I(277754, 0)
   
	g_gui.add_toast("Done",2000)
end

function buycooldwn()
	g_gui.add_toast("Done",2000)
            SCRIPT.SET_GLOBAL_I(277754, 0)
        end

function ncs()
	

    STATS.STAT_SET_INT(g_util.joaat("MP" .. player_char .."_LIFETIME_BUY_COMPLETE"), 700, true)
    STATS.STAT_SET_INT(g_util.joaat("MP" .. player_char .. "_LIFETIME_BUY_UNDERTAKEN"), 783, true)
    STATS.STAT_SET_INT(g_util.joaat("MP" .. player_char .."_LIFETIME_SELL_COMPLETE"), 783, true)
    STATS.STAT_SET_INT(g_util.joaat("MP" .. player_char .. "_LIFETIME_SELL_UNDERTAKEN"), 783, true)
    STATS.STAT_SET_INT(g_util.joaat("MP" .. player_char .. "_LIFETIME_CONTRA_EARNINGS"), 15660070, true)

	g_gui.add_toast("Done")
end

function ulpskip()  
    STATS.STAT_SET_INT(g_util.joaat("MP" .. player_char .."_ULP_MISSION_PROGRESS"), 127, true)
    STATS.STAT_SET_INT(g_util.joaat("MP" .. player_char .."_ULP_MISSION_CURRENT"), 127, true)
   
end

function finaleSkip()  

    SCRIPT.SET_GLOBAL_I(19679, 12)
    SCRIPT.SET_GLOBAL_I(28298 + 1, 99999) 
    SCRIPT.SET_GLOBAL_I(31554 + 69, 1)
 
    
end
function prep_skip()  
    STATS.STAT_SET_INT(g_util.joaat("MP" .. player_char .."_HEIST_PLANNING_STAGE"), -1, true)
    
end

function removeMoney()  
    SCRIPT.SET_GLOBAL_I(282478, 1000000) 
    g_gui.add_toast("Done")
    g_gui.add_toast("Buy ballistic armour for 10M")
end



function ncMoney()
    g_util.yield(100)
    
        SCRIPT.SET_GLOBAL_I(262145 + 24073, 300000) 
         SCRIPT.SET_GLOBAL_I(262145 + 24069, 300000) -- thanks to Bababoiiiii#7176 
           STATS.STAT_SET_INT(g_util.joaat("MP" .. player_char .. "_CLUB_POPULARITY"), 100000, true)
           g_util.yield(200)
           STATS.STAT_SET_INT(g_util.joaat("MP" .. player_char .. "_CLUB_PAY_TIME_LEFT"), -1, true)
           g_util.yield(200)
    
	end

	function ncStats()
		
        STATS.STAT_SET_INT(g_util.joaat("MP" .. player_char .."NIGHTCLUB_JOBS_DONE"), 0,true)
        STATS.STAT_SET_INT(g_util.joaat("MP" .. player_char .."NIGHTCLUB_EARNINGS"), 0,true)
        STATS.STAT_SET_INT(g_util.joaat("MP" .. player_char .."NIGHTCLUB_VIP_APPEAR"), 0,true)
        STATS.STAT_SET_INT(g_util.joaat("MP" .. player_char .."NIGHTCLUB_JOBS_DONE"), 0,true) 
        STATS.STAT_SET_INT(g_util.joaat("MP" .. player_char .."HUB_SALES_COMPLETED"), 0,true)
        STATS.STAT_SET_INT(g_util.joaat("MP" .. player_char .."HUB_EARNINGS"), 0,true)
        STATS.STAT_SET_INT(g_util.joaat("MP" .. player_char .."DANCE_COMBO_DURATION_MINS"), 0,true)
        STATS.STAT_SET_INT(g_util.joaat("MP" .. player_char .."NIGHTCLUB_PLAYER_APPEAR"), 0,true)
        STATS.STAT_SET_INT(g_util.joaat("MP" .. player_char .."LIFETIME_HUB_GOODS_SOLD"), 0,true)
        STATS.STAT_SET_INT(g_util.joaat("MP" .. player_char .."LIFETIME_HUB_GOODS_MADE"), 0,true)
	end
    
	function agency()
	g_util.yield(3000)
    g_gui.add_toast("open the safe and stay next to it, so you collect the money",1000)
    SCRIPT.SET_GLOBAL_I(PLAYER.PLAYER_ID() * 834 + 1854098, 200000)
	STATS.STAT_SET_INT(g_util.joaat("MP" .. player_char .. "_FIXER_PASSIVE_PAY_TIME_LEFT"), -1, true)
     g_util.yield(5500)
       
end

function tpagency()
	g_util.yield(100)
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PLAYER.PLAYER_PED_ID(), -590.90380859375, -707.34234619140625, 36.279422760009766)
end
function acStats()
	STATS.STAT_SET_INT(g_util.joaat("MP" .. player_char .. "_FIXER_COUNT"), 0, true)
    STATS.STAT_SET_INT(g_util.joaat("MP" .. player_char .. "_FIXER_EARNINGS"), 0, true)
end

function arcmoney() 
    SCRIPT.SET_GLOBAL_I(PLAYER.PLAYER_ID() * 834 + 1854029, 100000)
STATS.STAT_SET_INT(g_util.joaat("MP" .. player_char .. "_ARCADE_PAY_TIME_LEFT"), -100, true)
g_util.yield(500)
	end

	function arcsafe()
		PlauerChar = PLAYER.GET_PLAYER_PED(PLAYER.PLAYER_ID())
		ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 2728.023681640625,-374.30294799804688, -47.398490905761719)--safe
	end

		function outside()
			PlauerChar = PLAYER.GET_PLAYER_PED(PLAYER.PLAYER_ID())
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 758.8797607421875,-814.56719970703125, 26.304239273071289)--outside
	end
		function bountykekw()
			g_util.yield(100)
			ENTITY.SET_ENTITY_INVINCIBLE(PLAYER.PLAYER_PED_ID(), true)
			g_util.yield(100)
			if ENTITY.DOES_ENTITY_EXIST(PLAYER.GET_PLAYER_PED(PLAYER.PLAYER_ID())) and not ENTITY.IS_ENTITY_DEAD(PLAYER.GET_PLAYER_PED(PLAYER.PLAYER_ID())) then
				for player=0,31 do
					if ENTITY.DOES_ENTITY_EXIST(PLAYER.GET_PLAYER_PED(player)) then
						for target=0,31 do 
							if ENTITY.DOES_ENTITY_EXIST(PLAYER.GET_PLAYER_PED(target)) and target ~= PLAYER.PLAYER_ID() then
								local global1 = SCRIPT.GET_GLOBAL_I(1920255+9)
								local global2 = SCRIPT.GET_GLOBAL_I(1920255+10)
								local args = { 1915499503, player, target, 3, 10000, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, global1, global2 }
								g_util.trigger_script_event(player, args)
							end
							g_util.yield()
						end
					end
					g_util.yield()
				end
				g_util.yield(500)
				for kill = 0,31 do 
					local ped = PLAYER.GET_PLAYER_PED(kill)
					if ENTITY.DOES_ENTITY_EXIST(ped) and not ENTITY.IS_ENTITY_DEAD(ped) then
						local pos = ENTITY.GET_ENTITY_COORDS(ped)
						FIRE.ADD_OWNED_EXPLOSION(PLAYER.GET_PLAYER_PED(PLAYER.PLAYER_ID()), pos.x, pos.y, pos.z, 0, 5.0, false, false, 0.0)
					end
					if ENTITY.DOES_ENTITY_EXIST(ped) and not ENTITY.IS_ENTITY_DEAD(ped) then
						local pos = ENTITY.GET_ENTITY_COORDS(ped)
						FIRE.ADD_OWNED_EXPLOSION(PLAYER.GET_PLAYER_PED(PLAYER.PLAYER_ID()), pos.x, pos.y, pos.z, 0, 5.0, false, false, 0.0)
					end
					if ENTITY.DOES_ENTITY_EXIST(ped) and not ENTITY.IS_ENTITY_DEAD(ped) then
						local pos = ENTITY.GET_ENTITY_COORDS(ped)
						FIRE.ADD_OWNED_EXPLOSION(PLAYER.GET_PLAYER_PED(PLAYER.PLAYER_ID()), pos.x, pos.y, pos.z, 0, 5.0, false, false, 0.0)
					end
					g_util.yield()  
				end
				ENTITY.SET_ENTITY_INVINCIBLE(PLAYER.PLAYER_PED_ID(), false)
					g_util.yield(1500)
			end
			SYSTEM.WAIT(35000)
            g_gui.add_toast("Loop finished.",7000) 
		end		
    

		function action()
			g_gui.add_toast("This will take some time...",7000)
    PlauerChar = PLAYER.GET_PLAYER_PED(PLAYER.PLAYER_ID())
	ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 3514,3754,35)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 3799,4473,7)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 3306,5194,18)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 2937,4620,48)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 2725,4142,44)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 2487,3759,43)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 1886,3913,33)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 1702,3290,48)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 1390,3608,34)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 1295.646,4306.300,37.317)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 1714,4791,41)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 2416,4994,46)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 2221,5612,55)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 1540,6323,24)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 1310,6545,5)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 457,5573,781)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 178,6394,31)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -312,6314,32)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -689,5829,17)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -552,5330,75)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -263,4729,138)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -1121,4977,186)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -2168.814,5192.917,16.601)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -2186,4250,48)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -2172,3441,31)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -1649,3018,32)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -1281,2550,18)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -1514,1517,111)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -1895,2043,142)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -2558,2316,33)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -3244,996,13)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -2959,386,14)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -3020,41,10)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -2238,249,176)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -1807,427,132)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -1502,813,181)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -770,877,204)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -507,393,97)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -487,-55,39)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -294,-343,10)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -180,-632,49)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -108,-857,39)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -710,-906,19)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -909,-1149,2)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -1213,-960,1)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -1051,-523,36)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -989,-102,40)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -1024,190,62)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -1462,182,55)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -1720,-234,55)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -1547,-449,40)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -1905,-710,8)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -1648,-1095,13)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -1351,-1547,4)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -887,-2097,9)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -929,-2939,13)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 153,-3078,7)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 483,-3111,6)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -56,-2521,7)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 368,-2114,17)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 875,-2165,32)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 1244,-2573,43)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 1498,-2134,76)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 1207,-1480,34)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 679,-1523,9)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 379,-1510,29)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -44,-1749,29)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -66,-1453,32)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 173,-1209,30)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 657,-1047,22)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 462,-766,27)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 171,-564,22)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 621,-410,-1)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 1136,-667,57)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 988,-138,73)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 1667,0,166)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 2500,-390,95)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 2549,385,108)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 2618,1692,31)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 1414,1162,114)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 693,1201,345)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 660,549,130)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 219,97,97)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -141,234,99)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 87,812,211)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -91,939,233)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -441,1596,358)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -58,1939,190)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -601,2088,132)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -300,2847,55)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 63,3683,39)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 543,3074,40)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 387,2570,44)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 852,2166,52)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 1408,2157,98)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 1189,2641,38)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 1848,2700,63)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 2635,2931,44)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 2399,3063,54)
    g_util.yield(5000)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 2394,3062,52)
end
function cards()
	g_gui.add_toast("The COORDS ARE NOT PERFECTLY SET! YOU HAVE TO MOVE A BIT SORRY ",10000)
    g_gui.add_toast("This will take some time",10000)
PlauerChar = PLAYER.GET_PLAYER_PED(PLAYER.PLAYER_ID())
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -1028, -2747, 14)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -74, -2005, 18)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 202, -1645, 29)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 120, -1298, 29)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 11, -1102, 29)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -539, -1279, 27)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -1205, -1560, 4)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -1288, -1119, 7)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -1841, -1235, 13)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -1155, -528, 31)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -1167, -234, 37)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -971, 104, 55)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -1513, -105, 54)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -3048, 585, 7)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -3150, 1115, 20)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -1829, 798, 138)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -430, 1214, 325)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -409, 585, 125)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -103, 368, 112)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 253, 215, 106)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -168, -298, 40)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 183, -686, 43)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 1131, -983, 46)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 1159, -317, 69)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 548, -190, 54)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 1487, 1128, 114)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 730, 2514, 73)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 188, 3075, 43)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -288, 2545, 75)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -1103, 2714, 19)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -2306, 3388, 31)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -1583, 5204, 4)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -749, 5599, 41)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -283, 6225, 31)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 99, 6620, 32)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 1876, 6410, 46)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 2938, 5325, 101)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 3688, 4569, 25)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 2694, 4324, 45)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 2120, 4784, 40)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 1707, 4920, 42)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 727, 4189, 41)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, -524, 4193, 193)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 79, 3704, 41)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 900, 3557, 33)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 1690, 3588, 35)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 1991, 3045, 47)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 2747, 3465, 55)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 2341, 2571, 47)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 2565, 297, 108)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 1325, -1652, 52)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 989, -1801, 31)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 827, -2159, 29)
g_util.yield(5000)
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PlauerChar, 810, -2979, 6)
end



function checkban()
	g_gui.add_toast("Reason: X-Force v6.9b4 or Nightclub",15000)
    g_gui.add_toast("Banned accounts: 7",15000)
    g_gui.add_toast("safety satus: SAFE",15000)
    g_gui.add_toast("Ban rate: about 3-5%",15000)
    end

	function warn()
		
        if STATS.STAT_GET_BOOL(g_util.joaat("MPPLY_IS_HIGH_EARNER")) or STATS.STAT_GET_BOOL(g_util.joaat("MPPLY_IS_CHEATER")) or STATS.STAT_GET_BOOL(g_util.joaat("MPPLY_IS_CHEATER")) then
            g_gui.add_toast("BE CAREFUL!")
            g_util.yield(100)
            g_gui.add_toast("FLAGGED AS CHEATER!")
        else 
            g_gui.add_toast("Not flagged")
             end
        
         end
     
	function minigame()
		local schwanzkase = math.random(1,5)

if schwanzkase==1 then
 local you = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(you, 241.03279113769531,-232.517333984375, 400.030452728271484)
        local fickmeineeier= -1295027632
        local coords = PLAYER.GET_PLAYER_COORDS(PLAYER.PLAYER_ID())
        STREAMING.REQUEST_MODEL(fickmeineeier)
		while (not STREAMING.HAS_MODEL_LOADED(fickmeineeier)) do
			SYSTEM.WAIT(100)
		end
        local bastard =VEHICLE.CREATE_VEHICLE(fickmeineeier, coords.x, coords.y , coords.z, 1.0, true, true, false)
    PED.SET_PED_INTO_VEHICLE(you, bastard, -1)
    
    g_util.yield(5000)
    local schwanz = PED.GET_VEHICLE_PED_IS_USING(you)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(schwanz,241.03279113769531,-232.517333984375, 400.030452728271484)
                VEHICLE.SET_VEHICLE_ENGINE_HEALTH(schwanz, 400)
                VEHICLE.SET_VEHICLE_ENGINE_ON(schwanz, true,true, false)
                VEHICLE.SET_VEHICLE_FORWARD_SPEED(schwanz, 150)
              
    elseif  schwanzkase==2 then
        local you = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(you, -2165.858642578125,-414.45693969726563,  400.34978199005127)
        local fickmeineeier= -1295027632
        local coords = PLAYER.GET_PLAYER_COORDS(PLAYER.PLAYER_ID())
        STREAMING.REQUEST_MODEL(fickmeineeier)
		while (not STREAMING.HAS_MODEL_LOADED(fickmeineeier)) do
			SYSTEM.WAIT(100)
		end
        local bastard =VEHICLE.CREATE_VEHICLE(fickmeineeier, coords.x, coords.y , coords.z, 1.0, true, true, false)
    PED.SET_PED_INTO_VEHICLE(you, bastard, -1)
    g_util.yield(5000)
    local schwanz = PED.GET_VEHICLE_PED_IS_USING(you)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(schwanz,  -2165.858642578125,-414.45693969726563,  400.34978199005127)
                VEHICLE.SET_VEHICLE_ENGINE_HEALTH(schwanz, 400)
                VEHICLE.SET_VEHICLE_ENGINE_ON(schwanz, true,true, false)
                VEHICLE.SET_VEHICLE_FORWARD_SPEED(schwanz, 150)

            elseif  schwanzkase==3 then
                local you = PLAYER.PLAYER_PED_ID()
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(you, 1648.945556640625, 1857.437744140625, 400.66812133789063)
                local fickmeineeier= -1295027632
                local coords = PLAYER.GET_PLAYER_COORDS(PLAYER.PLAYER_ID())
                STREAMING.REQUEST_MODEL(fickmeineeier)
                while (not STREAMING.HAS_MODEL_LOADED(fickmeineeier)) do
                    SYSTEM.WAIT(100)
                end
                local bastard =VEHICLE.CREATE_VEHICLE(fickmeineeier, coords.x, coords.y , coords.z, 1.0, true, true, false)
            PED.SET_PED_INTO_VEHICLE(you, bastard, -1)
            g_util.yield(5000)
    local schwanz = PED.GET_VEHICLE_PED_IS_USING(you)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(schwanz, 1648.945556640625, 1857.437744140625, 400.66812133789063)
                VEHICLE.SET_VEHICLE_ENGINE_HEALTH(schwanz, 400)
                VEHICLE.SET_VEHICLE_ENGINE_ON(schwanz, true,true, false)
                VEHICLE.SET_VEHICLE_FORWARD_SPEED(schwanz, 150)
                
                    elseif  schwanzkase==4 then
                        local you = PLAYER.PLAYER_PED_ID()
                        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(you, 29.110847473144531,-1349.025390625, 400.513114929199219)
                        local fickmeineeier= -1295027632
                        local coords = PLAYER.GET_PLAYER_COORDS(PLAYER.PLAYER_ID())
                        STREAMING.REQUEST_MODEL(fickmeineeier)
                        while (not STREAMING.HAS_MODEL_LOADED(fickmeineeier)) do
                            SYSTEM.WAIT(100)
                        end
                        local bastard =VEHICLE.CREATE_VEHICLE(fickmeineeier, coords.x, coords.y , coords.z, 1.0, true, true, false)
                    PED.SET_PED_INTO_VEHICLE(you, bastard, -1)
                    g_util.yield(5000)
    local schwanz = PED.GET_VEHICLE_PED_IS_USING(you)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(schwanz, 29.110847473144531,-1349.025390625, 400.513114929199219)
                VEHICLE.SET_VEHICLE_ENGINE_HEALTH(schwanz, 400)
                VEHICLE.SET_VEHICLE_ENGINE_ON(schwanz, true,true, false)
                VEHICLE.SET_VEHICLE_FORWARD_SPEED(schwanz, 150)
               
                            elseif  schwanzkase==5 then
                                local you = PLAYER.PLAYER_PED_ID()
                                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(you, 1972.107421875,6324.7080078125,  400.576740264892578)
                                local fickmeineeier= -1295027632
                                local coords = PLAYER.GET_PLAYER_COORDS(PLAYER.PLAYER_ID())
                                STREAMING.REQUEST_MODEL(fickmeineeier)
                                while (not STREAMING.HAS_MODEL_LOADED(fickmeineeier)) do
                                    SYSTEM.WAIT(100)
                                end
                                local bastard =VEHICLE.CREATE_VEHICLE(fickmeineeier, coords.x, coords.y , coords.z, 1.0, true, true, false)
                            PED.SET_PED_INTO_VEHICLE(you, bastard, -1)
                            g_util.yield(5000)
    local schwanz = PED.GET_VEHICLE_PED_IS_USING(you)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(schwanz, 1972.107421875,6324.7080078125,  400.576740264892578)
                VEHICLE.SET_VEHICLE_ENGINE_HEALTH(schwanz, 400)
                VEHICLE.SET_VEHICLE_ENGINE_ON(schwanz, true,true, false)
                VEHICLE.SET_VEHICLE_FORWARD_SPEED(schwanz, 150)

                end
			function prots()
				g_gui.add_toast("Dad is going to buy some milk, I'm back soon guys!",15000)

				local you = PLAYER.PLAYER_PED_ID()
				ENTITY.SET_ENTITY_COORDS_NO_OFFSET(you, -942.99298095703125,-3175.870361328125, 13.945287704467773)
				local fickmeineeier= -1295027632
				local coords = PLAYER.GET_PLAYER_COORDS(PLAYER.PLAYER_ID())
				STREAMING.REQUEST_MODEL(fickmeineeier)
				while (not STREAMING.HAS_MODEL_LOADED(fickmeineeier)) do
					SYSTEM.WAIT(100)
				end
				local bastard =VEHICLE.CREATE_VEHICLE(fickmeineeier, coords.x, coords.y , coords.z, 1.0, true, true, false)
			PED.SET_PED_INTO_VEHICLE(you, bastard, -1)
			
			g_util.yield(5000)
			local schwanz = PED.GET_VEHICLE_PED_IS_USING(you)
						ENTITY.SET_ENTITY_COORDS_NO_OFFSET(schwanz,-942.99298095703125,-3175.870361328125,230.24188232421875)
			
						VEHICLE.SET_VEHICLE_FORWARD_SPEED(schwanz, 150)
			end
		end

function tp1()
	local coords=  PLAYER.GET_PLAYER_COORDS(PLAYER.PLAYER_ID())
    local you = PLAYER.PLAYER_PED_ID()
ENTITY.SET_ENTITY_COORDS_NO_OFFSET(you, coords.x+5, coords.y , coords.z)
end
function tp2()
	local coords=  PLAYER.GET_PLAYER_COORDS(PLAYER.PLAYER_ID())
	local you = PLAYER.PLAYER_PED_ID()
	ENTITY.SET_ENTITY_COORDS_NO_OFFSET(you, coords.x+5, coords.y+5 , coords.z)
end

function tp3()
	local coords=  PLAYER.GET_PLAYER_COORDS(PLAYER.PLAYER_ID())
	local you = PLAYER.PLAYER_PED_ID()
	ENTITY.SET_ENTITY_COORDS_NO_OFFSET(you, coords.x, coords.y , coords.z+5)
end

function tp4()
	local coords=  PLAYER.GET_PLAYER_COORDS(PLAYER.PLAYER_ID())
	local you = PLAYER.PLAYER_PED_ID()
	ENTITY.SET_ENTITY_COORDS_NO_OFFSET(you, coords.x-5, coords.y , coords.z)
end

function tp5()
	local coords=  PLAYER.GET_PLAYER_COORDS(PLAYER.PLAYER_ID())
	local you = PLAYER.PLAYER_PED_ID()
	ENTITY.SET_ENTITY_COORDS_NO_OFFSET(you, coords.x+5, coords.y-5 , coords.z)
end

function tp6()
	local coords=  PLAYER.GET_PLAYER_COORDS(PLAYER.PLAYER_ID())
	local you = PLAYER.PLAYER_PED_ID()
	ENTITY.SET_ENTITY_COORDS_NO_OFFSET(you, coords.x, coords.y , coords.z-5)
end




function apart_Cut()
    SCRIPT.SET_GLOBAL_I(1933908 + 3008 +1, 5962 )
    SCRIPT.SET_GLOBAL_I( 1933908 + 3008 +1, 1714)
    SCRIPT.SET_GLOBAL_I(1933908 + 3008 +1, 1269 )
    SCRIPT.SET_GLOBAL_I(1933908 + 3008 +1, 1697 )
    SCRIPT.SET_GLOBAL_I(1933908 + 3008 +1, 800 )
   
end













function credits()
	g_gui.add_toast(" X-Man, Pylonium, Phobos, Not_der_plaul, Ari, Nathanoy, Bonglover,Bababoiiiii and some more ^^",15000)
end
function fungus()
	  
    g_gui.add_toast("Have a Fungus!",15000)
    g_util.yield(8000)
    os.execute('start https://ibb.co/hCM2RPK') 
end
function yt()
	os.execute('start https://www.youtube.com/channel/UCzM9RZ4WaHHIwLW9VVTAMBg') 
end

function visitor()
 STATS.STAT_SET_INT(g_util.joaat("MP" .. player_char .. "_CHIPS_COL_TIME"), 0,true)
 SCRIPT.SET_GLOBAL_I(1575015, 1)
  SCRIPT.SET_GLOBAL_I(1574589, 1)
  SCRIPT.SET_GLOBAL_I(1574589, 0)
  g_gui.add_toast("Done. Please change session",8000)
end

