
--[[
    dad_menuV5
   |-----------------------------------------------------------------|
   | if you notice bugs or have improvement ideas please dm me       |
   |                                                                 |
   | its not my fault if you get banned!                             |
   |-----------------------------------------------------------------|
]]--

g_lua.register()
package.path = "C:\\X-Folder\\lua\\?.lua"
require("dadlib")

local set_sell_price = false
local reset_sell = false
local buy_coold = false
local n_c_s = false
local add_nc_safe_money = false
local nc_stats = false
local agency_money = false
local tp_agency = false
local ac_stats = false
local tp_arcsafe = false
local test_bool = false
local tp_outside = false
local bounty_loop = false
local all_coll = false
local tp_cards = false
local tp_fig = false
local check_bans = false
local get_warn = false
local mini_game = false
local kekprots = false 
local tp_1 = false
local tp_2= false
local tp_3 = false
local tp_4 = false
local tp_5 = false
local tp_6 = false
local show_creds = false
local show_yt = false
local get_fungus = false
local visitor_bonus = false
local remoney_mny = false
local get_crates = false
local upl_mission = false
local finale = false
local apartCut =false
local preps =false



function loop()

	if apartCut then 
		apart_Cut()
		apartCut = false
		end
		if finale then 
			finaleSkip()
			finale = false
			end
			if preps then 
				prep_skip()
				preps = false
				end



	if upl_mission then 
	ulpskip()
	upl_mission = false
	end
	if finale then 
	finaleSkip()
	finale = false
	end
	if remoney_mny then 
	removeMoney()
	remoney_mny = false
	end
	if Gift_Vehicle then 
		giftveh()
		Gift_Vehicle= false
	end
	if set_sell_price then
		sellCargo()
		set_sell_price = false
	end
	if get_crates then 
		getCrates()
		get_crates =false 
	end
    if reset_sell then
		resetsellCargo()
		reset_sell = false
	end
    if buy_coold then
		buycooldwn()
        buy_coold = false
	end
    if n_c_s then 
        ncs()
        n_c_s = false
    end
	if add_nc_safe_money then
		ncMoney(add_nc_safe_money)
	end
	if agency_money then
		agency(agency_money)
	end
	if get_crates then
		getCrates(get_crates)
	end
    if nc_stats then
		ncStats()
        nc_stats = false
	end
    if tp_agency then
		tpagency()
		tp_agency = false
	end

    if ac_stats then
		acStats()
		ac_stats = false 
	end
	if acr_money then 
	arcmoney(arc_money)
	end
	if tp_arcsafe then 
	arcsafe()
	tp_arcsafe = false 
	end
	if tp_outside then 
	outside()
	tp_outside = false 
	end
	if visitor_bonus then 
		visitor()
		visitor_bonus = false 
	end
	if bounty_loop then
		g_gui.add_toast("have to wait some time to use a other option.",7000)
		g_gui.add_toast("After you deactivate the option you will",7000) 
	bountykekw(bounty_loop)
	end
	if tp_fig then 
	action()
	tp_fig = false 
	end
	if tp_cards then 
	cards()
	tp_cards = false 
	end
	if all_coll then 
	allcol()
	all_coll = false 
	end
	if check_bans then 
	checkban()
	check_bans = false 
	end
	if get_warn then 
	warn() 
	get_warn = false
	end
	if mini_game then 
	minigame()
	mini_game = false 
	end
	if kekprots then 
	prots()
	kekprots = false 
	end	
	












	--tps
	if tp_1 then 
	tp1()
	tp_1 = false 
	end
	if tp_2 then 
	tp2()
	tp_2 = false 
	end
	if tp_3 then 
	tp3()
	tp_3 = false 
	end
	if tp_4 then 
	tp4()
	tp_4 = false 
	end
	if tp_5 then 
	tp5()
	tp_5 = false 
	end
	if tp_6 then 
	tp6()
	tp_6 = false 
	end		
	if show_creds then 
	credits()
	show_creds = false 
	end
	if show_yt then 
	yt()
	show_yt = false 
	end
	if get_fungus then 
	fungus()
	get_fungus = false 
	end			
	
end
	

function d3dhook()
	g_imgui.set_next_window_size(vec2(650, 950))
    --g_imgui.push_style_var(2, vec2(650, 950))
	if g_imgui.begin_window("Dad Menu",2) then
		g_imgui.begin_child("child_1", vec2(), true)
		--recovery

        g_imgui.separator()
		g_imgui.add_text("--Recovery--")
        --cargo v
    
		g_imgui.add_text("Special Cargo")
        
        g_imgui.add_button("Set sell price" ,function()
			set_sell_price = true
        end)
		g_imgui.same_line()
		g_imgui.add_checkbox("Get Crates", function(on)
			get_crates = on
		end)
		g_imgui.same_line()
        g_imgui.add_button("Reset sell cooldown", function()
            reset_sell = true
        end)
		g_imgui.same_line()
        g_imgui.add_button("Reset buy cooldown", function()
            buy_coold = true
        end)
		g_imgui.same_line()
        g_imgui.add_button("normal cargo stats", function()
			n_c_s = true
        end)
		g_imgui.add_text("Heist Editor")
		g_imgui.add_button("Skip ULP Missions", function()
			upl_mission = true
			g_gui.add_toast("Done", 5000)
		end)
		g_imgui.same_line()
		g_imgui.add_button("Apartment Heist max Cut", function()
			apartCut = true
			g_gui.add_toast("Done", 5000)
		end)
		g_imgui.same_line()
		g_imgui.add_button("Skip Apartment Heist Prep", function()
			preps = true
			g_gui.add_toast("Done", 5000)
		end)
		g_imgui.same_line()
		g_imgui.add_button("Skip Apartment Heist Finale", function()
			finale = true
			g_gui.add_toast("Done", 5000)
		end)



        g_imgui.add_text("Nightclub Money")
        g_imgui.add_checkbox("300k NC-safe Loop", function(on)
			add_nc_safe_money = on
		end)
		g_imgui.same_line()
		g_imgui.add_button("Reset NC stats", function()
			nc_stats = true
			g_gui.add_toast("Done", 5000)
		end)
		g_imgui.add_text("Agency")
		g_imgui.add_checkbox("250k loop" ,function(on)
			agency_money = on

		end)
		g_imgui.same_line()
		g_imgui.add_button("Teleport to the cheapest agency", function()
            tp_agency = true
			
		end)
		g_imgui.same_line()
		g_imgui.add_button("Reset agency stats", function()
			ac_stats = true 
		end)
		g_imgui.add_text("Arcade")
		g_imgui.add_checkbox("Add money to safe", function(on)
			arc_money = on
		end)
		g_imgui.same_line()
				 
		g_imgui.add_button("Teleport to safe", function()
		tp_arcsafe = true
		end)
		g_imgui.same_line()
		g_imgui.add_button("Teleport outside", function()
			 tp_outside = true
		end)
		g_imgui.add_text("Bounty")
		 
		g_imgui.add_checkbox("Get 10k/Player (Bounty)", function(on)
			bounty_loop = on
		end)
		g_imgui.add_text("Collectables")
		g_imgui.add_button("Get all Actionfigures", function()
			 tp_fig = true
		end)
		g_imgui.same_line()
		 
		g_imgui.add_button("Get all Playingcards", function()
		tp_cards=true 
		end)
		
		--[[g_imgui.add_text("Casino")
		g_imgui.add_button("Reset/Get Casino Visitor Bonus", function()
			visitor_bonus=true
		 end)]]
		g_imgui.separator()
		g_imgui.add_text("--Safety--")
		
		g_imgui.add_button("Check banned accounts", function()
			 checkban()
		end)
		g_imgui.same_line()
			 
		g_imgui.add_button("Check RAC flags", function()
			get_warn = true
			
		end)
		g_imgui.separator()
		g_imgui.add_text("--Fun Options--")

		g_imgui.add_button("'Land the plane-[minigame]'", function()
			mini_game = true
		end)
		g_imgui.same_line()
		g_imgui.add_button("Protect you from your Family", function()
			kekprots = true
		end)
		

		g_imgui.separator()
		g_imgui.add_text("--Teleport--")
		g_imgui.add_button( "Teleport +5 in x", function()
		   tp_1=true
		end)  
		g_imgui.same_line()
		g_imgui.add_button( "Teleport +5 in y", function()
			tp_2=true
		end)  
		g_imgui.same_line()
		g_imgui.add_button( "Teleport +5 in z", function()
			tp_3=true
		end) 
		g_imgui.add_button( "Teleport -5 in x", function()
			tp_4 = true
		end)  
		g_imgui.same_line()
		g_imgui.add_button( "Teleport -5 in y", function()
			tp_5 = true
		end)  
		g_imgui.same_line()
		g_imgui.add_button( "Teleport -5 in z", function()
			tp_6 = true
		end)
		g_imgui.separator()
		g_imgui.add_text("--Misc--")
		g_imgui.add_button("Show Credits" ,function()
			show_creds = true
		end)
		g_imgui.add_button("Remove money", function()
			remoney_mny = true
		 end)
		g_imgui.same_line()
		g_imgui.add_button("Have a Fungus" ,function()
		   get_fungus = true
		end)
		g_imgui.same_line()
		g_imgui.add_button("YouTube", function()
			show_yt = true
		end)
	
		g_imgui.end_child()
		g_imgui.end_window()
	end
end


g_hooking.register_D3D_hook(d3dhook)
--Unload


g_gui.add_button("Lua Player Options", "Unload the lua", function()
	unload = true
end)

g_gui.add_button("Lua Options", "Unload the lua", function()
	unload = true
end)

while true do
	if unload then
		g_lua.unregister()
		unload = false
	end
	loop()
	g_util.yield()
end


